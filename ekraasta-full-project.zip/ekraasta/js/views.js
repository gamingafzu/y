/* ============================================================
   views.js — v3 UX
   Ek app, do mode: 90 Din (red) aur Learning (indigo).
   Upar switch se turant badal jata hai. Neeche ka "aaj" same rehta hai.
   ============================================================ */

const ui = {
  nav: 'home',        // home | plan | practice | more
  mode: '90',         // 90 | learn  <- roadmap switch
  more: null,
  practice: 'prompt',
  openPhase: 'p1',
  openMonth: null,
  promptRes: null,
  englishRes: null,
  quiz: null,
  cloudTest: null
};

const draft = { prompt: '', english: '' };

/* ---------------- shared bits ---------------- */
function modeSwitch() {
  const t90 = t90Stats();
  const lr = learnStats();
  return `
    <div class="modeswitch">
      <button data-act="mode" data-mode="90" class="${ui.mode === '90' ? 'on' : ''}">
        <span class="dot"></span> 90 Din${t90.pct ? ` <span class="count">${t90.pct}%</span>` : ''}
      </button>
      <button data-act="mode" data-mode="learn" class="${ui.mode === 'learn' ? 'on' : ''}">
        <span class="dot"></span> Learning${lr.pct ? ` <span class="count">${lr.pct}%</span>` : ''}
      </button>
    </div>`;
}

function nextTask90() {
  for (const ph of PLAN_90) {
    for (let i = 0; i < ph.tasks.length; i++) {
      if (!state.t90.done[ph.id + '-' + i]) return { ph, i, t: ph.tasks[i] };
    }
  }
  return null;
}

function nextWeekLearn() {
  const mo = currentMonth();
  for (const w of mo.weeks) {
    if (!state.learn.done['m' + mo.m + '-' + w.w]) return { mo, w };
  }
  if (!state.learn.done['m' + mo.m + '-proj']) return { mo, proj: true };
  return { mo };
}

/* ============================================================
   HOME — dono track ek jagah
   ============================================================ */
function vHome() {
  const rec = todayRec();
  const done = blocksDone(rec);
  const pct = Math.round((done / DAILY_BLOCKS.length) * 100);
  const wk = weekStartISO(todayISO());
  const name = state.profile.name || 'Aadil';

  const blocks = DAILY_BLOCKS.map((b) => {
    const isDone = !!rec.blocks[b.id];
    const trk = b.track === '90' ? 'trk-90' : b.track === 'learn' ? 'trk-learn' : 'trk-both';
    return `
      <div class="blk ${isDone ? 'done' : ''}" data-act="toggle-block" data-id="${b.id}">
        <div class="cb">${icon('check')}</div>
        <div class="blk-main">
          <div class="blk-title"><span class="trk ${trk}"></span>${esc(b.title)}</div>
          <div class="blk-hint">${b.mins} min · ${esc(b.hint)}</div>
        </div>
      </div>`;
  }).join('');

  return `
  ${modeSwitch()}

  <div class="hero ${ui.mode === '90' ? 'm90' : 'mlearn'}">
    <div class="hero-top">
      <div class="eyebrow">${ui.mode === '90' ? '90-din track' : 'Learning track'}</div>
      <div class="hero-pill num">${done}/${DAILY_BLOCKS.length} aaj</div>
    </div>
    <h2>${esc(name)}, aaj ka din</h2>
    <p>${done >= DAILY_BLOCKS.length ? 'Sab ho gaya — streak bach gaya.' : done >= 4 ? 'Bas ek-do block bache hain.' : 'Ek-ek block. Bas shuru karo.'}</p>
    <div class="hero-bar"><i style="width:${pct}%"></i></div>
    <div class="hero-stats">
      <div class="hero-stat"><b>${ui.mode === '90' ? day90() : 'M' + currentMonth().m}</b><span>${ui.mode === '90' ? 'din / 90' : 'mahina'}</span></div>
      <div class="hero-stat"><b>${streak()}</b><span>din streak</span></div>
      <div class="hero-stat"><b>${weekHours(wk)}</b><span>ghante/hafta</span></div>
    </div>
  </div>

  <div class="sec"><h3>Aaj ka plan</h3><span class="tiny muted">${TOTAL_MINS} min</span></div>
  <div class="card tight">${blocks}</div>

  <div class="sec"><h3>${ui.mode === '90' ? 'Agla kaam' : 'Agla step'}</h3></div>
  ${ui.mode === '90' ? next90Card() : nextLearnCard()}

  <div class="sec"><h3>Aaj ka log</h3><span class="tiny muted">kya banaya / kya atka</span></div>
  <div class="card">
    <textarea id="logArea" placeholder="Aaj: ...&#10;Atka: ...&#10;Kal: ...">${esc(rec.log || '')}</textarea>
    <button class="btn soft sm mt10" data-act="save-log">Log save karo</button>
  </div>

  <div class="stat-row">
    <div class="stat" data-act="more" data-sub="money" style="cursor:pointer">
      <b>${inr(monthEarn())}</b><span>is mahine</span>
    </div>
    <div class="stat" data-act="more" data-sub="projects" style="cursor:pointer">
      <b>${shippedCount()}/${state.projects.length}</b><span>project</span>
    </div>
    <div class="stat" data-act="nav" data-nav="practice" style="cursor:pointer">
      <b>${state.evals.length}</b><span>evals</span>
    </div>
  </div>
  `;
}

function next90Card() {
  const n = nextTask90();
  if (!n) {
    return `<div class="card">
      <div class="card-title">Sab kaam ho gaye</div>
      <div class="card-sub">Day 91 pe repeat plan kholo — rate 2x.</div>
    </div>`;
  }
  const ps = phaseStats(n.ph);
  return `
  <div class="card">
    <div class="row between" style="align-items:flex-start">
      <div style="flex:1;min-width:0">
        <span class="tag red">${esc(n.ph.name)}</span>
        <div class="card-title mt6">${esc(n.t.t)}</div>
        <div class="card-sub">${esc(n.ph.range)} · ${ps.done}/${ps.total} ho gaye</div>
      </div>
    </div>
    ${progressBar(Math.round((ps.done / ps.total) * 100))}
    <div class="mt10">
      <div class="hr-label" style="margin-top:0">Kaise karna hai</div>
      <ol style="margin:0;padding-left:18px;font-size:12.5px;color:var(--text-2);line-height:1.6">
        ${n.t.how.slice(0, 3).map((h) => `<li>${esc(h)}</li>`).join('')}
      </ol>
    </div>
    <button class="btn accent block mt14" data-act="nav" data-nav="plan">Poora plan dekho</button>
  </div>`;
}

function nextLearnCard() {
  const n = nextWeekLearn();
  const ms = monthStats(n.mo);
  return `
  <div class="card">
    <div class="row between" style="align-items:flex-start">
      <div style="flex:1;min-width:0">
        <span class="tag indigo">Month ${n.mo.m}</span>
        <div class="card-title mt6">${esc(n.mo.title)}</div>
        <div class="card-sub">${esc(n.mo.focus)}</div>
      </div>
    </div>
    ${progressBar(Math.round((ms.done / ms.total) * 100), 'indigo')}
    <div class="mt10">
      <div class="hr-label" style="margin-top:0">${n.proj ? 'Is month ka project' : 'Is hafte ka topic'}</div>
      <div style="font-size:13px;font-weight:600">${esc(n.proj ? n.mo.project.t : (n.w.w + ' — ' + n.w.d))}</div>
    </div>
    <button class="btn indigo block mt14" data-act="nav" data-nav="plan">Learning plan khole</button>
  </div>`;
}

/* ============================================================
   PLAN — dono roadmap, switch se
   ============================================================ */
function vPlan() {
  return `
  ${modeSwitch()}
  <div class="blk-head">
    <div>
      <div class="blk-head-t">${ui.mode === '90' ? '90-din roadmap' : 'Learning roadmap'}</div>
      <div class="blk-head-s">${ui.mode === '90'
        ? 'Fixed dates · paisa + proof · ' + day90() + '/90 din'
        : 'Flexible · 13 mahine · ' + learnStats().pct + '% ho gaya'}</div>
    </div>
  </div>
  ${ui.mode === '90' ? plan90Body() : learnBody()}
  `;
}

/* ---------------- 90 din ---------------- */
function plan90Body() {
  const st = t90Stats();
  const phases = PLAN_90.map((ph, idx) => {
    const ps = phaseStats(ph);
    const open = ui.openPhase === ph.id;
    const pct = Math.round((ps.done / ps.total) * 100);
    const tasks = ph.tasks.map((t, i) => {
      const key = ph.id + '-' + i;
      const isDone = !!state.t90.done[key];
      return `
        <div class="task ${isDone ? 'done' : ''}">
          <div class="task-top" data-act="toggle-t90" data-key="${key}">
            <div class="cb">${icon('check')}</div>
            <div class="task-txt">${esc(t.t)}</div>
          </div>
          <details class="how">
            <summary>Kaise karna hai</summary>
            <div class="how-body">
              <ol>${t.how.map((h) => `<li>${esc(h)}</li>`).join('')}</ol>
              ${t.why ? `<div class="mt6"><b>Kyun:</b> ${esc(t.why)}</div>` : ''}
            </div>
          </details>
        </div>`;
    }).join('');

    return `
      <div class="card phase is-90">
        <div class="phase-head" data-act="open-phase" data-id="${ph.id}">
          <div class="phase-num">${idx + 1}</div>
          <div class="phase-meta">
            <div class="phase-name">${esc(ph.name)}</div>
            <div class="phase-range">${esc(ph.range)} · ${esc(ph.goal || '')}</div>
          </div>
          <div class="ph-end">
            <span class="cnt num">${ps.done}/${ps.total}</span>
            <div class="chev ${open ? 'open' : ''}">${icon('chev')}</div>
          </div>
        </div>
        <div class="head-bar">${progressBar(pct)}</div>
        ${open ? tasks : ''}
      </div>`;
  }).join('');

  return `
  <div class="card flat">
    <div class="row between">
      <div>
        <div class="card-sub">Progress</div>
        <div style="font-size:20px;font-weight:750" class="num">${st.done} / ${st.total}</div>
      </div>
      <div class="badge red">Day ${day90()}</div>
    </div>
    <div class="mt10">${progressBar(st.pct)}</div>
    <div class="tiny muted mt6">Yeh track date pe chalta hai — learning jahan bhi ho, nahi rukta.</div>
  </div>
  ${phases}`;
}

/* ---------------- learning ---------------- */
function learnBody() {
  const st = learnStats();
  const cm = currentMonth();
  const openMonth = ui.openMonth === null ? cm.m : ui.openMonth;

  const months = LEARN_MONTHS.map((mo) => {
    const ms = monthStats(mo);
    const open = openMonth === mo.m;
    const pct = Math.round((ms.done / ms.total) * 100);
    const weeks = mo.weeks.map((w) => {
      const key = 'm' + mo.m + '-' + w.w;
      const isDone = !!state.learn.done[key];
      return `
        <div class="week ${isDone ? 'done' : ''}" data-act="toggle-learn" data-key="${key}">
          <div class="cb" style="width:18px;height:18px;border-radius:6px;${isDone ? 'background:var(--ok);border-color:var(--ok)' : ''}">${icon('check')}</div>
          <div class="week-n">${w.w}</div>
          <div class="week-txt">${esc(w.d)}</div>
        </div>`;
    }).join('');

    const projKey = 'm' + mo.m + '-proj';
    const projDone = !!state.learn.done[projKey];
    const res = (mo.res || []).map((r) => r.u
      ? `<a class="res-link" href="${esc(r.u)}" target="_blank" rel="noopener">${icon('link')}${esc(r.l)}</a>`
      : `<div class="res-link" style="color:var(--text-2)">${icon('info')}${esc(r.l)}</div>`).join('');

    return `
      <div class="card phase is-learn">
        <div class="mon-head" data-act="open-month" data-m="${mo.m}">
          <div class="mon-badge"><b>${mo.m}</b><i>MON</i></div>
          <div class="phase-meta">
            <div class="phase-name">${esc(mo.title)}</div>
            <div class="phase-range">${esc(mo.focus)}</div>
          </div>
          <div class="ph-end">
            <span class="cnt num">${ms.done}/${ms.total}</span>
            <div class="chev ${open ? 'open' : ''}">${icon('chev')}</div>
          </div>
        </div>
        <div class="head-bar">${progressBar(pct, 'indigo')}</div>
        ${open ? `
          <div class="mon-body">
            ${weeks}
            <div class="proj-box">
              <div class="row between">
                <b>Project: ${esc(mo.project.t)}</b>
                <div class="cb" style="width:18px;height:18px;border-radius:6px;${projDone ? 'background:var(--ok);border-color:var(--ok)' : ''}"
                     data-act="toggle-learn" data-key="${projKey}">${icon('check')}</div>
              </div>
              <ol>${mo.project.steps.map((s) => `<li>${esc(s)}</li>`).join('')}</ol>
            </div>
            ${res ? `<div class="res-links">${res}</div>` : ''}
            ${mo.note ? `<div class="how-body" style="margin-top:12px;font-size:12px;color:var(--text-2)">${esc(mo.note)}</div>` : ''}
          </div>` : ''}
      </div>`;
  }).join('');

  return `
  <div class="card flat">
    <div class="row between">
      <div>
        <div class="card-sub">Abhi</div>
        <div style="font-size:20px;font-weight:750" class="num">Month ${cm.m}</div>
      </div>
      <div class="badge indigo">${st.pct}% total</div>
    </div>
    <div class="mt10">${progressBar(st.pct, 'indigo')}</div>
    <div class="tiny muted mt6">12 month target · 13 lage to koi problem nahi. Deadline nahi, direction hai.</div>
  </div>

  ${adaptedCard()}
  ${months}`;
}

function adaptedCard() {
  const open = ui.more === 'adapted';
  const rows = [
    ['Month 1', 'Excel dashboard hataya', 'Python + scripts pe pura time — AI engineer ko Excel ka basic kaafi'],
    ['Month 3', 'EDA 4 hafte → 3 hafte', 'Chautha hafta SQL ko diya — SQL se freelance kaam milta hai'],
    ['Month 4', 'Power BI / Tableau skip', 'Data analyst ka kaam nahi chahiye. Uski jagah FastAPI early start'],
    ['Month 4', 'FastAPI jaldi shuru', 'API deploy karna aana = paisa kamane layak banna'],
    ['Month 7', 'Deep Learning 4 → 3 hafte', 'CNN project rakha, RNN sirf samajhne ke liye'],
    ['Month 12-13', 'Buffer month add', '13 mahine lage to guilt nahi — tumne khud bola tha'],
    ['Resources', 'Hindi-first', 'CodeWithHarry / CampusX — English weak hai, isliye'],
    ['Resume/LinkedIn', 'Sample copy nahi', 'Woh 10 saal experience wale ke hain. Tumhara resume projects se banega']
  ];
  return `
  <div class="card">
    <div class="row between" data-act="adapted-toggle" style="cursor:pointer">
      <div>
        <div class="card-title">Tumhare hisaab se kya badla</div>
        <div class="card-sub">11th pass, English weak, paisa jaldi chahiye, degree nahi</div>
      </div>
      <div class="chev ${open ? 'open' : ''}">${icon('chev')}</div>
    </div>
    ${open ? `<div class="mt10">
      ${rows.map((r) => `
        <div style="padding:9px 0;border-top:1px solid var(--line)">
          <div class="row between"><b class="small">${esc(r[0])}</b><span class="tiny muted">${esc(r[1])}</span></div>
          <div class="tiny muted mt6">${esc(r[2])}</div>
        </div>`).join('')}
    </div>` : ''}
  </div>`;
}

/* ============================================================
   PRACTICE
   ============================================================ */
function vPractice() {
  const tabs = `
    <div class="seg">
      <button class="${ui.practice === 'prompt' ? 'on' : ''}" data-act="practice-tab" data-t="prompt">Prompt Lab</button>
      <button class="${ui.practice === 'english' ? 'on' : ''}" data-act="practice-tab" data-t="english">English</button>
      <button class="${ui.practice === 'tests' ? 'on' : ''}" data-act="practice-tab" data-t="tests">Tests</button>
    </div>`;

  if (ui.practice === 'prompt') return tabs + practicePrompt();
  if (ui.practice === 'english') return tabs + practiceEnglish();
  return tabs + practiceTests();
}

function practicePrompt() {
  const r = ui.promptRes;
  const resultHTML = r ? `
    <div class="card">
      <div class="score-head">
        <div>
          <div class="score-num ${r.score >= 75 ? 'good' : r.score >= 50 ? 'mid' : 'low'}">${r.score}</div>
          <div class="tiny muted">/ 100</div>
        </div>
        <div class="score-meta">
          ${progressBar(r.score, r.score >= 75 ? 'ok' : '')}
          <div class="tiny muted mt6">${r.score >= 75 ? 'Achha prompt hai.' : r.score >= 50 ? 'Theek hai, sudhaar possible hai.' : 'Yeh galti tumhari hai — prompt adhoora hai. Neeche jo missing hai wo add karo.'}</div>
        </div>
      </div>
      <div class="divider"></div>
      ${r.items.map((it) => `
        <div class="fb">
          <div class="fb-dot ${it.type}"></div>
          <div>${esc(it.text)}</div>
        </div>`).join('')}
      <div class="how-body" style="margin-top:12px"><b>Zara ki salah:</b> ${esc(r.next)}</div>
      <div class="row gap mt10">
        <button class="btn sm soft" data-act="speak" data-text="${esc(r.next)}">${icon('play')} Suno</button>
        <button class="btn sm ghost" data-act="prompt-save">Save karo</button>
      </div>
    </div>` : '';

  return `
  <div class="card">
    <div class="card-title">Prompt likho</div>
    <div class="card-sub">Zara check karegi — role, task, context, format, constraint</div>
    <textarea id="promptArea" class="mt10" placeholder="Tum ek senior Python developer ho. Neeche diye code me bug dhundo. Main beginner hoon. Output table me do: bug, kyun, fix. Sirf 3 bug. Hinglish me.">${esc(draft.prompt)}</textarea>
    <div class="row gap mt10">
      <button class="btn accent" data-act="check-prompt">Check karwao</button>
      <button class="btn ghost" data-act="prompt-example">Example</button>
    </div>
  </div>
  ${resultHTML}
  <div class="sec"><h3>Prompt ke 5 part</h3></div>
  <div class="card">
    ${PROMPT_PARTS.map((p) => `<div class="tpl"><b>${esc(p.name)}</b>"${esc(p.ex)}"</div>`).join('')}
  </div>`;
}

function practiceEnglish() {
  const r = ui.englishRes;
  const words = draft.english.trim() ? draft.english.trim().split(/\s+/).length : 0;
  const tpl = ENGLISH_TEMPLATES.map((g) => `
    <div class="hr-label" style="margin:12px 0 6px">${esc(g.g)}</div>
    ${g.items.map((i) => `<div class="tpl">${esc(i)}</div>`).join('')}`).join('');

  const resultHTML = r ? `
    <div class="card">
      <div class="score-head">
        <div>
          <div class="score-num ${r.score >= 75 ? 'good' : r.score >= 50 ? 'mid' : 'low'}">${r.score}</div>
          <div class="tiny muted">/ 100 · ${r.words} words</div>
        </div>
        <div class="score-meta">${progressBar(r.score, r.score >= 75 ? 'ok' : '')}</div>
      </div>
      <div class="divider"></div>
      ${r.items.map((it) => `<div class="fb"><div class="fb-dot ${it.type}"></div><div>${esc(it.text)}</div></div>`).join('')}
      <div class="how-body" style="margin-top:12px"><b>Zara ki salah:</b> ${esc(r.next)}</div>
      <div class="row gap mt10">
        <button class="btn sm soft" data-act="eval-save">Eval me save karo</button>
        <button class="btn sm ghost" data-act="speak" data-text="${esc(r.next)}">${icon('play')} Suno</button>
      </div>
    </div>` : '';

  return `
  <div class="card">
    <div class="card-title">English eval drill</div>
    <div class="card-sub">Ek bad AI answer lo, 150 words me feedback likho. Hindi me socho, English me likho.</div>
    <textarea id="englishArea" class="mt10" placeholder="This response is correct but incomplete. It says Python is used for data science. It should also mention web development and automation...">${esc(draft.english)}</textarea>
    <div class="row between mt6">
      <span class="tiny muted" id="wordCount">${words} words</span>
      <button class="btn sm ghost" data-act="load-samples">Sample</button>
    </div>
    <button class="btn accent block mt10" data-act="check-english">Check karwao</button>
  </div>
  ${resultHTML}
  <div class="sec"><h3>15 templates</h3><span class="tiny muted">ratna hai</span></div>
  <div class="card">${tpl}</div>`;
}

function practiceTests() {
  const q = ui.quiz;
  if (!q) {
    const last = state.tests.slice().sort((a, b) => (a.at < b.at ? 1 : -1))[0];
    return `
    <div class="card">
      <div class="card-title">Test lo</div>
      <div class="card-sub">5 sawaal · prompt, eval, AI basics, paisa. Har jawab ke baad explanation.</div>
      <button class="btn accent block mt14" data-act="start-test">Test shuru karo</button>
      ${last ? `<div class="tiny muted mt10">Pichla: ${last.score}/5 · ${fmtDate(last.at)}</div>` : ''}
    </div>
    ${state.tests.length ? `<div class="card">
      <div class="card-title">Purane tests</div>
      ${state.tests.slice().reverse().slice(0, 6).map((t) => `
        <div class="kv"><span class="muted">${fmtDate(t.at)}</span><b>${t.score}/5</b></div>`).join('')}
    </div>` : ''}`;
  }

  if (q.idx >= q.list.length) {
    const s = q.score;
    return `
    <div class="card center">
      <div class="score-num ${s >= 4 ? 'good' : s >= 3 ? 'mid' : 'low'}" style="font-size:42px">${s}/5</div>
      <div class="muted small mt6">${s >= 4 ? 'Bahut achha — topic clear hai.' : s >= 3 ? 'Theek hai, thoda revise karo.' : 'Kam hai — templates dobara padho.'}</div>
      <button class="btn accent block mt14" data-act="start-test">Dubara</button>
      <button class="btn ghost block mt10" data-act="end-test">Wapas</button>
    </div>`;
  }

  const item = q.list[q.idx];
  return `
  <div class="card">
    <div class="row between"><span class="tiny muted">Sawaal ${q.idx + 1} / ${q.list.length}</span><span class="tiny muted">Sahi: ${q.score}</span></div>
    <div class="mt6">${progressBar((q.idx / q.list.length) * 100)}</div>
    <div class="qbox mt14">${esc(item.q)}</div>
    ${item.o.map((opt, i) => {
      let cls = '';
      if (q.answered !== null) {
        if (i === item.a) cls = 'right';
        else if (i === q.answered) cls = 'wrong';
      }
      return `<button class="opt ${cls}" data-act="answer" data-i="${i}" ${q.answered !== null ? 'disabled' : ''}>${esc(opt)}</button>`;
    }).join('')}
    ${q.answered !== null ? `
      <div class="how-body mt10"><b>${q.answered === item.a ? 'Sahi!' : 'Galat.'}</b> ${esc(item.e)}</div>
      <button class="btn accent block mt10" data-act="next-q">Agla sawaal</button>` : ''}
  </div>`;
}

/* ============================================================
   MORE
   ============================================================ */
function vMore() {
  if (ui.more === 'projects') return vProjects();
  if (ui.more === 'money') return vMoney();
  if (ui.more === 'platforms') return vPlatforms();
  if (ui.more === 'ideas') return vIdeas();
  if (ui.more === 'weekly') return vWeekly();
  if (ui.more === 'settings') return vSettings();

  const rows = [
    { k: 'projects', i: 'folder', t: 'Projects', s: `${shippedCount()} shipped / ${state.projects.length}` },
    { k: 'money', i: 'wallet', t: 'Paisa', s: `${inr(totalEarn())} ab tak` },
    { k: 'platforms', i: 'list', t: 'Platforms', s: `${state.platforms.filter((p) => p.status === 'tasks' || p.status === 'paid').length} active` },
    { k: 'ideas', i: 'bulb', t: 'Ideas parking', s: `${state.ideas.length} parked · Day 91 pe khulenge` },
    { k: 'weekly', i: 'chart', t: 'Weekly scorecard', s: '6 number, har Sunday' },
    { k: 'settings', i: 'gear', t: 'Settings', s: 'naam, theme, awaaz, cloud, export' }
  ];

  return `
  <div class="blk-head">
    <div class="blk-head-t">Sab kuch</div>
    <div class="blk-head-s">projects · paisa · platforms · settings</div>
  </div>

  <div class="card flat">
    <div class="row between">
      <div style="text-align:center;flex:1"><div style="font-size:17px;font-weight:750" class="num">${inr(totalEarn())}</div><div class="tiny muted">kamai</div></div>
      <div style="width:1px;height:30px;background:var(--line)"></div>
      <div style="text-align:center;flex:1"><div style="font-size:17px;font-weight:750" class="num">${shippedCount()}/${state.projects.length}</div><div class="tiny muted">projects</div></div>
      <div style="width:1px;height:30px;background:var(--line)"></div>
      <div style="text-align:center;flex:1"><div style="font-size:17px;font-weight:750" class="num">${state.evals.length}</div><div class="tiny muted">evals</div></div>
    </div>
  </div>

  <div class="card tight">
    ${rows.map((r) => `
      <div class="item" data-act="more" data-sub="${r.k}">
        <div class="item-ico">${icon(r.i)}</div>
        <div class="item-body"><div class="item-title">${r.t}</div><div class="item-sub">${r.s}</div></div>
        <div class="item-right">${icon('arrow')}</div>
      </div>`).join('')}
  </div>

  <button class="btn block mt14" data-act="open-zara">
    ${icon('zara')} Zara se baat karo
    <span class="tiny muted" style="margin-left:6px">${state.profile.ttsProvider !== 'device' ? 'cloud voice' : 'Hinglish'}</span>
  </button>

  <div class="tiny muted center mt20">
    ekRaasta v3 · Aadil ka app<br>
    Data isi device pe · cloud on hai to dono device pe same
  </div>`;
}

function subHead(title) {
  return `<div class="row gap" style="margin-bottom:14px">
    <button class="icon-btn" data-act="more" data-sub="">${icon('arrow')}</button>
    <div style="font-size:17px;font-weight:750;letter-spacing:-.3px">${esc(title)}</div>
  </div>`;
}

function vProjects() {
  const list = state.projects.map((p) => {
    const cls = p.status === 'done' ? 'ok' : p.status === 'wip' ? 'warn' : '';
    return `
    <div class="card">
      <div class="row between">
        <div class="card-title" style="flex:1">${esc(p.name)}</div>
        <span class="badge ${cls}">${p.status === 'done' ? 'Shipped' : p.status === 'wip' ? 'Chalu' : 'Todo'}</span>
      </div>
      <div class="row wrap gap" style="gap:5px;margin-top:8px">
        ${(p.tags || []).map((t) => `<span class="tag">${esc(t)}</span>`).join('')}
      </div>
      ${p.link ? `<a class="res-link" style="padding-left:0" href="${esc(p.link)}" target="_blank" rel="noopener">${icon('link')}${esc(p.link.replace(/^https?:\/\//, ''))}</a>` : ''}
      <div class="g2 mt10">
        <select data-act="proj-status" data-id="${p.id}">
          <option value="todo" ${p.status === 'todo' ? 'selected' : ''}>Todo</option>
          <option value="wip" ${p.status === 'wip' ? 'selected' : ''}>Chalu</option>
          <option value="done" ${p.status === 'done' ? 'selected' : ''}>Ho gaya</option>
        </select>
        <input type="url" data-act="proj-link" data-id="${p.id}" placeholder="GitHub link" value="${esc(p.link)}" />
      </div>
    </div>`;
  }).join('');

  return subHead('Projects') + `
    <div class="tiny muted" style="margin:-6px 2px 12px">${shippedCount()} shipped out of ${state.projects.length}. Shipped matlab chalta hai.</div>
    ${list}`;
}

function vMoney() {
  const rows = state.earnings.length ? state.earnings.slice().reverse().map((e) => `
    <div class="item" style="cursor:default">
      <div class="item-ico">${icon('wallet')}</div>
      <div class="item-body">
        <div class="item-title num">${inr(toINR(e.amount, e.cur))}</div>
        <div class="item-sub">${fmtDate(e.date)} · ${esc(e.platform)}${e.note ? ' · ' + esc(e.note) : ''}</div>
      </div>
      <button class="icon-btn" data-act="del-earn" data-id="${e.id}">${icon('trash')}</button>
    </div>`).join('') : emptyBox('wallet', 'Abhi ₹0. Yeh normal hai.<br>Pehla paisa Karya se 2-4 hafte me.');

  const platOpts = state.platforms.map((p) => `<option value="${esc(p.name)}">${esc(p.name)}</option>`).join('');

  return subHead('Paisa') + `
    <div class="card flat">
      <div class="row between">
        <div><div class="card-sub">Is mahine</div><div class="money-big">${inr(monthEarn())}</div></div>
        <div style="text-align:right"><div class="card-sub">Ab tak</div><div style="font-size:19px;font-weight:750" class="num">${inr(totalEarn())}</div></div>
      </div>
    </div>

    <div class="card">
      <div class="card-title">Kamai add karo</div>
      <div class="g2 mt10">
        <label class="f"><span>Date</span><input type="date" id="eDate" value="${todayISO()}" /></label>
        <label class="f"><span>Platform</span><select id="ePlat">${platOpts}<option>Other</option></select></label>
        <label class="f"><span>Amount</span><input type="number" id="eAmt" placeholder="0" step="0.01" /></label>
        <label class="f"><span>Currency</span><select id="eCur"><option value="INR">INR ₹</option><option value="USD">USD $</option></select></label>
      </div>
      <label class="f"><span>Note</span><input type="text" id="eNote" placeholder="kaam kya tha" /></label>
      <button class="btn accent block" data-act="add-earn">Add karo</button>
    </div>

    <div class="card tight">${rows}</div>`;
}

function vPlatforms() {
  const t = todayISO();
  const sorted = state.platforms.slice().sort((a, b) => {
    const ad = a.due || '9999'; const bd = b.due || '9999';
    return ad < bd ? -1 : ad > bd ? 1 : 0;
  });

  const cards = sorted.map((p) => {
    const due = p.due && p.due <= t && p.status !== 'paid';
    const live = p.status === 'tasks' || p.status === 'paid';
    const opts = Object.keys(PLATFORM_STATUS).map((k) =>
      `<option value="${k}" ${p.status === k ? 'selected' : ''}>${PLATFORM_STATUS[k]}</option>`).join('');
    return `
      <div class="card" style="${due ? 'border-color:var(--warn)' : ''}">
        <div class="row between">
          <div class="card-title">${esc(p.name)}</div>
          <span class="badge ${live ? 'ok' : due ? 'warn' : ''}">${PLATFORM_STATUS[p.status] || '—'}</span>
        </div>
        <div class="card-sub mt6">${esc(p.rate || '')}</div>
        <div class="item-sub mt6"><b>Next:</b> ${esc(p.next || '—')}${p.due ? ` · ${fmtDate(p.due)}${due ? ' <span style="color:var(--warn);font-weight:700">due</span>' : ''}` : ''}</div>
        <div class="g2 mt10">
          <select data-act="plat-status" data-id="${p.id}">${opts}</select>
          <input type="date" data-act="plat-due" data-id="${p.id}" value="${esc(p.due || '')}" />
        </div>
      </div>`;
  }).join('');

  return subHead('Platforms') + `
    <div class="tiny muted" style="margin:-6px 2px 12px">Order important hai. Karya pehle — English ki zarurat kam.</div>
    ${cards}`;
}

function vIdeas() {
  const unlock = addDays(state.profile.startDate, 90);
  const left = Math.max(0, daysBetween(todayISO(), unlock));
  const list = state.ideas.length ? state.ideas.slice().reverse().map((i) => `
    <div class="card">
      <div class="row between">
        <div style="flex:1;font-size:13px">${esc(i.text)}</div>
        <button class="icon-btn" data-act="del-idea" data-id="${i.id}">${icon('trash')}</button>
      </div>
      <div class="tiny muted mt6">${fmtDate(i.at)} ko park kiya · Day 91 tak band</div>
    </div>`).join('') : emptyBox('bulb', 'Kuch park nahi hai.<br>Naya idea aaye to yahan likho — phir kaam pe wapas.');

  return subHead('Ideas parking') + `
    <div class="card">
      <div class="card-title">Naya idea aaya?</div>
      <div class="card-sub">Yeh idea achha ho sakta hai. Par abhi nahi. Yahi tumhara pattern hai — isliye park ho raha hai.</div>
      <textarea id="ideaArea" class="mt10" placeholder="Naya idea kya hai..."></textarea>
      <button class="btn accent block mt10" data-act="add-idea">Park karo</button>
    </div>
    <div class="stat-row">
      <div class="stat"><b>${state.ideas.length}</b><span>parked</span></div>
      <div class="stat"><b>${left}</b><span>din baaki</span></div>
      <div class="stat"><b>${day90()}</b><span>aaj ka din</span></div>
    </div>
    ${list}`;
}

function vWeekly() {
  const ws = weekStartISO(todayISO());
  const cur = weekRow(ws);
  const prev = weekRow(addDays(ws, -7));
  const rows = [
    ['Ghante (auto)', cur.hours, prev.hours],
    ['Evals (auto)', cur.evals, prev.evals],
    ['Kamai (auto)', inr(cur.rupees), inr(prev.rupees)],
    ['Repos shipped', cur.repos, prev.repos],
    ['Outreach', cur.outreach, prev.outreach],
    ['Replies', cur.replies, prev.replies]
  ];
  return subHead('Weekly scorecard') + `
    <div class="card">
      <div class="card-sub">Har Sunday yeh 6 number bharo.</div>
      <div class="g2 mt10">
        <label class="f"><span>Repos shipped</span><input type="number" id="wRepos" value="${cur.repos}" min="0" /></label>
        <label class="f"><span>Outreach</span><input type="number" id="wOut" value="${cur.outreach}" min="0" /></label>
        <label class="f"><span>Replies</span><input type="number" id="wRep" value="${cur.replies}" min="0" /></label>
        <label class="f"><span>Ghante (auto)</span><input type="text" value="${cur.hours}" disabled /></label>
      </div>
      <button class="btn accent block" data-act="save-week">Save karo</button>
    </div>
    <div class="card">
      <div class="card-title">Is hafte vs pichla</div>
      <div class="mt6">
        ${rows.map((r) => `<div class="kv"><span class="muted">${r[0]}</span><b>${r[1]} <span class="tiny muted">· pichla ${r[2]}</span></b></div>`).join('')}
      </div>
    </div>
    <button class="btn ghost block" data-act="print">Weekly report print / PDF</button>`;
}

function vSettings() {
  const p = state.profile;
  return subHead('Settings') + `
    <div class="card">
      <div class="card-title">Tumhari detail</div>
      <label class="f mt10"><span>Naam</span><input type="text" id="sName" value="${esc(p.name)}" placeholder="Tumhara naam" /></label>
      <div class="g2">
        <label class="f"><span>90-din Day 1</span><input type="date" id="sStart" value="${p.startDate}" /></label>
        <label class="f"><span>Learning start</span><input type="date" id="sLearn" value="${p.learnStart}" /></label>
      </div>
      <div class="g2">
        <label class="f"><span>Roz ka target (ghante)</span><input type="number" id="sHours" value="${p.hoursPerDay}" step="0.5" min="1" max="12" /></label>
        <label class="f"><span>1 USD = ? INR</span><input type="number" id="sRate" value="${p.usdRate}" min="1" /></label>
      </div>
      <button class="btn accent block" data-act="save-settings">Save karo</button>
    </div>

    <div class="card">
      <div class="row between">
        <div><div class="card-title">Theme</div><div class="card-sub">${p.theme === 'dark' ? 'Dark' : 'Light'} chal raha hai</div></div>
        <button class="btn sm soft" data-act="theme">${icon(p.theme === 'dark' ? 'sun' : 'moon')} Badlo</button>
      </div>
      <div class="divider"></div>
      <div class="row between">
        <div><div class="card-title">Zara bole?</div><div class="card-sub">${p.voice ? 'Bol ke sunati hai' : 'Chup rehti hai'}</div></div>
        <button class="btn sm ${p.voice ? 'soft' : 'ghost'}" data-act="toggle-voice">${p.voice ? 'On' : 'Off'}</button>
      </div>
    </div>

    ${voiceCard()}

    <div class="card">
      <div class="card-title">Zara ka dimag (optional)</div>
      <div class="card-sub">Bina key ke rules se chalti hai — offline. Free Groq key daalo to asli AI.</div>
      <label class="f mt10"><span>API key</span><input type="password" id="sKey" value="${esc(p.apiKey)}" placeholder="gsk_... (khaali chhod do to offline)" /></label>
      <label class="f"><span>API base URL</span><input type="text" id="sBase" value="${esc(p.apiBase)}" /></label>
      <label class="f"><span>Model</span><input type="text" id="sModel" value="${esc(p.apiModel)}" /></label>
      <button class="btn accent block" data-act="save-settings">Save karo</button>
    </div>

    <div class="card">
      <div class="card-title">Cloud sync (login)</div>
      <div class="card-sub">Ek account = phone aur PC dono pe same data</div>
      ${cloudCardBody()}
    </div>

    <div class="card">
      <div class="card-title">App install karo</div>
      <div class="card-sub">Phone ya PC pe icon — browser bar ke bina</div>
      <button class="btn soft block mt10" data-act="install">Install / Add to Home Screen</button>
    </div>

    <div class="card">
      <div class="card-title">Data</div>
      <div class="card-sub">Data isi browser me. Export karke rakh lo.</div>
      <div class="row gap wrap mt10">
        <button class="btn sm ghost" data-act="export">Export</button>
        <button class="btn sm ghost" data-act="import">Import</button>
        <button class="btn sm danger" data-act="reset">Reset</button>
      </div>
      <input type="file" id="importFile" accept="application/json" class="hidden" />
    </div>

    <div class="tiny muted center">ekRaasta v3 · Made for Aadil</div>`;
}

/* ---------------- Zara ki awaaz ---------------- */
function voiceCard() {
  const st = Zara.ttsStatus();
  const list = Zara.allVoices();
  const cur = state.profile.voiceName || (Zara.chosenVoice() ? Zara.chosenVoice().name : '');
  const provider = state.profile.ttsProvider || 'device';

  const options = list.length
    ? list.map((v) => `<option value="${esc(v.name)}" ${v.name === cur ? 'selected' : ''}>${esc(v.name)} · ${esc(v.lang)}</option>`).join('')
    : '<option value="">Koi voice nahi mili</option>';

  return `
  <div class="card">
    <div class="card-title">Zara ki awaaz</div>
    <div class="card-sub">Abhi: <b>${esc(st.voice)}</b> · ${esc(st.engine)}</div>

    <div class="hr-label">Device voice (free)</div>
    <label class="f"><span>Voice</span><select id="vName">${options}</select></label>
    <div class="g2">
      <label class="f"><span>Speed ${Number(state.profile.voiceRate).toFixed(2)}</span>
        <input type="range" id="vRate" min="0.7" max="1.3" step="0.02" value="${state.profile.voiceRate}" /></label>
      <label class="f"><span>Pitch ${Number(state.profile.voicePitch).toFixed(2)}</span>
        <input type="range" id="vPitch" min="0.8" max="1.4" step="0.02" value="${state.profile.voicePitch}" /></label>
    </div>
    <div class="row gap wrap">
      <button class="btn sm accent" data-act="voice-test">Sun ke dekho</button>
      <button class="btn sm ghost" data-act="voice-save">Save</button>
      <button class="btn sm ghost" data-act="voice-refresh">Refresh</button>
    </div>
    <div class="how-body mt10">
      <b>Robotic lage to:</b> Android → Settings → Text-to-speech → Google TTS → "Install voice data" → Hindi.
      PC → Edge me kholo (Microsoft Swara/Neera). Phir "Refresh".
    </div>

    <div class="hr-label">Cloud voice — real ladki jaisi</div>
    <label class="f"><span>Provider</span>
      <select id="tProvider">
        <option value="device" ${provider === 'device' ? 'selected' : ''}>Device voice (free)</option>
        <option value="sarvam" ${provider === 'sarvam' ? 'selected' : ''}>Sarvam AI (Hindi best)</option>
        <option value="elevenlabs" ${provider === 'elevenlabs' ? 'selected' : ''}>ElevenLabs (sabse natural)</option>
        <option value="google" ${provider === 'google' ? 'selected' : ''}>Google Cloud TTS</option>
      </select>
    </label>
    <label class="f"><span>API key</span><input type="password" id="tKey" value="${esc(state.profile.ttsKey)}" placeholder="provider ki key" /></label>
    <label class="f"><span>Voice name / id</span>
      <input type="text" id="tVoice" value="${esc(state.profile.ttsVoice)}"
        placeholder="${provider === 'sarvam' ? 'anushka' : provider === 'elevenlabs' ? '21m00Tcm4TlvDq8ikWAM' : 'hi-IN-Neural2-A'}" /></label>
    <div class="row gap wrap">
      <button class="btn sm accent" data-act="cloud-voice-test">Cloud test</button>
      <button class="btn sm ghost" data-act="cloud-voice-save">Save</button>
    </div>
    <div class="tiny muted mt6">Key sirf isi device pe. Fail ho to device voice pe chali jayegi.</div>
  </div>`;
}

/* ---------------- cloud sync ---------------- */
function cloudCardBody() {
  const st = Cloud.status();

  if (!st.ready) {
    const t = ui.cloudTest;
    const testBox = t ? `<div class="test-box ${t.ok ? 'ok' : 'bad'}">${icon(t.ok ? 'check' : 'info')}<span>${esc(t.msg)}</span></div>` : '';
    return `
      <div class="tiny muted mt10" style="line-height:1.6">
        PC aur phone pe <b>ek hi data</b>. Supabase free hai — 3 minute ka kaam.
      </div>

      <details class="how mt10" open>
        <summary>Step 1 · Supabase project banao</summary>
        <div class="how-body">
          1. <b>supabase.com</b> → Start your project (GitHub/Google se login chalega)<br>
          2. <b>New project</b> → naam kuch bhi, region <b>Mumbai / Singapore</b>, password yaad rakho<br>
          3. 2 minute wait — project ban jayega
        </div>
      </details>

      <details class="how">
        <summary>Step 2 · SQL chalao (copy karo)</summary>
        <div class="how-body">
          Supabase me <b>SQL Editor</b> → New query → niche wala poora paste → <b>RUN</b>.
          <textarea id="sqlBox" class="mt10" wrap="off" style="font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:10.5px;line-height:1.6;min-height:170px;white-space:pre;overflow:auto" readonly>${esc(Cloud.SQL)}</textarea>
          <button class="btn sm soft mt10" data-act="cloud-copy-sql">${icon('code')} SQL copy karo</button>
        </div>
      </details>

      <div class="hr-label" style="margin:14px 0 6px">Step 3 · URL aur key paste karo</div>
      <div class="tiny muted" style="line-height:1.6">Supabase → <b>Project Settings → API</b> → <b>Project URL</b> aur <b>anon public</b> key.</div>
      <label class="f mt10"><span>Supabase URL</span><input type="text" id="cUrl" value="${esc(state.profile.supabaseUrl)}" placeholder="https://xxxxx.supabase.co" /></label>
      <label class="f"><span>Supabase anon key</span><input type="password" id="cKey" value="${esc(state.profile.supabaseKey)}" placeholder="eyJhbGciOi..." /></label>
      <div class="tiny muted">Auth → Providers → Email → <b>Confirm email</b> OFF kar dena, warna login nahi hoga.</div>

      <div class="row gap mt10">
        <button class="btn accent" data-act="cloud-config">Save karo</button>
        <button class="btn ghost" data-act="cloud-test">Test karo</button>
      </div>
      ${testBox}`;
  }

  if (!st.signedIn) {
    return `
      <label class="f mt10"><span>Email</span><input type="email" id="cEmail" placeholder="tumhara@email.com" /></label>
      <label class="f"><span>Password</span><input type="password" id="cPass" placeholder="6+ character" /></label>
      <div class="row gap">
        <button class="btn accent" data-act="cloud-login">Login</button>
        <button class="btn ghost" data-act="cloud-signup">Naya account</button>
      </div>
      <div class="row between mt10">
        <span class="tiny muted">${esc(String(state.profile.supabaseUrl).replace(/^https?:\/\//, ''))}</span>
        <button class="btn sm ghost" data-act="cloud-forget">Config badlo</button>
      </div>`;
  }

  const timeTxt = st.at ? new Date(st.at).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '—';
  const stateTxt = st.state === 'syncing' ? 'Sync ho raha hai...'
    : st.state === 'error' ? 'Error: ' + esc(st.err || '')
    : st.state === 'synced' ? 'Synced · ' + timeTxt : 'Login hai';

  return `
    <div class="row between mt10">
      <div style="min-width:0">
        <div class="small" style="font-weight:650">${esc(st.email)}</div>
        <div class="tiny muted">${stateTxt}</div>
      </div>
      <span class="badge ${st.state === 'error' ? 'warn' : 'ok'}">${st.state === 'error' ? 'Error' : 'Cloud'}</span>
    </div>
    <div class="row gap wrap mt10">
      <button class="btn sm soft" data-act="cloud-push">Push</button>
      <button class="btn sm ghost" data-act="cloud-pull">Pull</button>
      <button class="btn sm danger" data-act="cloud-logout">Logout</button>
    </div>
    <div class="tiny muted mt6">Auto-sync on — har change 3 sec baad cloud pe.</div>`;
}

/* ============================================================
   CHAT
   ============================================================ */
function chatHTML() {
  if (!state.chat.length) {
    return `<div class="msg zara">Namaste Aadil! Main Zara hoon.

Poocho: "aaj kya karna hai", "prompt kaise likhu", "paisa kaise kamaun".</div>`;
  }
  return state.chat.slice(-40).map((m) => `<div class="msg ${m.role}">${esc(m.text)}</div>`).join('');
}

const QUICK_Q = ['Aaj kya karna hai?', 'Prompt kaise likhu?', 'Paisa kaise kamaun?', 'English kaise improve karu?', 'Test lo'];
