/* ============================================================
   app.js — boot, router, sab events
   ============================================================ */

/* ---------------- render ---------------- */
function flushInputs() {
  const log = document.getElementById('logArea');
  if (log) todayRec().log = log.value;
  const p = document.getElementById('promptArea');
  if (p) draft.prompt = p.value;
  const e = document.getElementById('englishArea');
  if (e) draft.english = e.value;
  save();
}

const SCREENS = {
  home: vHome,
  plan: vPlan,
  practice: vPractice,
  more: vMore
};

function render() {
  flushInputs();
  const html = (SCREENS[ui.nav] || vHome)();
  document.getElementById('screen').innerHTML = html;

  /* tabbar */
  const navKey = ui.nav;
  document.querySelectorAll('.tab').forEach((t) => {
    t.classList.toggle('on', t.dataset.nav === navKey);
  });

  /* header */
  document.getElementById('logoSub').textContent =
    ui.nav === 'plan'
      ? (ui.mode === '90' ? `90 Din · Day ${day90()}` : `Learning · Month ${currentMonth().m}`)
      : `Day ${day90()} / 90 · Model ${currentMonth().m}`;

  /* english word count live */
  const ta = document.getElementById('englishArea');
  if (ta) {
    ta.addEventListener('input', () => {
      const w = ta.value.trim() ? ta.value.trim().split(/\s+/).length : 0;
      const wc = document.getElementById('wordCount');
      if (wc) { wc.textContent = w + ' words'; wc.style.color = w >= 120 ? 'var(--ok)' : 'var(--text-2)'; }
    });
  }
  /* voice sliders ke live labels */
  const bindSlider = (id, label) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener('input', () => {
      const sp = el.closest('label').querySelector('span');
      if (sp) sp.textContent = label + ' ' + Number(el.value).toFixed(2);
    });
  };
  bindSlider('vRate', 'Speed');
  bindSlider('vPitch', 'Pitch');
}

/* ---------------- Zara chat ---------------- */
function renderChat() {
  const body = document.getElementById('chatBody');
  body.innerHTML = chatHTML();
  body.scrollTop = body.scrollHeight;
  const quick = document.getElementById('chatQuick');
  quick.innerHTML = QUICK_Q.map((q) => `<button class="qchip" data-act="quick" data-q="${esc(q)}">${esc(q)}</button>`).join('');
  document.getElementById('zaraStatus').textContent = state.profile.apiKey
    ? 'AI connected · Hinglish'
    : 'Offline rules · API key daalo to asli AI';
}

function openZara() {
  document.getElementById('zaraSheet').classList.remove('hidden');
  renderChat();
  if (!state.chat.length) {
    setTimeout(() => Zara.speak('Namaste! Main Zara hoon. Poocho kuch bhi.'), 250);
  }
}
function closeZara() {
  document.getElementById('zaraSheet').classList.add('hidden');
  Zara.stopSpeak();
}

function pushMsg(role, text) {
  state.chat.push({ role, text, at: new Date().toISOString() });
  if (state.chat.length > 120) state.chat = state.chat.slice(-120);
  save();
}

async function sendChat(text) {
  const t = String(text || '').trim();
  if (!t) return;
  pushMsg('user', t);
  renderChat();

  const body = document.getElementById('chatBody');
  const typing = document.createElement('div');
  typing.className = 'msg zara typing';
  typing.textContent = 'Zara soch rahi hai...';
  body.appendChild(typing);
  body.scrollTop = body.scrollHeight;

  let answer = null;
  if (state.profile.apiKey) {
    answer = await Zara.askLLM(t);
    if (!answer) {
      answer = Zara.reply(t);
      toast('API se jawab nahi aaya — offline jawab de rahi hoon');
    }
  } else {
    await new Promise((r) => setTimeout(r, 350));
    answer = Zara.reply(t);
  }

  pushMsg('zara', answer);
  renderChat();
  Zara.speak(answer);
}

/* ---------------- tests ---------------- */
function startTest() {
  const pool = QUIZ_BANK.slice();
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  ui.quiz = { list: pool.slice(0, 5), idx: 0, score: 0, answered: null };
  render();

  /* login hai to cloud se latest data lao */
  if (Cloud.auto()) {
    Cloud.pull(true).then((r) => { if (r && r.applied) { render(); toast('Cloud se data aaya'); } });
  }
}

/* ---------------- settings ---------------- */
function saveSettings() {
  const g = (id) => { const el = document.getElementById(id); return el ? el.value : null; };
  state.profile.name = (g('sName') || '').trim();
  state.profile.startDate = g('sStart') || state.profile.startDate;
  state.profile.learnStart = g('sLearn') || state.profile.learnStart;
  state.profile.hoursPerDay = Number(g('sHours')) || 3.5;
  state.profile.usdRate = Number(g('sRate')) || 88;
  state.profile.apiKey = (g('sKey') || '').trim();
  state.profile.apiBase = (g('sBase') || '').trim() || 'https://api.groq.com/openai/v1';
  state.profile.apiModel = (g('sModel') || '').trim() || 'llama-3.1-8b-instant';
  saveNow();
  render();
  toast('Settings save ho gayi');
}

function exportJSON() {
  flushInputs();
  try {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ekraasta-backup-${todayISO()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => { try { URL.revokeObjectURL(url); } catch (e) {} }, 400);
    toast('Backup download ho gaya');
  } catch (e) {
    toast('Download block hua — browser permission do');
  }
}

function importJSON(file) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const p = JSON.parse(reader.result);
      if (!p || !p.profile) throw new Error('bad');
      state = Object.assign(seedState(), p);
      state.profile = Object.assign(seedState().profile, p.profile || {});
      saveNow();
      applyTheme();
      render();
      toast('Data import ho gaya');
    } catch (e) {
      toast('File galat hai — import nahi hua');
    }
  };
  reader.readAsText(file);
}

function printReport() {
  flushInputs();
  const ws = weekStartISO(todayISO());
  const rows = [];
  for (let i = 0; i < 7; i++) {
    const d = addDays(ws, i);
    const rec = state.daily[d];
    rows.push(`<tr><td>${fmtDateFull(d)}</td><td>${blocksDone(rec)}/5</td><td>${(minsDone(rec) / 60).toFixed(1)}</td><td>${esc((rec && rec.log) || '')}</td></tr>`);
  }
  const t90 = t90Stats();
  const lr = learnStats();
  const html = `
    <h2 style="margin:0 0 4px">ekRaasta — Weekly Report</h2>
    <p style="margin:0 0 14px;font-size:12px">${fmtDateFull(ws)} se ${fmtDateFull(addDays(ws, 6))} · Day ${day90()}/90 · Learning Month ${currentMonth().m}</p>
    <table border="1" cellpadding="6" cellspacing="0" style="width:100%;border-collapse:collapse;font-size:12px">
      <tr style="background:#eee"><th>Date</th><th>Blocks</th><th>Ghante</th><th>Log</th></tr>
      ${rows.join('')}
    </table>
    <p style="font-size:12px;margin-top:14px">
      <b>Week total:</b> ${weekHours(ws)} ghante<br>
      <b>90-din track:</b> ${t90.done}/${t90.total} (${t90.pct}%)<br>
      <b>Learning:</b> ${lr.done}/${lr.total} (${lr.pct}%)<br>
      <b>Kamai (ab tak):</b> ${inr(totalEarn())} · <b>Evals:</b> ${state.evals.length} · <b>Projects shipped:</b> ${shippedCount()}
    </p>`;
  let box = document.getElementById('printArea');
  if (!box) {
    box = document.createElement('div');
    box.id = 'printArea';
    document.body.appendChild(box);
  }
  box.innerHTML = html;
  window.print();
}

function resetAll() {
  if (!confirm('Sab data delete ho jayega. Pakka?')) return;
  if (!confirm('Aakhri baar: reset kar dun?')) return;
  try { store.removeItem(STORE_KEY); } catch (e) {}
  state = seedState();
  saveNow();
  applyTheme();
  render();
  toast('Sab reset ho gaya');
}

/* ---------------- events ---------------- */
document.addEventListener('click', async (e) => {
  const closer = e.target.closest('[data-close]');
  if (closer) {
    if (closer.dataset.close === 'zara') closeZara();
    if (closer.dataset.close === 'modal') closeModal();
    return;
  }

  const tab = e.target.closest('.tab');
  if (tab) {
    if (ui.nav !== tab.dataset.nav) window.scrollTo(0, 0);
    ui.nav = tab.dataset.nav;
    ui.more = null;
    render();
    return;
  }

  const el = e.target.closest('[data-act]');
  if (!el) return;
  const a = el.dataset.act;

  switch (a) {
    /* ---- navigation ---- */
    case 'nav': {
      const target = el.dataset.nav;
      ui.nav = (target === 't90' || target === 'learn') ? 'plan' : target;
      if (target === 't90') ui.mode = '90';
      if (target === 'learn') ui.mode = 'learn';
      ui.more = null;
      render();
      window.scrollTo({ top: 0, behavior: 'instant' in document.documentElement.style ? 'instant' : 'auto' });
      break;
    }
    case 'mode':
      ui.mode = el.dataset.mode;
      if (ui.nav !== 'plan' && ui.nav !== 'home') ui.nav = 'plan';
      ui.more = null;
      render();
      if (window.scrollY > 40) window.scrollTo(0, 0);
      break;
    case 'adapted-toggle':
      ui.more = ui.more === 'adapted' ? null : 'adapted';
      render();
      break;
    case 'more':
      ui.more = el.dataset.sub || null; ui.nav = 'more'; render(); window.scrollTo(0, 0); break;
    case 'theme': toggleTheme(); render(); break;
    case 'practice-tab':
      ui.practice = el.dataset.t; ui.promptRes = null; ui.englishRes = null; render(); window.scrollTo(0, 0); break;
    case 'ptrack':
      ui.pTrack = el.dataset.t; render(); break;

    /* ---- daily blocks ---- */
    case 'toggle-block': {
      const rec = todayRec();
      rec.blocks[el.dataset.id] = !rec.blocks[el.dataset.id];
      save();
      const done = blocksDone(rec);
      if (done === DAILY_BLOCKS.length) toast('Sab ho gaya — aaj ka din count hua');
      else if (done === 4) toast('4/5 — streak bach gaya');
      render();
      break;
    }
    case 'save-log': flushInputs(); toast('Log save ho gaya'); break;

    /* ---- 90 din ---- */
    case 'open-phase':
      ui.openPhase = ui.openPhase === el.dataset.id ? null : el.dataset.id;
      render();
      break;
    case 'toggle-t90': {
      const k = el.dataset.key;
      if (state.t90.done[k]) delete state.t90.done[k];
      else state.t90.done[k] = todayISO();
      save(); render();
      break;
    }

    /* ---- learning ---- */
    case 'open-month':
      ui.openMonth = ui.openMonth === Number(el.dataset.m) ? null : Number(el.dataset.m);
      render();
      break;
    case 'toggle-learn': {
      const k = el.dataset.key;
      if (state.learn.done[k]) delete state.learn.done[k];
      else state.learn.done[k] = todayISO();
      save(); render();
      break;
    }

    /* ---- practice: prompt ---- */
    case 'check-prompt': {
      flushInputs();
      ui.promptRes = Zara.promptFeedback(draft.prompt);
      render();
      break;
    }
    case 'prompt-example': {
      const ex = PROMPT_EXAMPLES[0];
      draft.prompt = ex.good;
      ui.promptRes = null;
      render();
      toast('Achha example bhar diya — padho aur badlo');
      break;
    }
    case 'prompt-save': {
      if (!ui.promptRes) { toast('Pehle check karwao'); break; }
      state.prompts.push({ id: uid(), at: todayISO(), text: draft.prompt, score: ui.promptRes.score });
      save(); toast('Prompt practice save ho gaya');
      break;
    }
    case 'speak':
      Zara.speak(el.dataset.text || '');
      break;

    /* ---- practice: english ---- */
    case 'check-english': {
      flushInputs();
      ui.englishRes = Zara.englishFeedback(draft.english);
      render();
      break;
    }
    case 'eval-save': {
      if (!ui.englishRes) { toast('Pehle check karwao'); break; }
      state.evals.push({
        id: uid(), date: todayISO(), topic: 'English eval drill',
        text: draft.english, mistakes: '', score: ui.englishRes.score
      });
      save(); toast('Eval save ho gaya · 30 ka target yaad rakhna');
      break;
    }
    case 'load-samples': {
      draft.english = 'This response is correct but incomplete. It says Python is only used for data science. It should also mention web development and automation. The accuracy is good, but completeness is low. Suggested fix: add two more use cases with a short example. Overall score: 3/5 because one important use case is missing.';
      ui.englishRes = null;
      render();
      break;
    }

    /* ---- practice: tests ---- */
    case 'start-test': startTest(); break;
    case 'answer': {
      if (!ui.quiz || ui.quiz.answered !== null) break;
      ui.quiz.answered = Number(el.dataset.i);
      if (ui.quiz.answered === ui.quiz.list[ui.quiz.idx].a) ui.quiz.score++;
      render();
      break;
    }
    case 'next-q': {
      if (!ui.quiz) break;
      ui.quiz.idx++;
      ui.quiz.answered = null;
      if (ui.quiz.idx >= ui.quiz.list.length) {
        state.tests.push({ at: todayISO(), score: ui.quiz.score });
        save();
      }
      render();
      break;
    }
    case 'end-test': ui.quiz = null; ui.practice = 'prompt'; render(); break;

    /* ---- money ---- */
    case 'add-earn': {
      const amt = Number((document.getElementById('eAmt') || {}).value);
      if (!amt || amt <= 0) { toast('Amount daalo'); break; }
      state.earnings.push({
        id: uid(),
        date: (document.getElementById('eDate') || {}).value || todayISO(),
        platform: (document.getElementById('ePlat') || {}).value || 'Other',
        amount: amt,
        cur: (document.getElementById('eCur') || {}).value || 'INR',
        note: ((document.getElementById('eNote') || {}).value || '').trim()
      });
      save(); render(); toast('Kamai add ho gayi');
      break;
    }
    case 'del-earn':
      state.earnings = state.earnings.filter((x) => x.id !== el.dataset.id);
      save(); render();
      break;

    /* ---- ideas ---- */
    case 'add-idea': {
      const t = ((document.getElementById('ideaArea') || {}).value || '').trim();
      if (!t) { toast('Idea likho'); break; }
      state.ideas.push({ id: uid(), text: t, at: todayISO() });
      save(); render(); toast('Park ho gaya · Day 91 pe khulega');
      break;
    }
    case 'del-idea':
      state.ideas = state.ideas.filter((x) => x.id !== el.dataset.id);
      save(); render();
      break;

    /* ---- weekly ---- */
    case 'save-week': {
      const ws = weekStartISO(todayISO());
      const g = (id) => Number(((document.getElementById(id) || {}).value) || 0);
      const row = weekRow(ws);
      const entry = { week: ws, hours: row.hours, evals: row.evals, rupees: row.rupees, repos: g('wRepos'), outreach: g('wOut'), replies: g('wRep') };
      const i = state.weekly.findIndex((w) => w.week === ws);
      if (i >= 0) state.weekly[i] = entry; else state.weekly.push(entry);
      save(); render(); toast('Scorecard save ho gaya');
      break;
    }

    /* ---- settings ---- */
    case 'save-settings': saveSettings(); break;
    case 'toggle-voice':
      state.profile.voice = !state.profile.voice;
      save(); render();
      toast(state.profile.voice ? 'Zara bol degi' : 'Zara chup rahegi');
      break;
    /* ---- Zara voice ---- */
    case 'voice-test':
      saveVoiceFields();
      if (!state.profile.voiceName) {
        const b = Zara.bestVoice();
        if (b) state.profile.voiceName = b.name;
      }
      state.profile.voice = true;
      saveNow();
      Zara.speak('Namaste Aadil! Main Zara hoon. Aaj ka pehla kaam — Python functions practice. Chalo shuru karein.');
      break;
    case 'voice-save':
      saveVoiceFields(); render(); toast('Awaaz save ho gayi');
      break;
    case 'voice-refresh':
      Zara.loadVoices();
      setTimeout(() => { render(); toast('Voice list update ho gayi'); }, 400);
      break;
    case 'cloud-voice-save':
      saveVoiceFields(); render(); toast('Cloud voice save ho gayi');
      break;
    case 'cloud-voice-test':
      saveVoiceFields();
      Zara.speak('Namaste Aadil! Yeh Zara ki cloud awaaz hai. Sun kar batao — theek lagi?');
      break;

    /* ---- cloud sync ---- */
    case 'cloud-config': {
      const u = (document.getElementById('cUrl') || {}).value || '';
      const k = (document.getElementById('cKey') || {}).value || '';
      if (!/^https?:\/\//.test(u.trim())) { toast('URL https:// se shuru hona chahiye'); break; }
      state.profile.supabaseUrl = u.trim();
      state.profile.supabaseKey = k.trim();
      ui.cloudTest = null;
      saveNow(); render();
      toast('Cloud config save ho gayi — ab Test karo');
      break;
    }
    case 'cloud-test': {
      const uEl = document.getElementById('cUrl');
      const kEl = document.getElementById('cKey');
      const u = uEl ? uEl.value.trim() : state.profile.supabaseUrl;
      const k = kEl ? kEl.value.trim() : state.profile.supabaseKey;
      const prevU = state.profile.supabaseUrl;
      const prevK = state.profile.supabaseKey;
      state.profile.supabaseUrl = u;
      state.profile.supabaseKey = k;
      ui.cloudTest = { ok: true, msg: 'Check kar raha hoon...' };
      render();
      Cloud.test().then((r) => {
        if (r.ok) {
          ui.cloudTest = null;
          saveNow();
          render();
          toast('Connected! Ab email se account banao');
        } else {
          state.profile.supabaseUrl = prevU;
          state.profile.supabaseKey = prevK;
          ui.cloudTest = r;
          render();
        }
      });
      break;
    }
    case 'cloud-copy-sql': {
      const txt = Cloud.SQL || '';
      const done = () => toast('SQL copy ho gaya — Supabase SQL Editor me paste karo');
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(txt).then(done).catch(() => fallback());
      } else fallback();
      function fallback() {
        const box = document.getElementById('sqlBox');
        if (box) { box.removeAttribute('readonly'); box.select(); }
        try { document.execCommand('copy'); done(); } catch (e) { toast('Copy nahi hua — text select karke copy karo'); }
        if (box) box.setAttribute('readonly', 'readonly');
      }
      break;
    }
    case 'cloud-forget':
      state.profile.supabaseUrl = '';
      state.profile.supabaseKey = '';
      Cloud.logout();
      saveNow(); render();
      break;
    case 'cloud-signup':
    case 'cloud-login': {
      const email = ((document.getElementById('cEmail') || {}).value || '').trim();
      const pass = (document.getElementById('cPass') || {}).value || '';
      if (!email || pass.length < 6) { toast('Email aur 6+ character ka password daalo'); break; }
      const btn = el; btn.disabled = true; btn.textContent = 'Ruk jao...';
      try {
        if (a === 'cloud-signup') {
          const r = await Cloud.signup(email, pass);
          if (r.needsConfirm) toast('Account bana — email verify karke phir login karo');
          else { toast('Account ban gaya, login ho gaya'); await Cloud.pull(); }
        } else {
          await Cloud.login(email, pass);
          toast('Login ho gaya');
          await Cloud.pull();
        }
      } catch (e) {
        toast('Nahi hua: ' + (e.message || 'error'));
      }
      render();
      break;
    }
    case 'cloud-push': await Cloud.push(false); render(); break;
    case 'cloud-pull': await Cloud.pull(false); render(); break;
    case 'cloud-logout':
      Cloud.logout(); render(); toast('Logout ho gaya — data is device pe safe hai');
      break;

    /* ---- PWA install ---- */
    case 'install': promptInstall(); break;

    case 'export': exportJSON(); break;
    case 'import': {
      const f = document.getElementById('importFile');
      if (f) f.click();
      break;
    }
    case 'reset': resetAll(); break;
    case 'print': printReport(); break;

    /* ---- zara ---- */
    case 'open-zara': openZara(); break;
    case 'quick': sendChat(el.dataset.q); break;

    default: break;
  }
});

/* input/change events */
document.addEventListener('change', (e) => {
  const el = e.target.closest('[data-act]');
  if (!el) return;
  const a = el.dataset.act;

  if (a === 'proj-status') {
    const p = state.projects.find((x) => x.id === el.dataset.id);
    if (p) { p.status = el.value; save(); render(); }
  }
  if (a === 'proj-link') {
    const p = state.projects.find((x) => x.id === el.dataset.id);
    if (p) { p.link = el.value.trim(); save(); toast('Link save ho gaya'); }
  }
  if (a === 'plat-status') {
    const p = state.platforms.find((x) => x.id === el.dataset.id);
    if (p) { p.status = el.value; save(); render(); }
  }
  if (a === 'plat-due') {
    const p = state.platforms.find((x) => x.id === el.dataset.id);
    if (p) { p.due = el.value; save(); render(); }
  }
  if (a === 'import-file') { /* handled below */ }

  if (e.target.id === 'importFile' && e.target.files && e.target.files[0]) {
    importJSON(e.target.files[0]);
  }
});

document.addEventListener('input', (e) => {
  if (e.target.id === 'promptArea') draft.prompt = e.target.value;
  if (e.target.id === 'englishArea') draft.english = e.target.value;
  if (e.target.id === 'logArea') { todayRec().log = e.target.value; save(); }
});

/* chat form */
document.addEventListener('DOMContentLoaded', () => {});
window.addEventListener('DOMContentLoaded', boot);

function saveVoiceFields() {
  const g = (id) => { const el = document.getElementById(id); return el ? el.value : null; };
  if (g('vName') !== null) state.profile.voiceName = g('vName');
  if (g('vRate') !== null) state.profile.voiceRate = Number(g('vRate')) || 0.98;
  if (g('vPitch') !== null) state.profile.voicePitch = Number(g('vPitch')) || 1.08;
  if (g('tProvider') !== null) state.profile.ttsProvider = g('tProvider');
  if (g('tKey') !== null) state.profile.ttsKey = String(g('tKey')).trim();
  if (g('tVoice') !== null) state.profile.ttsVoice = String(g('tVoice')).trim();
  saveNow();
}

function promptInstall() {
  const ev = window.__installPrompt;
  if (ev) {
    ev.prompt();
    ev.userChoice.then(() => { window.__installPrompt = null; });
    return;
  }
  const ua = navigator.userAgent || '';
  if (/Android/i.test(ua)) toast('Chrome menu (⋮) → "Add to Home screen"');
  else if (/iPhone|iPad/i.test(ua)) toast('Safari → Share → "Add to Home Screen"');
  else toast('Chrome/Edge: address bar ka install icon, ya menu → "Install ekRaasta"');
}

function boot() {
  /* inject print styles */
  const st = document.createElement('style');
  st.textContent = `
    #printArea { display: none; }
    @media print {
      body > *:not(#printArea) { display: none !important; }
      #printArea { display: block !important; padding: 16px; color: #000; background: #fff; }
      body { background: #fff; padding: 0; }
    }`;
  document.head.appendChild(st);

  /* PWA install prompt capture */
  window.addEventListener('beforeinstallprompt', (ev) => {
    ev.preventDefault();
    window.__installPrompt = ev;
  });

  /* service worker (sirf http/https pe) */
  if ('serviceWorker' in navigator && location.protocol.indexOf('http') === 0) {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }

  applyTheme();
  document.getElementById('btnTheme').innerHTML = icon(state.profile.theme === 'dark' ? 'sun' : 'moon');
  document.getElementById('btnSettingsTop').innerHTML = icon('gear');
  const fab = document.getElementById('fabZara');
  if (fab) { fab.innerHTML = icon('zara'); fab.addEventListener('click', openZara); }
  document.getElementById('btnZaraVoice').innerHTML = icon('mic');
  document.getElementById('btnMic').innerHTML = icon('mic');
  if (typeof hydrateIcons === 'function') hydrateIcons();
  document.getElementById('chatForm').querySelector('.send-btn').innerHTML = icon('send');

  document.getElementById('btnTheme').addEventListener('click', () => { toggleTheme(); render(); });
  document.getElementById('btnSettingsTop').addEventListener('click', () => {
    ui.nav = 'more'; ui.more = 'settings'; render();
  });
  document.getElementById('btnZaraVoice').addEventListener('click', () => {
    const last = state.chat.filter((m) => m.role === 'zara').slice(-1)[0];
    if (last) Zara.speak(last.text);
    else toast('Pehle kuch poocho');
  });

  document.getElementById('chatForm').addEventListener('submit', (ev) => {
    ev.preventDefault();
    const inp = document.getElementById('chatText');
    const v = inp.value;
    inp.value = '';
    sendChat(v);
  });

  document.getElementById('btnMic').addEventListener('click', () => {
    Zara.listen(
      (txt) => { sendChat(txt); },
      (err) => toast(err)
    );
    toast('Bolna shuru karo...');
  });

  render();
}
