/* ============================================================
   data.js — saara content ek jagah
   (90-din plan, 12-mahine ka learning roadmap, practice material)
   ============================================================ */

/* ---------- ROZ KE 5 BLOCK (90 + Learning dono) ---------- */
const DAILY_BLOCKS = [
  { id: 'learn',   track: 'learn', title: 'Learning — video + code along', mins: 50, hint: 'Learning tab: is hafte ka topic, saath me code karo' },
  { id: 'build',   track: 'learn', title: 'Learning — project ka kaam',     mins: 50, hint: 'Is month ka project aage badhao' },
  { id: 'cash',    track: '90',    title: 'Paisa — Karya / platform / apply', mins: 40, hint: '90 Din tab: aaj ka cash task' },
  { id: 'english', track: '90',    title: 'Practice — English drill',        mins: 20, hint: 'Practice tab: 150 words feedback' },
  { id: 'log',     track: 'both',  title: 'Log likho',                       mins: 5,  hint: 'Kya banaya · kya atka · kal kya' }
];
const TOTAL_MINS = 165; // 2h 45m core, +30-45 min buffer = ~3.5 ghante

/* ============================================================
   PART 1 — 90 DIN (fixed dates)
   ============================================================ */
const PLAN_90 = [
  {
    id: 'p1', name: 'Foundation + Proof', range: 'Day 1-30',
    goal: 'Skill haath me wapas + dikhane layak proof',
    tasks: [
      {
        t: 'Python basics revise — functions, dict, list, files, try/except',
        how: [
          'Learning tab ka Month 1 kholo — wahi tumhara syllabus hai',
          'Roz 1 topic: functions → dict/list → file I/O → try/except',
          'Har topic pe 3 chhote script likho, GitHub pe push karo'
        ],
        why: 'Interview me Python ka basic compulsory hai.'
      },
      {
        t: '3 working demo banao (chalte hon, sirf code na ho)',
        how: [
          'Demo 1: number guessing game (ban chuka hai — sudharo)',
          'Demo 2: unit converter (ban chuka hai — main() + constants add karo)',
          'Demo 3: naya — expense tracker ya CSV cleaner',
          'Har demo ka README + 60 sec screen recording (Loom free)'
        ],
        why: 'Client/recruiter code nahi, chalta hua cheez dekhta hai.'
      },
      {
        t: 'GitHub profile saaf karo',
        how: [
          'Username professional banao (gamingafzu nahi)',
          'Har repo me README: kya hai, kaise chalayein, kya seekha',
          '4 best repos pin karo, file names me typo check karo'
        ]
      },
      {
        t: 'Portfolio page banao',
        how: ['GitHub Pages pe free — simple HTML', 'Har project: Problem → Solution → Demo → Link'],
        why: 'Ek link bhejna padta hai, 5 link nahi.'
      },
      {
        t: 'Karya app install + profile 100%',
        how: [
          'Play Store: Karya (DAIA Tech)',
          'Profile me Gujarati + Hindi + English teeno language add karo',
          'Task mile to turant karo — pehle 10 task slow, quality pe'
        ],
        why: 'Pehla paisa — English ki zarurat sabse kam.'
      },
      {
        t: 'Roz 1 English eval drill (Practice tab)',
        how: [
          'Zara se ek bad AI answer + rubric maango',
          '150 words me feedback likho — pehle Hindi me socho, phir English',
          'Practice → English me save karo, galtiyan note karo'
        ],
        why: 'Yahi skill Outlier/DataAnnotation me paisa deti hai.'
      }
    ]
  },
  {
    id: 'p2', name: 'Pehla Paisa', range: 'Day 31-60',
    goal: 'Kam se kam ek rupya apne dum pe',
    tasks: [
      {
        t: 'Outlier — multilingual Hindi track apply',
        how: [
          'Generalist English track nahi — multilingual select karo',
          'ID + selfie verification (VPN band)',
          'Assessment ek hi sitting me, jaldi mat karo',
          'Fail ho to 30-90 din baad dusre domain se retry'
        ],
        why: 'Hindi/Gujarati me competition kam hai — yahi tumhara edge.'
      },
      {
        t: '2 local client (Godhra) — ₹3,000-5,000',
        how: [
          '25 dukaan/coaching ki list banao',
          'Offer: "PDF bills se Excel data" ₹500-1,500 (ek shaam ka kaam)',
          'Ya: "WhatsApp enquiry auto-reply" ₹3,000-5,000',
          '50% advance lo — yeh rule kabhi na todo'
        ]
      },
      {
        t: 'Python tuition — 3 students (₹800-1,500 each)',
        how: [
          '10 coaching class pe jao — "aapke students ko Python batch doon"',
          'Hafta me 2 din, 1 ghanta, ghar pe',
          'Pehla demo class free'
        ],
        why: 'Sabse fast cash, aur padhane se apni basics pakki.'
      },
      {
        t: '30 eval drills complete',
        how: ['Roz 1 — Practice tab me save hoga', 'Hafte me galtiyan wali list dobara padho']
      },
      {
        t: '3 testimonial lo (video ya written)',
        how: ['Kaam ke baad turant maango', 'Video 30 sec — "kya kaam hua, kitna time bacha"']
      },
      {
        t: 'Fiverr pe 3 gig live',
        how: [
          '"Fix your Python script in 24h" — $10',
          '"PDF/Excel data to clean Google Sheet" — $10',
          '"Scrape website data to Excel" — $15',
          'Har gig me 40 sec screen recording'
        ]
      }
    ]
  },
  {
    id: 'p3', name: 'Coding Track + Foreign', range: 'Day 61-90',
    goal: 'Rate double + ek foreign client',
    tasks: [
      {
        t: 'Coding track assessment (Outlier / DataAnnotation)',
        how: [
          'Pehle 3 hafte coding practice — GitHub pe doosre ka code padho',
          'Prompt ke constraints 3 baar padho — 40% reject isi wajah se',
          'Pehle bug fix, baad me refactor — refactor boring rakho'
        ],
        why: 'Coding track $22-32/hr deta hai — generalist ka double.'
      },
      {
        t: 'Hafte me 5 proposals (Upwork/Fiverr)',
        how: [
          'Sirf: n8n, Zapier migration, email automation, API integration',
          'Feature list nahi — unke problem ka 60 sec Loom bhejo',
          'Pehle 3-4 job $50-150 me (sirf review ke liye)'
        ]
      },
      {
        t: '1 foreign client ($300+)',
        how: [
          'Roz 20 cold email/DM — business owner ko',
          'Subject: "quick idea for [Business]"',
          '50% advance (Wise/Payoneer) — bina advance kaam nahi'
        ]
      },
      {
        t: 'Portfolio me 4 case studies',
        how: ['Problem → kya banaya → result → demo video', 'Numbers likho: "6 ghante bachaye", "₹X"']
      },
      {
        t: 'Weekly scorecard har Sunday (More tab)',
        how: ['6 number: ghante, repo, eval, outreach, reply, ₹']
      }
    ]
  },
  {
    id: 'p4', name: 'Repeat + Scale', range: 'Day 91-120',
    goal: '90 din khatam — ab repeatable banao',
    tasks: [
      {
        t: '90 din ka review — kya chala, kya nahi',
        how: ['Platform wise paisa dekho', 'Jo channel sabse zyada reply de raha hai — sirf wahi karo']
      },
      {
        t: 'Retainer client banao (monthly ₹1,000-2,000)',
        how: ['Ek baar ka kaam → monthly maintenance me badlo', '2-3 retainer = base income']
      },
      {
        t: 'Naya 90-din cycle: rate 2x',
        how: ['Jo kaam ₹3,000 me kiya, wahi ₹6,000 me becho', 'Case study + testimonial ke saath']
      }
    ]
  }
];

/* ============================================================
   PART 2 — 12 MAHINE LEARNING (flexible, 13 bhi chalega)
   Tumhare hisaab se badla: degree nahi hai, paisa chahiye,
   civil engineer ka context hata diya.
   ============================================================ */
const LEARN_MONTHS = [
  {
    m: 1, title: 'Python Foundations', focus: 'Programming base — sab isi pe khada hai',
    weeks: [
      { w: 'W1', d: 'Python syntax, variables, data types, loops, conditionals' },
      { w: 'W2', d: 'Functions, OOP basics (class/object), error handling, file I/O' },
      { w: 'W3', d: 'Statistics basics — mean/median/mode, std dev, distribution, correlation' },
      { w: 'W4', d: '30+ chhote scripts + mini project' }
    ],
    project: {
      t: 'Python scripts kit + expense tracker',
      steps: ['unit converter (ban chuka)', 'number guessing game (ban chuka)', 'expense tracker (file me save kare)', 'CSV cleaner (duplicate + empty rows hatao)']
    },
    res: [
      { l: 'Python Full Course — CodeWithHarry (Hindi)', u: 'https://youtube.com/playlist?list=PLu0W_9lII9agwh1XjRt242xIpHhPT2llg' },
      { l: '100 Days of Python (Days 1-25) — CampusX', u: 'https://youtube.com/playlist?list=PLKnIA16_Rmvb1RYR-iTA_hzckhdONtSW4' }
    ],
    note: 'Excel/dashboard wala part skip karo — AI engineer ko Excel ka basic kaafi hai. Time Python pe lagao.'
  },
  {
    m: 2, title: 'Pandas / NumPy + Git', focus: 'Data se kaam karna + professional version control',
    weeks: [
      { w: 'W1', d: 'NumPy — arrays, vectorized operations, broadcasting' },
      { w: 'W2', d: 'Pandas — Series/DataFrame, filter, groupby, merge, missing values' },
      { w: 'W3', d: 'Git & GitHub — commit, branch, pull request; Colab/Jupyter workflow' },
      { w: 'W4', d: 'Real dataset pe apply karo + GitHub pe push' }
    ],
    project: {
      t: 'Dataset analysis notebook',
      steps: ['Kaggle se ek dataset lo (sales ya HR)', 'Pandas se clean karo', '3-4 insight likho', 'README ke saath GitHub pe']
    },
    res: [
      { l: '100 Days of Python (Days 26-60) — CampusX', u: 'https://youtube.com/playlist?list=PLKnIA16_Rmvb1RYR-iTA_hzckhdONtSW4' },
      { l: 'Git & GitHub — YouTube pe "Git and GitHub for beginners" search karo', u: 'https://www.youtube.com/results?search_query=git+and+github+for+beginners+hindi' }
    ],
    note: 'Yeh month tumhare liye double kaam ka hai — Pandas wahi skill hai jo freelance me sabse pehle bikti hai (data cleaning).'
  },
  {
    m: 3, title: 'EDA + Visualization', focus: 'Data ko samajhna — jo log skip karte hain aur baad me pachhtate hain',
    weeks: [
      { w: 'W1', d: 'Matplotlib & Seaborn — plots, styling, subplots' },
      { w: 'W2', d: 'EDA process — univariate/bivariate, outliers, missing values' },
      { w: 'W3', d: 'Kaggle dataset pe full EDA' },
      { w: 'W4', d: 'SQL basics shuru (SELECT, WHERE, GROUP BY, JOIN)' }
    ],
    project: {
      t: 'EDA report — portfolio piece #1',
      steps: ['Kaggle dataset chuno (house price ya HR attrition)', '10+ visuals banao', 'Har visual ke saath 2 line insight likho', 'GitHub pe notebook + README']
    },
    res: [
      { l: 'EDA — CampusX (Session 29)', u: 'https://www.youtube.com/live/PPEHpg2RixQ' },
      { l: 'EDA & Feature Engineering — Krish Naik', u: 'https://youtu.be/xhB-dmKmzRk' }
    ],
    note: 'Roadmap me is month 4 hafte the — tumhare liye 3 hafte kaafi hain. Chautha hafta SQL ko de diya, taaki Month 4 halka pade.'
  },
  {
    m: 4, title: 'SQL + FastAPI (early start)', focus: 'Database + apna API banane ki shuruaat',
    weeks: [
      { w: 'W1', d: 'SQL advanced — subqueries, window functions, CTE' },
      { w: 'W2', d: 'SQL project — ek database pe 10 query likho' },
      { w: 'W3', d: 'FastAPI intro — route, request/response, Pydantic validation' },
      { w: 'W4', d: 'Chhota API banao jo Python function ko expose kare' }
    ],
    project: {
      t: 'SQL queries + pehla FastAPI endpoint',
      steps: ['Chinook/Sample DB pe 10 query likho', 'FastAPI me /convert aur /health endpoint banao', 'Local pe chalao, screenshots README me']
    },
    res: [
      { l: 'SQL — YouTube pe "SQL for data science full course" (CampusX)', u: 'https://www.youtube.com/results?search_query=sql+for+data+science+full+course+campusx' },
      { l: 'FastAPI for ML — CampusX', u: 'https://youtube.com/playlist?list=PLKnIA16_RmvZ41tjbKB2ZnwchfniNsMuQ' }
    ],
    note: 'Power BI / Tableau SKIP — woh data analyst ka kaam hai. FastAPI pehle seekho, kyunki API deploy karna = paisa kamane layak banna.'
  },
  {
    m: 5, title: 'Machine Learning Foundations', focus: 'Algorithm samjho, sirf .fit() nahi',
    weeks: [
      { w: 'W1', d: 'Linear & Logistic Regression, cost function, gradient descent' },
      { w: 'W2', d: 'Classification — KNN, Decision Tree, Naive Bayes' },
      { w: 'W3', d: 'Unsupervised — K-Means, PCA; evaluation metrics' },
      { w: 'W4', d: 'End-to-end ML project' }
    ],
    project: {
      t: 'Churn ya house-price prediction — portfolio piece #2',
      steps: ['Raw data → clean → split → train → evaluate', '2 model compare karo', 'Confusion matrix + metrics likho']
    },
    res: [
      { l: '100 Days of Machine Learning — CampusX', u: 'https://youtube.com/playlist?list=PLKnIA16_Rmvbr7zKYQuBfsVkjoLcJgxHH' }
    ],
    note: 'Math ka perfection mat dhoondo. Intuition kaafi hai — interview me "kyun" poochha jaata hai, derivation nahi.'
  },
  {
    m: 6, title: 'Advanced ML + XGBoost', focus: 'Notebook se production-jaisa code',
    weeks: [
      { w: 'W1', d: 'Feature engineering & feature selection' },
      { w: 'W2', d: 'Ensemble — Random Forest, Gradient Boosting, XGBoost' },
      { w: 'W3', d: 'Hyperparameter tuning, cross-validation, overfitting' },
      { w: 'W4', d: 'Clean repo structure — config, tests, folders' }
    ],
    project: {
      t: 'Month 5 project ka v2 — XGBoost ke saath',
      steps: ['Feature engineering lagao', 'XGBoost train karo', 'Cross-validation se compare karo', 'Clean repo structure me push karo']
    },
    res: [
      { l: '100 Days of ML (aage ke modules) — CampusX', u: 'https://youtube.com/playlist?list=PLKnIA16_Rmvbr7zKYQuBfsVkjoLcJgxHH' },
      { l: 'XGBoost tutorial — YouTube search', u: 'https://www.youtube.com/results?search_query=xgboost+tutorial+for+beginners' }
    ]
  },
  {
    m: 7, title: 'Deep Learning', focus: 'Neural network — LLM samajhne ke liye zaroori',
    weeks: [
      { w: 'W1', d: 'Perceptron, activation functions, forward/backward propagation' },
      { w: 'W2', d: 'CNN — image ke liye' },
      { w: 'W3', d: 'RNN/LSTM — sequence ke liye (basics, gehrai nahi)' },
      { w: 'W4', d: 'CNN project train + evaluate karo' }
    ],
    project: {
      t: 'Image classifier (CNN) — portfolio piece #3',
      steps: ['Cats vs dogs ya digit recognition', 'Colab free GPU use karo', 'Accuracy + loss graph README me']
    },
    res: [
      { l: '100 Days of Deep Learning — CampusX', u: 'https://youtube.com/playlist?list=PLKnIA16_RmvYuZauWaPlRTC54KxSNLtNn' }
    ],
    note: 'Roadmap me 4 hafte — tumhare liye 3 kaafi. RNN sirf samajhne ke liye, project CNN hi rakho.'
  },
  {
    m: 8, title: 'Cloud + Docker + Deploy', focus: 'Model ko internet pe live karna',
    weeks: [
      { w: 'W1', d: 'Cloud basics — compute, storage, IAM (GCP/AWS/Azure me farq)' },
      { w: 'W2', d: 'Ek cloud chuno (GCP free tier recommend) + Docker basics' },
      { w: 'W3', d: 'FastAPI me ML model ko serve karo' },
      { w: 'W4', d: 'Cloud pe deploy karo' }
    ],
    project: {
      t: 'Live API — portfolio piece #4 (public link)',
      steps: ['Model ko FastAPI me wrap karo', 'Dockerfile banao', 'GCP Cloud Run ya Railway pe deploy', 'Live URL README me']
    },
    res: [
      { l: 'GCP Zero to Hero — Abhishek Veeramalla', u: 'https://youtu.be/N5rXROueKhw' },
      { l: 'AWS Zero to Hero — Abhishek Veeramalla', u: 'https://youtu.be/GkKNxyLp_V0' },
      { l: 'Azure Zero to Hero — Abhishek Veeramalla', u: 'https://youtu.be/10jm7Waan8M' },
      { l: 'FastAPI for ML — CampusX', u: 'https://youtube.com/playlist?list=PLKnIA16_RmvZ41tjbKB2ZnwchfniNsMuQ' }
    ],
    note: 'Yeh month sabse important hai — deploy karna aana = freelance me paisa. Railway/Render ka free tier bhi chalega.'
  },
  {
    m: 9, title: 'Generative AI + LLM + LangChain', focus: 'Model banane se model ke upar product banane tak',
    weeks: [
      { w: 'W1', d: 'LLM basics — token, context window, text kaise generate hota hai' },
      { w: 'W2', d: 'Prompt engineering — zero-shot, few-shot, structured output' },
      { w: 'W3', d: 'Embeddings & vector representation' },
      { w: 'W4', d: 'LangChain — chain, memory, tool use' }
    ],
    project: {
      t: 'Document summarizer ya Q&A bot — portfolio piece #5',
      steps: ['LangChain + Groq/Gemini free API', 'Ek PDF summarizer banao', 'Streamlit UI lagao']
    },
    res: [
      { l: 'Generative AI using LangChain — CampusX', u: 'https://youtube.com/playlist?list=PLKnIA16_RmvaTbihpo4MtzVm4XOQa0ER0' }
    ],
    note: 'Yahan se tumhari paisa-earning skill shuru hoti hai. Prompt Lab (Practice tab) roz use karo — theory yahan kaam aayegi.'
  },
  {
    m: 10, title: 'RAG Chatbots', focus: 'Sabse zyada demand wala GenAI pattern',
    weeks: [
      { w: 'W1', d: 'RAG theory — retrieval + generation, chunking strategies' },
      { w: 'W2', d: 'Vector DB — FAISS/Chroma/Pinecone, similarity search' },
      { w: 'W3', d: 'Apne PDFs pe full RAG pipeline' },
      { w: 'W4', d: 'FastAPI backend + Streamlit/Gradio UI' }
    ],
    project: {
      t: 'RAG chatbot — portfolio piece #6 (flagship)',
      steps: ['Apne notes/resume/PDFs pe chatbot', 'Citation ke saath answer', '"I don\'t know" handle karo', 'Deploy karke live link lo']
    },
    res: [
      { l: 'Complete RAG Playlist — Krish Naik', u: 'https://youtube.com/playlist?list=PLZoTAELRMXVM8Pf4U67L4UuDRgV4TNX9D' },
      { l: 'FastAPI for ML (backend ke liye) — CampusX', u: 'https://youtube.com/playlist?list=PLKnIA16_RmvZ41tjbKB2ZnwchfniNsMuQ' }
    ],
    note: 'Yeh project tumhare resume ka sabse strong point hoga. Isko 2 hafte extra do agar zarurat ho — 13 mahine chalega to chalega.'
  },
  {
    m: 11, title: 'Agentic AI + MCP + Claude Code', focus: 'Frontier — agent jo tool use karke kaam kare',
    weeks: [
      { w: 'W1', d: 'Agent concepts — planning, memory, tool calling; LangGraph basics' },
      { w: 'W2', d: 'Multi-step agent workflow banao' },
      { w: 'W3', d: 'MCP (Model Context Protocol) — tools/data se connect' },
      { w: 'W4', d: 'Claude Code — AI coding agent se project fast banao' }
    ],
    project: {
      t: 'Agent workflow — portfolio piece #7 (flagship)',
      steps: ['Research agent ya support-ticket triage agent', 'Kam se kam 1 MCP tool connect karo', 'Error handling + cost limit lagao', 'Claude Code se refactor karo']
    },
    res: [
      { l: 'Agentic AI using LangGraph — CampusX', u: 'https://youtube.com/playlist?list=PLKnIA16_RmvYsvB8qkUQuJmJNuiCUJFPL' },
      { l: 'Model Context Protocol — CampusX', u: 'https://youtube.com/playlist?list=PLKnIA16_Rmva_oZ9F4ayUu9qcWgF7Fyc0' },
      { l: 'Claude Code Full Course 12h — Mayank Aggarwal', u: 'https://youtu.be/05aY2LRIC3s' }
    ]
  },
  {
    m: 12, title: 'Capstone + Portfolio + Job', focus: 'Sab jodo, aur naukri/client ke liye ready ho jao',
    weeks: [
      { w: 'W1', d: '1-2 capstone chuno (ML + GenAI + Cloud + FastAPI)' },
      { w: 'W2', d: 'Saare repos polish — README, docs, tests, structure' },
      { w: 'W3', d: 'Portfolio website + 3-4 LinkedIn posts' },
      { w: 'W4', d: 'Resume, mock interview, applications shuru' }
    ],
    project: {
      t: '3 flagship projects live',
      steps: ['ML model deployment (live API)', 'RAG chatbot (live)', 'Agentic workflow (live)', 'Sab ka link ek portfolio page pe']
    },
    res: [
      { l: 'Interview 150 Questions (tumhari PDF)', u: '' },
      { l: 'AI System Design Playbook (tumhari PDF)', u: '' },
      { l: 'Resume sample (tumhari PDF) — apna banao, copy nahi', u: '' }
    ],
    note: 'Yahan tak 12 mahine, par 13 ya 14 lage to koi problem nahi — yeh deadline nahi, direction hai. Roz 50 min = aage badhna.'
  },
  {
    m: 13, title: 'Buffer Month (agar zarurat pade)', focus: 'Jo reh gaya wo pakka karo — koi naya topic nahi',
    weeks: [
      { w: 'W1', d: 'Jo month adhoora chhoot gaya — wahi dobara' },
      { w: 'W2', d: 'Sabse kamzor 1 topic deep karo' },
      { w: 'W3', d: 'Interview questions practice (150 PDF)' },
      { w: 'W4', d: 'Applications + freelance proposals roz' }
    ],
    project: { t: 'Koi naya project nahi', steps: ['Purane project polish karo', 'Ek project me tests + docs add karo'] },
    res: [],
    note: 'Yeh month optional hai. Agar 12 me ho gaya to seedha job/freelance pe jao.'
  }
];

/* ============================================================
   PLAYGROUND — PROMPT FRAMEWORK (Zara sikhayegi)
   ============================================================ */
const PROMPT_PARTS = [
  { key: 'role',      name: 'Role',       desc: 'AI ko batao wo kaun hai', ex: 'Tum ek senior Python teacher ho.' },
  { key: 'task',      name: 'Task',       desc: 'Ek hi kaam, saaf shabdon me', ex: 'Mujhe yeh code samjhao aur bug batao.' },
  { key: 'context',   name: 'Context',    desc: 'Background — kya, kyun, kis ke liye', ex: 'Main beginner hoon, 11th pass, English kamzor.' },
  { key: 'format',    name: 'Format',     desc: 'Output kaisa chahiye', ex: 'Table me: bug, kyun, fix.' },
  { key: 'constraint',name: 'Constraint', desc: 'Limit aur rules', ex: 'Hinglish me. 150 words max. Sirf 3 bugs.' }
];

const PROMPT_EXAMPLES = [
  {
    bad: 'python code fix karo',
    good: 'Tum ek senior Python developer ho. Neeche diye code me bug dhundo. Main beginner hoon, isliye simple bhasha me samjhao. Output table me do: (1) bug kahan hai, (2) kyun problem hai, (3) fix kaise karna hai. Sirf 3 sabse badi galtiyan batao. Hinglish me likho. Code: [yahan paste]',
    why: 'Role + Task + Context + Format + Constraint — paanchon hai. Isliye answer usable aata hai.'
  },
  {
    bad: 'make my english good',
    good: 'Tum ek English teacher ho jo Hinglish bolne wale students ko padhata hai. Meri neeche 150-word writing check karo. Sirf grammar galtiyan batao — text ko rewrite mat karo. Output: table me "galti | rule | kaise theek karein". Maximum 5 galtiyan. Simple English me samjhao, difficult words mat use karo.',
    why: '"Rewrite mat karo" — yeh constraint hi asli kaam karta hai.'
  }
];

const ENGLISH_TEMPLATES = [
  { g: 'Accuracy', items: [
    'This statement is factually correct.',
    'This statement is incorrect. The correct value is ___ .',
    'I cannot verify this claim, so I will not score it as accurate.',
    'The response contains a hallucination: it states ___ , which is not true.'
  ]},
  { g: 'Completeness', items: [
    'The response is correct but incomplete. It should also mention ___ .',
    'It does not answer the second part of the user\'s question.',
    'No example is given, which makes the answer harder to follow.'
  ]},
  { g: 'Instruction-following', items: [
    'The response ignores the constraint: "___" .',
    'The user asked for JSON, but the response returns a Python dictionary.',
    'The response follows all stated constraints.'
  ]},
  { g: 'Clarity / tone', items: [
    'The explanation is correct but poorly organized. The steps should be in order.',
    'The tone is appropriate for the target audience.'
  ]},
  { g: 'Suggested fix', items: [
    'Suggested fix: add a short example after the definition.',
    'Minimal edit required: change ___ to ___ .',
    'Overall score: 3/5. Reason: correct but incomplete, and one constraint was missed.'
  ]}
];

/* ---------- MCQ BANK (Practice → Tests) ---------- */
const QUIZ_BANK = [
  {
    q: 'Prompt ka kaunsa part missing hai: "Mujhe Python seekhna hai, batao"?',
    o: ['Role', 'Context aur Format dono', 'Kuch missing nahi', 'Sirf title'],
    a: 1,
    e: 'Kaun ho, kis level pe ho (context) aur output kaisa chahiye (format) — dono missing hain. Isliye jawab general aayega.'
  },
  {
    q: 'LLM "hallucination" kya hoti hai?',
    o: ['Model slow chalna', 'Model galat ya bana hua fact confidence se bolna', 'API band ho jana', 'Token khatam hona'],
    a: 1,
    e: 'Hallucination = model aisi baat bol de jo sach nahi hai, par confident lage. RAG isi ko kam karta hai.'
  },
  {
    q: 'RAG me "R" ka matlab?',
    o: ['Random', 'Retrieval', 'React', 'Repeat'],
    a: 1,
    e: 'Retrieval-Augmented Generation — pehle apne data me se relevant hissa dhoondo, phir LLM se jawab banao.'
  },
  {
    q: 'Eval me sabse zaroori cheez kya hai?',
    o: ['Lambe jawab', 'Rubric aur consistent scoring', 'Tez type karna', 'Zyada adjectives'],
    a: 1,
    e: 'Rubric pehle padho, har criterion alag score karo. Consistency hi paisa deti hai.'
  },
  {
    q: 'Good prompt ka sabse bada dushman kya hai?',
    o: ['Constraint dena', 'Ek message me 5 alag kaam maangna', 'Format batana', 'Example dena'],
    a: 1,
    e: 'Ek prompt = ek kaam. Multiple kaam maango to output adhoora aata hai.'
  },
  {
    q: 'Coding assessment me sabse zyada reject kis wajah se hote hain?',
    o: ['Code slow likhna', 'Prompt me diya constraint miss karna', 'Comment likhna', 'Test chalana'],
    a: 1,
    e: '40% reject "missed a stated constraint" se hote hain — jaldi padhne ki wajah se.'
  },
  {
    q: '"Rewrite mat karo, sirf galtiyan batao" — yeh prompt ka kaunsa part hai?',
    o: ['Role', 'Constraint', 'Context', 'Title'],
    a: 1,
    e: 'Constraint = limit/rules. Yahi line output ko control karti hai.'
  },
  {
    q: 'Vector database ka kaam kya hai?',
    o: ['Text ko design karna', 'Similarity search — matlab jaisa matlab waisa dhoondhna', 'Database ko slow karna', 'Model train karna'],
    a: 1,
    e: 'Embedding ke vectors me nearest match dhoondhta hai — RAG ka retrieval step.'
  },
  {
    q: 'Agent aur normal chatbot me farq?',
    o: ['Agent zyada colorful hota hai', 'Agent tool use karke multi-step kaam karta hai', 'Kuch farq nahi', 'Agent sirf English bolta hai'],
    a: 1,
    e: 'Agent plan banata hai, tool call karta hai, result dekhke agla step leta hai.'
  },
  {
    q: 'Eval feedback me "This is good" kyun reject hota hai?',
    o: ['Bahut lamba hai', 'Specific nahi — kya, kahan, kyun missing hai', 'Grammar galat hai', 'English me hai'],
    a: 1,
    e: 'Vague feedback = reject. Sentence quote karo aur exact problem likho.'
  },
  {
    q: 'Zero-shot prompt kya hai?',
    o: ['Bina example diye instruction', 'Zero degree temperature', 'Bina API key', 'Chhota prompt'],
    a: 0,
    e: 'Zero-shot = koi example nahi. Few-shot = 1-3 example diye.'
  },
  {
    q: 'Tumhe LLM se JSON output chahiye. Sabse safe tarika?',
    o: ['"JSON do" likhna', 'Schema example ke saath format specify karna', 'Model ka naam badalna', 'Lambe prompt'],
    a: 1,
    e: 'Expected JSON ka exact shape dikhao + "sirf JSON, koi text nahi" constraint lagao.'
  },
  {
    q: 'Karya jaisa platform kis cheez ka paisa deta hai?',
    o: ['Code likhne ka', 'Native language me AI training data (voice/text)', 'Design ka', 'Marketing ka'],
    a: 1,
    e: 'Hindi/Gujarati voice aur text data — isliye English ki zarurat kam.'
  },
  {
    q: 'Freelance me 50% advance kyun zaroori hai?',
    o: ['Client ko impress karne ke liye', 'Kaam ke baad paisa na milne ka risk kam karne ke liye', 'Tax ke liye', 'Zaroori nahi'],
    a: 1,
    e: 'Bina advance bada kaam = risk. Advance = commitment ka proof.'
  },
  {
    q: '"I don\'t know" handling RAG me kyun zaroori hai?',
    o: ['Model ko aaram chahiye', 'Data me jawab na ho to hallucination rokta hai', 'Speed badhata hai', 'Zaroori nahi'],
    a: 1,
    e: 'Agar retrieval me jawab nahi mila to LLM ko "nahi pata" bolna chahiye — warna bana dega.'
  }
];
