/* ============================================================
   cloud.js — Supabase login + multi-device sync
   SDK nahi — seedha REST API (fetch). Isliye kuch install nahi karna.

   Kaam:
   - signup / login / logout (email + password)
   - push: local state -> Supabase (user_state table)
   - pull: Supabase -> local state (agar remote naya ho)
   - auto: save hone pe 3 sec baad apne aap push

   Security: har user ka data alag (Row Level Security SQL README me hai).
   API key (Groq) aur Supabase key cloud pe kabhi nahi jaate.
   ============================================================ */

/* Supabase me ek baar chalane wala SQL — app ke andar se copy kar sakte ho */
const CLOUD_SQL = `-- ekRaasta cloud sync: Supabase > SQL Editor me paste karke RUN
create table if not exists public.user_state (
  user_id uuid primary key references auth.users on delete cascade,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.user_state enable row level security;

drop policy if exists "own rows read"   on public.user_state;
drop policy if exists "own rows insert" on public.user_state;
drop policy if exists "own rows update" on public.user_state;

create policy "own rows read"   on public.user_state for select using (auth.uid() = user_id);
create policy "own rows insert" on public.user_state for insert with check (auth.uid() = user_id);
create policy "own rows update" on public.user_state for update using (auth.uid() = user_id) with check (auth.uid() = user_id);`;

const Cloud = (function () {
  const SS = 'ekraasta_cloud_session';
  let pushTimer = null;
  let busy = false;
  let lastStatus = '';   // '', 'syncing', 'synced', 'error'
  let lastAt = 0;
  let lastErr = '';

  function cfg() {
    return {
      url: String(state.profile.supabaseUrl || '').replace(/\/+$/, ''),
      key: String(state.profile.supabaseKey || '').trim()
    };
  }
  function ready() {
    const c = cfg();
    return !!(c.url && c.key);
  }
  function session() {
    try { return JSON.parse(store.getItem(SS) || 'null'); } catch (e) { return null; }
  }
  function setSession(s) {
    try {
      if (s) store.setItem(SS, JSON.stringify(s));
      else store.removeItem(SS);
    } catch (e) {}
  }
  function signedIn() {
    const s = session();
    return !!(s && s.access && s.refresh);
  }
  function userEmail() {
    const s = session();
    return s && s.email ? s.email : '';
  }
  function status() {
    return { ready: ready(), signedIn: signedIn(), email: userEmail(), state: lastStatus, at: lastAt, err: lastErr };
  }
  function auto() { return ready() && signedIn(); }

  function jwtSub(token) {
    try {
      const part = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
      const json = decodeURIComponent(escape(window.atob(part)));
      const obj = JSON.parse(json);
      return obj.sub || (obj.user_id || null);
    } catch (e) { return null; }
  }

  function headers(extra) {
    const c = cfg();
    const s = session();
    const h = Object.assign({
      'apikey': c.key,
      'Content-Type': 'application/json'
    }, extra || {});
    if (s && s.access) h['Authorization'] = 'Bearer ' + s.access;
    return h;
  }

  async function authFetch(path, body) {
    const c = cfg();
    const res = await fetch(c.url + path, { method: 'POST', headers: headers(), body: JSON.stringify(body) });
    const text = await res.text();
    let data = {};
    try { data = text ? JSON.parse(text) : {}; } catch (e) { data = { raw: text }; }
    if (!res.ok) {
      const msg = data.error_description || data.msg || data.message || data.error || ('HTTP ' + res.status);
      throw new Error(msg);
    }
    return data;
  }

  function remember(data, email) {
    const now = Date.now();
    const s = {
      access: data.access_token,
      refresh: data.refresh_token,
      expires: now + ((data.expires_in || 3600) * 1000),
      email: email || (data.user && data.user.email) || ''
    };
    setSession(s);
    return s;
  }

  async function signup(email, password) {
    if (!ready()) throw new Error('Pehle Supabase URL aur key save karo');
    const data = await authFetch('/auth/v1/signup', { email, password });
    if (data.access_token) { remember(data, email); return { ok: true, needsConfirm: false }; }
    return { ok: true, needsConfirm: true };
  }

  async function login(email, password) {
    if (!ready()) throw new Error('Pehle Supabase URL aur key save karo');
    const data = await authFetch('/auth/v1/token?grant_type=password', { email, password });
    remember(data, email);
    return { ok: true };
  }

  async function refreshSession() {
    const s = session();
    if (!s || !s.refresh) return false;
    const c = cfg();
    try {
      const res = await fetch(c.url + '/auth/v1/token?grant_type=refresh_token', {
        method: 'POST',
        headers: { 'apikey': c.key, 'Content-Type': 'application/json' },
        body: JSON.stringify({ refresh_token: s.refresh })
      });
      if (!res.ok) return false;
      const data = await res.json();
      remember(data, s.email);
      return true;
    } catch (e) { return false; }
  }

  async function ensureToken() {
    const s = session();
    if (!s) return false;
    if (Date.now() < (s.expires - 60000)) return true;
    return await refreshSession();
  }

  function logout() {
    setSession(null);
    lastStatus = '';
  }

  /* -------- push -------- */
  async function push(silent) {
    if (!auto()) return false;
    if (busy) return false;
    busy = true; lastStatus = 'syncing';
    try {
      if (!(await ensureToken())) throw new Error('Session expire — dobara login karo');
      const s = session();
      const uid = jwtSub(s.access);
      if (!uid) throw new Error('User id nahi mila — dobara login karo');

      /* sensitive local-only fields hata ke bhejo */
      const payload = JSON.parse(JSON.stringify(state));
      delete payload.profile.apiKey;
      delete payload.profile.supabaseKey;
      delete payload.profile.supabaseUrl;
      delete payload.profile.supabaseAnon;
      payload.updatedAt = Date.now();

      const c = cfg();
      const res = await fetch(c.url + '/rest/v1/user_state', {
        method: 'POST',
        headers: headers({
          'Prefer': 'resolution=merge-duplicates,return=minimal'
        }),
        body: JSON.stringify({
          user_id: uid,
          data: payload,
          updated_at: new Date().toISOString()
        })
      });
      if (!res.ok) {
        const t = await res.text();
        throw new Error(t.slice(0, 160) || ('HTTP ' + res.status));
      }
      lastStatus = 'synced'; lastAt = Date.now(); lastErr = '';
      if (!silent && typeof toast === 'function') toast('Cloud pe save ho gaya');
      return true;
    } catch (e) {
      lastStatus = 'error'; lastErr = e.message || 'push fail';
      if (!silent && typeof toast === 'function') toast('Sync fail: ' + lastErr);
      return false;
    } finally {
      busy = false;
    }
  }

  function pushSoon() {
    if (!auto()) return;
    clearTimeout(pushTimer);
    pushTimer = setTimeout(() => push(true), 3000);
  }

  /* -------- pull -------- */
  async function pull(silent) {
    if (!auto()) return { ok: false, reason: 'signed-out' };
    lastStatus = 'syncing';
    try {
      if (!(await ensureToken())) throw new Error('Session expire — dobara login karo');
      const s = session();
      const uid = jwtSub(s.access);
      const c = cfg();
      const res = await fetch(c.url + '/rest/v1/user_state?user_id=eq.' + uid + '&select=data,updated_at', {
        headers: headers()
      });
      if (!res.ok) {
        const t = await res.text();
        throw new Error(t.slice(0, 160) || ('HTTP ' + res.status));
      }
      const rows = await res.json();
      if (!rows.length) {
        /* cloud khaali — pehla device: local data chadha do */
        lastStatus = 'synced'; lastAt = Date.now();
        await push(true);
        return { ok: true, applied: false, reason: 'cloud-empty' };
      }

      const row = rows[0];
      const remote = row.data || {};
      const remoteAt = new Date(row.updated_at).getTime() || 0;
      const localAt = Number(state.updatedAt) || 0;

      if (remoteAt > localAt + 1500) {
        applyRemote(remote);
        lastStatus = 'synced'; lastAt = Date.now(); lastErr = '';
        if (!silent && typeof toast === 'function') toast('Cloud se latest data aa gaya');
        return { ok: true, applied: true };
      }

      lastStatus = 'synced'; lastAt = Date.now();
      await push(true);
      return { ok: true, applied: false };
    } catch (e) {
      lastStatus = 'error'; lastErr = e.message || 'pull fail';
      if (!silent && typeof toast === 'function') toast('Pull fail: ' + lastErr);
      return { ok: false, error: lastErr };
    }
  }


  /* ---- connection test (URL + key sahi hai ya nahi) ---- */
  async function test() {
    const c = cfg();
    if (!c.url || !c.key) return { ok: false, msg: 'URL ya key khaali hai' };
    if (!/^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(c.url)) {
      return { ok: false, msg: 'URL aisa hona chahiye: https://xxxxx.supabase.co' };
    }
    try {
      const res = await fetch(c.url + '/rest/v1/user_state?select=user_id&limit=1', {
        headers: { apikey: c.key, Authorization: 'Bearer ' + c.key }
      });
      if (res.status === 404) {
        return { ok: false, code: 404, msg: 'Project mil gaya, par table "user_state" nahi hai — SQL chalao' };
      }
      if (res.status === 401 || res.status === 403) {
        return { ok: false, code: res.status, msg: 'Key galat hai — Settings → API se "anon public" key copy karo' };
      }
      if (!res.ok) {
        const t = await res.text();
        return { ok: false, code: res.status, msg: (t || 'HTTP ' + res.status).slice(0, 160) };
      }
      return { ok: true, msg: 'Connected — table bhi mil gaya' };
    } catch (e) {
      return { ok: false, msg: 'Internet/URL problem: ' + (e.message || 'fetch fail') };
    }
  }

  function applyRemote(remote) {
    const localSecrets = {
      apiKey: state.profile.apiKey,
      supabaseUrl: state.profile.supabaseUrl,
      supabaseKey: state.profile.supabaseKey
    };
    const base = seedState();
    const merged = Object.assign(base, remote);
    merged.profile = Object.assign(base.profile, remote.profile || {});
    merged.profile.apiKey = localSecrets.apiKey || '';
    merged.profile.supabaseUrl = localSecrets.supabaseUrl || '';
    merged.profile.supabaseKey = localSecrets.supabaseKey || '';
    merged.profile.theme = state.profile.theme;
    state = merged;
    saveNow();
    if (typeof applyTheme === 'function') applyTheme();
    if (typeof render === 'function') render();
  }

  return {
    ready, signedIn, userEmail, status, auto,
    signup, login, logout, push, pull, pushSoon, applyRemote, test, SQL: CLOUD_SQL
  };
})();
