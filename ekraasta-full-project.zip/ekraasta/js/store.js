/* ============================================================
   store.js — data layer
   Sab kuch localStorage me. Koi backend nahi, koi external call nahi.
   ============================================================ */

const STORE_KEY = 'ekraasta_v2';

/* localStorage band ho (iframe/private mode) to memory fallback */
const store = (function () {
  try {
    localStorage.setItem('__t', '1');
    localStorage.removeItem('__t');
    return localStorage;
  } catch (e) {
    const mem = {};
    return {
      getItem: (k) => (k in mem ? mem[k] : null),
      setItem: (k, v) => { mem[k] = String(v); },
      removeItem: (k) => { delete mem[k]; }
    };
  }
})();

/* ---------------- date helpers ---------------- */
const pad2 = (n) => String(n).padStart(2, '0');

function todayISO() {
  const d = new Date();
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}
function isoOf(d) { return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`; }
function parseISO(iso) {
  const p = String(iso || '').split('-').map(Number);
  return new Date(p[0], (p[1] || 1) - 1, p[2] || 1);
}
function addDays(iso, n) {
  const d = parseISO(iso); d.setDate(d.getDate() + n); return isoOf(d);
}
function daysBetween(a, b) { return Math.round((parseISO(b) - parseISO(a)) / 86400000); }
function weekStartISO(iso) {
  const d = parseISO(iso);
  const shift = (d.getDay() + 6) % 7;
  d.setDate(d.getDate() - shift);
  return isoOf(d);
}
const MONTH_SHORT = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
function fmtDate(iso) {
  if (!iso) return '';
  const d = parseISO(iso);
  return `${d.getDate()} ${MONTH_SHORT[d.getMonth()]}`;
}
function fmtDateFull(iso) {
  if (!iso) return '';
  const d = parseISO(iso);
  return `${d.getDate()} ${MONTH_SHORT[d.getMonth()]} ${d.getFullYear()}`;
}
function uid() { return Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-3); }

/* ---------------- seed ---------------- */
function seedState() {
  const today = todayISO();
  return {
    v: 2,
    profile: {
      name: 'Aadil',
      startDate: today,          // 90-din ka Day 1
      learnStart: today,         // learning track ka start
      theme: 'dark',
      uiV: 6,
      hoursPerDay: 3.5,
      usdRate: 88,
      apiKey: '',
      apiBase: 'https://api.groq.com/openai/v1',
      apiModel: 'llama-3.1-8b-instant',
      voice: true,
      voiceName: '',
      voiceRate: 0.98,
      voicePitch: 1.08,
      ttsProvider: 'device',
      ttsKey: '',
      ttsVoice: '',
      supabaseUrl: '',
      supabaseKey: ''
    },
    daily: {},                   // date -> { blocks:{}, log }
    t90: { done: {} },           // taskKey -> iso date
    learn: { done: {}, open: 1 },// key: m1-w1, m1-proj
    projects: [
      { id: uid(), name: 'Number Guessing Game', status: 'done', tags: ['loops','random','try/except'], link: 'https://github.com/your-github-username/build-01-number-guessing-game' },
      { id: uid(), name: 'Unit Converter', status: 'done', tags: ['functions','validation'], link: 'https://github.com/your-github-username/build-02-unit-converter' },
      { id: uid(), name: 'Expense Tracker (file save)', status: 'todo', tags: ['file I/O','json'], link: '' },
      { id: uid(), name: 'CSV / Excel Cleaner', status: 'todo', tags: ['pandas'], link: '' },
      { id: uid(), name: 'Dataset Analysis Notebook', status: 'todo', tags: ['pandas','eda'], link: '' },
      { id: uid(), name: 'Churn / Price Prediction', status: 'todo', tags: ['sklearn'], link: '' },
      { id: uid(), name: 'Live FastAPI Deployment', status: 'todo', tags: ['fastapi','cloud'], link: '' },
      { id: uid(), name: 'RAG Chatbot (flagship)', status: 'todo', tags: ['rag','vector db'], link: '' },
      { id: uid(), name: 'Agent Workflow (flagship)', status: 'todo', tags: ['langgraph','mcp'], link: '' }
    ],
    evals: [],
    prompts: [],
    tests: [],
    earnings: [],
    platforms: [
      { id: uid(), name: 'Karya', status: 'start', rate: '$5/hr', next: 'App install + profile 100%', due: today, notes: 'Pehla paisa. UPI me aata hai.' },
      { id: uid(), name: 'Outlier (Hindi multilingual)', status: 'later', rate: '$15-24/hr', next: '2-3 hafte baad apply', due: addDays(today, 21), notes: 'Generalist nahi — multilingual track.' },
      { id: uid(), name: 'Stellar AI', status: 'later', rate: '$18-25/hr', next: 'Outlier ke baad', due: addDays(today, 30), notes: '' },
      { id: uid(), name: 'Mindrift', status: 'later', rate: 'varies', next: 'Backup', due: addDays(today, 30), notes: '' },
      { id: uid(), name: 'Mercor', status: 'later', rate: '$20-75/hr', next: '2 mahine baad (video interview)', due: addDays(today, 60), notes: 'Bolne ki English chahiye.' },
      { id: uid(), name: 'DataAnnotation', status: 'later', rate: '$22-32/hr', next: '2 mahine baad — SIRF 1 attempt', due: addDays(today, 60), notes: 'Starter assessment retake nahi.' },
      { id: uid(), name: 'Alignerr', status: 'later', rate: 'varies', next: 'Low priority', due: '', notes: 'Join aasan, kaam mushkil.' }
    ],
    ideas: [],
    weekly: [],
    chat: [],
    updatedAt: 0
  };
}

/* ---------------- state load/save ---------------- */
let state = loadState();

function loadState() {
  const base = seedState();
  try {
    const raw = store.getItem(STORE_KEY);
    if (!raw) return base;
    const p = JSON.parse(raw);
    const merged = Object.assign(base, p);
    merged.profile = Object.assign(base.profile, p.profile || {});
    merged.t90 = Object.assign(base.t90, p.t90 || {});
    merged.learn = Object.assign(base.learn, p.learn || {});
    if (!Array.isArray(merged.projects) || !merged.projects.length) merged.projects = base.projects;
    if (!merged.profile.name) merged.profile.name = 'Aadil';
    /* v4: naya dark palette — purane users ko bhi ek baar dark pe le aao */
    if (merged.profile.uiV !== 6) {
      merged.profile.uiV = 6;
      merged.profile.theme = 'dark';
    }
    return merged;
  } catch (e) {
    return base;
  }
}

let saveTimer = null;
function save() {
  state.updatedAt = Date.now();
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try { store.setItem(STORE_KEY, JSON.stringify(state)); } catch (e) {}
  }, 60);
  /* cloud sync — agar login hai to 3 sec baad apne aap push */
  try {
    if (typeof Cloud !== 'undefined' && Cloud.auto()) Cloud.pushSoon();
  } catch (e) {}
}
function saveNow() {
  clearTimeout(saveTimer);
  try { store.setItem(STORE_KEY, JSON.stringify(state)); } catch (e) {}
}

/* ---------------- derived data ---------------- */
function day90() {
  const diff = daysBetween(state.profile.startDate, todayISO());
  return Math.min(Math.max(diff + 1, 1), 999);
}
function learnDay() {
  return Math.max(1, daysBetween(state.profile.learnStart, todayISO()) + 1);
}
function todayRec() {
  const t = todayISO();
  if (!state.daily[t]) state.daily[t] = { blocks: {}, log: '' };
  if (!state.daily[t].blocks) state.daily[t].blocks = {};
  return state.daily[t];
}
function blocksDone(rec) {
  if (!rec || !rec.blocks) return 0;
  return DAILY_BLOCKS.filter((b) => rec.blocks[b.id]).length;
}
function minsDone(rec) {
  if (!rec || !rec.blocks) return 0;
  return DAILY_BLOCKS.reduce((s, b) => s + (rec.blocks[b.id] ? b.mins : 0), 0);
}
function streak() {
  let n = 0;
  let cursor = todayISO();
  if (blocksDone(state.daily[cursor]) < 4) cursor = addDays(cursor, -1);
  for (let i = 0; i < 500; i++) {
    if (blocksDone(state.daily[cursor]) >= 4) { n++; cursor = addDays(cursor, -1); }
    else break;
  }
  return n;
}
function weekHours(ws) {
  let total = 0;
  for (let i = 0; i < 7; i++) total += minsDone(state.daily[addDays(ws, i)]) / 60;
  return Math.round(total * 10) / 10;
}
function toINR(amount, cur) {
  const n = Number(amount) || 0;
  return cur === 'USD' ? Math.round(n * (Number(state.profile.usdRate) || 88)) : n;
}
function inr(n) { return '₹' + (Math.round(Number(n) || 0)).toLocaleString('en-IN'); }

/* 90-din progress */
function t90Stats() {
  let total = 0, done = 0;
  PLAN_90.forEach((ph) => ph.tasks.forEach((t, i) => { total++; if (state.t90.done[ph.id + '-' + i]) done++; }));
  return { total, done, pct: total ? Math.round((done / total) * 100) : 0 };
}
function phaseStats(ph) {
  let done = 0;
  ph.tasks.forEach((t, i) => { if (state.t90.done[ph.id + '-' + i]) done++; });
  return { done, total: ph.tasks.length };
}
/* learning progress */
function learnStats() {
  let total = 0, done = 0;
  LEARN_MONTHS.forEach((mo) => {
    mo.weeks.forEach((w) => { total++; if (state.learn.done['m' + mo.m + '-' + w.w]) done++; });
    total++; if (state.learn.done['m' + mo.m + '-proj']) done++;
  });
  return { total, done, pct: total ? Math.round((done / total) * 100) : 0 };
}
function monthStats(mo) {
  let total = 0, done = 0;
  mo.weeks.forEach((w) => { total++; if (state.learn.done['m' + mo.m + '-' + w.w]) done++; });
  total++; if (state.learn.done['m' + mo.m + '-proj']) done++;
  return { done, total };
}
function currentMonth() {
  const mo = LEARN_MONTHS.filter((x) => monthStats(x).done < monthStats(x).total);
  return mo.length ? mo[0] : LEARN_MONTHS[LEARN_MONTHS.length - 1];
}
function shippedCount() { return state.projects.filter((p) => p.status === 'done').length; }
function monthEarn() {
  const mk = todayISO().slice(0, 7);
  return state.earnings.filter((e) => String(e.date).slice(0, 7) === mk).reduce((s, e) => s + toINR(e.amount, e.cur), 0);
}
function totalEarn() { return state.earnings.reduce((s, e) => s + toINR(e.amount, e.cur), 0); }

/* weekly scorecard row */
function weekRow(ws) {
  const found = state.weekly.find((w) => w.week === ws);
  let evals = 0;
  state.evals.forEach((e) => { if (weekStartISO(e.date) === ws) evals++; });
  let rupees = 0;
  state.earnings.forEach((e) => { if (weekStartISO(e.date) === ws) rupees += toINR(e.amount, e.cur); });
  return {
    week: ws,
    hours: weekHours(ws),
    evals,
    rupees,
    repos: found ? found.repos || 0 : 0,
    outreach: found ? found.outreach || 0 : 0,
    replies: found ? found.replies || 0 : 0
  };
}
