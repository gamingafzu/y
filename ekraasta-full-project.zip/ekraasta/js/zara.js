/* ============================================================
   zara.js — Zara ka "dimag"
   1. Prompt checker (rule-based, offline)
   2. English eval checker (rule-based, offline)
   3. Chat replies (offline knowledge)
   4. Optional real LLM (agar user apni free API key daale)
   5. Voice: bolna + sunna (browser speech)
   ============================================================ */

const Zara = (function () {

  /* ---------------- 1. PROMPT CHECKER ---------------- */
  function promptFeedback(raw) {
    const text = String(raw || '').trim();
    const items = [];
    let score = 20;

    if (text.length < 30) {
      return {
        score: 0,
        items: [{ type: 'bad', text: 'Yeh prompt bahut chhota hai. Kam se kam 2-3 line likho — role, kaam, aur output format.' }],
        next: '"python fix karo" nahi — "Tum senior Python dev ho. Is code me bug dhundo. Output table me: bug, kyun, fix. Sirf 3 bugs." aisa likho.'
      };
    }

    const has = (re) => re.test(text);

    const role = has(/(you are|act as|tum ek|aap ek|tum ho|senior|expert|teacher|developer ho|as a)/i);
    const task = has(/(write|likho|banao|banado|explain|samjhao|fix|theek|find|dhundo|summar|convert|generate|list|batao|check|review|improve)/i);
    const context = has(/(i am|main |mera|mere|beginner|context|background|kis liye|for my|because|kyunki|student)/i);
    const format = has(/(json|table|bullet|list|markdown|csv|words|format|step by step|numbered|paragraph|heading)/i);
    const constraint = has(/(only|sirf|max|maximum|minimum|do not|mat |no more|limit|at least|exactly|nahi chahiye|short)/i);
    const example = has(/(example|jaise|for instance|e\.g\.|sample)/i);
    const vague = has(/\b(good|nice|better|best|accha|achha|thik|theek)\b/i);

    if (role) { score += 15; items.push({ type: 'good', text: 'Role diya — AI ko pata hai wo kis nazar se jawab de.' }); }
    else { items.push({ type: 'bad', text: 'Role missing. Pehli line me likho: "Tum ek senior Python developer ho."' }); }

    if (task) { score += 15; items.push({ type: 'good', text: 'Kaam saaf hai — kya karna hai wo pata chalta hai.' }); }
    else { items.push({ type: 'bad', text: 'Kaam (task) clear nahi. Ek verb se shuru karo: "samjhao", "dhundo", "banao".' }); }

    if (context) { score += 15; items.push({ type: 'good', text: 'Context diya — level/background batane se jawab tumhare layak aata hai.' }); }
    else { items.push({ type: 'meh', text: 'Context add karo: "Main beginner hoon, 11th pass, English kamzor hai." Isse jawab simple aayega.' }); }

    if (format) { score += 15; items.push({ type: 'good', text: 'Output format bataya — jawab usable form me aayega.' }); }
    else { items.push({ type: 'bad', text: 'Format missing. Likhо: "Output table me do" ya "5 bullet points me".' }); }

    if (constraint) { score += 15; items.push({ type: 'good', text: 'Constraint diya — AI limit me rahega.' }); }
    else { items.push({ type: 'meh', text: 'Constraint add karo: "SIRF 3 bug batao", "150 words max", "rewrite mat karo".' }); }

    if (example) { score += 5; items.push({ type: 'good', text: 'Example diya — yeh best practice hai (few-shot).' }); }

    if (vague) { score -= 8; items.push({ type: 'bad', text: '"good / best / accha" jaise vague words hatao — unki jagah exactly likho kya chahiye.' }); }

    const qCount = (text.match(/\?/g) || []).length;
    if (qCount > 2) { score -= 8; items.push({ type: 'meh', text: 'Ek prompt me 3 se zyada sawaal hain. Ek prompt = ek kaam. Baaki agle message me poocho.' }); }

    if (text.length < 120) { score -= 5; items.push({ type: 'meh', text: 'Thoda detail aur add karo — 3-6 line ka prompt best chalta hai.' }); }

    score = Math.max(0, Math.min(100, score));

    const next = score >= 80
      ? 'Bahut badhiya. Ab isi prompt se jawab lo, aur jawab ache na aaye to ek line aur add karo — "pehle 1 line summary, phir detail".'
      : 'Sabse bada gap: ' + (items.find((i) => i.type === 'bad') || {}).text;

    return { score, items, next };
  }

  /* ---------------- 2. ENGLISH EVAL CHECKER ---------------- */
  function englishFeedback(raw) {
    const text = String(raw || '').trim();
    const items = [];
    let score = 0;

    if (!text) {
      return { score: 0, words: 0, items: [{ type: 'bad', text: 'Kuch likho — kam se kam 100 words.' }], next: 'Practice → English me 150 words likho.' };
    }

    const words = text.split(/\s+/).filter(Boolean).length;
    const sentences = text.split(/[.!?]+/).filter((s) => s.trim().length > 2);

    /* length */
    if (words >= 120) { score += 25; items.push({ type: 'good', text: `Length theek hai (${words} words). Eval me 120+ words kaafi hote hain.` }); }
    else if (words >= 60) { score += 14; items.push({ type: 'meh', text: `${words} words — thoda kam. 120-150 words tak le jao.` }); }
    else { items.push({ type: 'bad', text: `Sirf ${words} words. Eval feedback me kam se kam 120 words chahiye.` }); }

    /* templates usage */
    const tplHits = [
      /correct but incomplete/i,
      /should also mention/i,
      /factually (correct|incorrect)/i,
      /ignores? the constraint/i,
      /suggested fix/i,
      /overall score/i,
      /hallucinat/i,
      /follows all stated constraints/i
    ].filter((re) => re.test(text)).length;
    if (tplHits >= 2) { score += 25; items.push({ type: 'good', text: 'Template patterns use kiye — yahi assessment me kaam aata hai.' }); }
    else if (tplHits === 1) { score += 12; items.push({ type: 'meh', text: 'Ek template use hua. Practice tab ke 15 templates me se 2-3 patterns roz use karo.' }); }
    else { items.push({ type: 'bad', text: 'Koi fixed eval pattern nahi mila. "This response is correct but incomplete. It should also mention ..." jaise sentences use karo.' }); }

    /* sentence start capital */
    const lowerStarts = sentences.filter((s) => /^[a-z]/.test(s.trim()));
    if (lowerStarts.length === 0) { score += 15; items.push({ type: 'good', text: 'Har sentence capital letter se shuru hoti hai.' }); }
    else { items.push({ type: 'bad', text: `${lowerStarts.length} sentence small letter se shuru ho rahi hain. Capital se shuru karo.` }); }

    /* i instead of I */
    if (/\bi\b/.test(text.replace(/\bi'm\b/gi, ''))) items.push({ type: 'bad', text: 'English me "I" hamesha capital hota hai ("i think" → "I think").' });
    else score += 10;

    /* a/an */
    const aVowel = text.match(/\ba\s+[aeiouAEIOU]/g);
    const anCons = text.match(/\ban\s+[^aeiouAEIOU\s]/g);
    if (aVowel || anCons) {
      items.push({ type: 'bad', text: `Article galti: ${(aVowel || []).concat(anCons || []).slice(0, 3).join(', ')} — vowel se pehle "an", consonant se pehle "a".` });
    } else score += 8;

    /* punctuation */
    if (/[.!?]$/.test(text)) score += 7;
    else items.push({ type: 'meh', text: 'Aakhir me full stop lagao.' });

    /* Hindi words */
    const hindi = text.match(/\b(hai|nahi|karo|bohot|bahut|mera|tum|aap|kar|raha|rahe)\b/gi);
    if (hindi && hindi.length) {
      score -= 10;
      items.push({ type: 'bad', text: `Eval text me Hindi words mile (${hindi.slice(0, 3).join(', ')}). Assessment me sirf English likhna hota hai — Hindi me socho, English me likho.` });
    }

    /* filler */
    const filler = text.match(/\b(very|really|thing|things|stuff|etc)\b/gi);
    if (filler && filler.length > 2) {
      score -= 5;
      items.push({ type: 'meh', text: '"very / really / thing" jaise filler words kam karo — specific words likho.' });
    }

    /* specific quoting (best practice) */
    if (/["']/.test(text) || /says|states|mentions/i.test(text)) {
      score += 8;
      items.push({ type: 'good', text: 'Response ki baat quote/reference ki — specific feedback strong hota hai.' });
    } else {
      items.push({ type: 'meh', text: 'Response ka exact sentence quote karo — "it states ___". Isse feedback strong lagta hai.' });
    }

    score = Math.max(0, Math.min(100, Math.round((score / 108) * 100)));

    const next = score >= 75
      ? 'Achha hai. Ab isi ko GitHub pe `evals/` folder me daalo — portfolio bhi ban raha hai.'
      : 'Do cheezein sudharo: (1) template patterns use karo, (2) 120+ words likho. Baaki apne aap theek hoga.';

    return { score, words, items, next };
  }

  /* ---------------- 3. CHAT (offline knowledge) ---------------- */
  function todaySummary() {
    const rec = todayRec();
    const left = DAILY_BLOCKS.filter((b) => !rec.blocks[b.id]);
    if (!left.length) return 'Aaj ke saare 5 block ho gaye. Shabaash! Ab kal ka plan dekh lo — ya 30 min buffer me project pe kaam karo.';
    return 'Aaj baaki hai:\n' + left.map((b) => `• ${b.title} (${b.mins} min)`).join('\n') + '\n\nEk-ek karo, ek saath nahi.';
  }

  function reply(q) {
    const t = String(q || '').toLowerCase();

    if (/(aaj|today).*(kya|kaam|karna)|kya karu/.test(t)) return todaySummary();

    if (/(kitne|how many).*(ghante|hour)|time/.test(t)) {
      return 'Do track milaakar roz 3.5 ghante:\n• 50 min learning (video + code)\n• 50 min project ka kaam\n• 40 min paisa (Karya/platform/apply)\n• 20 min English drill\n• 5 min log\n\n90-din akela 3 ghante maangta hai, 12-mahine akela 2 ghante. Overlap ki wajah se 3+2 = 5 nahi, 3.5 banta hai.';
    }

    if (/prompt/.test(t)) {
      return 'Prompt ke 5 part hote hain:\n1. Role — "Tum ek senior Python dev ho"\n2. Task — ek kaam: "is code me bug dhundo"\n3. Context — "main beginner hoon"\n4. Format — "table me: bug, kyun, fix"\n5. Constraint — "sirf 3 bugs, Hinglish me"\n\nPractice → Prompt Lab me likho, main check karungi.';
    }

    if (/(english|angrezi|grammar)/.test(t)) {
      return 'English ke liye roz 20 min: ek bad AI answer lo, 150 words me feedback likho, phir mujhse check karwao.\n\nAsli baat: tumhe fancy English nahi chahiye — 15 fixed patterns chahiye. Practice → English me templates hain.';
    }

    if (/(eval|evaluation)/.test(t)) {
      return 'Eval matlab: AI ke jawab ko rubric se naapna. Formula:\n1. Rubric pehle padho\n2. Har criterion alag score karo (average mat banao)\n3. Exact sentence quote karo\n4. Batao: kya galat, kyun galat, kaise fix\n\nVague feedback ("this is good") = reject. Specific feedback = paisa.';
    }

    if (/(rag)/.test(t)) {
      return 'RAG = Retrieval-Augmented Generation.\nMatlab: pehle tumhare documents me se relevant hissa dhoondo, phir LLM ko wahi deke jawab banwao. Isse hallucination kam hoti hai.\n\nLearning Month 10 me pura month isi pe hai.';
    }

    if (/(paisa|kamai|money|earn)/.test(t)) {
      return 'Sabse fast paisa: Karya (Hindi/Gujarati task, UPI me) → 2-4 hafte.\nUske baad: Outlier multilingual → $15-24/hr.\nCoding track (45-60 din baad) → $22-32/hr.\nLocal: tuition ₹800-1,500/bacche, dukaan ka chhota automation ₹2,000-5,000.\n\n90 Din tab me pura order hai.';
    }

    if (/(karya)/.test(t)) {
      return 'Karya: Play Store se install karo (DAIA Tech). Profile me Gujarati + Hindi + English teeno daalo. Task mile to slow aur perfect karo — pehle 10 task audition hote hain.\nPaisa UPI/bank me, log 15 working days bolte hain. Cap ~$1,500 hai, isliye isko base income na samjho.';
    }

    if (/(outlier|dataannotation|mercora|alignerr)/.test(t)) {
      return 'Order important hai:\n1. Karya (abhi)\n2. Outlier — sirf multilingual Hindi track (2-3 hafte baad)\n3. Stellar / Mindrift (backup)\n4. Mercor, DataAnnotation (2 mahine baad — English chahiye; DA ka sirf 1 attempt)\n\nEk platform pe bharosa mat karo. 3-4 pe active raho.';
    }

    if (/(test|quiz|exam)/.test(t)) {
      return 'Practice → Tests tab kholo. 5 sawaal aayenge, har jawab ke baad explanation milegi. Kam se kam 80% aaye to topic clear hai.';
    }

    if (/(kaun ho|tum kon|who are you|tumhara naam)/.test(t)) {
      return 'Main Zara hoon — tumhari padhai partner. Main is app ke andar rehti hoon: prompt check karti hoon, English sudharti hoon, aur plan yaad dilati hoon.\n\nNote: bina API key ke main rules se chalti hoon (offline). Key daal do to main asli AI se jawab dungi.';
    }

    if (/(thak|bore|mann nahi|motivat)/.test(t)) {
      return 'Thak gaya to 50 min ka rule lagao: sirf 50 min karo, phir 10 min break. Motivation ka intezaar mat karo — timer chalao.\n\nAur yaad rakho: tumhari problem knowledge ki nahi, finish karne ki thi. Aaj ek chhota kaam poora karo — bas ek.';
    }

    if (/(idea|naya|switch|badal)/.test(t)) {
      return 'Naya idea aaya? More → Ideas me park karo. 90 din tak woh band rahega — yeh maine tumhare liye hi banaya hai, kyunki field badalna tumhara sabse bada risk hai.';
    }

    if (/(kya seekh|learning|roadmap|month)/.test(t)) {
      const mo = currentMonth();
      return `Abhi tum Month ${mo.m} pe ho: ${mo.title}.\n\nIs month ka project: ${mo.project.t}\n\nLearning tab me iss month ke 4 week aur resources hain.`;
    }

    /* fallback */
    return 'Samajh gayi. Main in cheezon me madad kar sakti hoon:\n• "aaj kya karna hai"\n• "prompt kaise likhu"\n• "English kaise improve karu"\n• "paisa kaise kamaun"\n• "eval kya hai"\n• "test lo"\n\nYa Practice tab me likho, main check karungi.';
  }

  /* ---------------- 4. OPTIONAL REAL LLM ---------------- */
  async function askLLM(userText) {
    const key = (state.profile.apiKey || '').trim();
    if (!key) return null;
    const base = (state.profile.apiBase || '').replace(/\/$/, '');
    const model = state.profile.apiModel || 'llama-3.1-8b-instant';
    const sys = 'Tum Zara ho — ek padhai partner jo Hinglish (Roman Hindi) me baat karti hai. '
      + 'User 19 saal ka ladka hai, Godhra Gujarat se, AI engineer banna chahta hai, English kamzor hai, paisa kamana chahta hai. '
      + 'Chhote jawab do (max 150 words), simple bhasha, actionable steps. Bullets use karo. Formalities mat karo.';
    try {
      const res = await fetch(base + '/chat/completions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key },
        body: JSON.stringify({
          model,
          messages: [{ role: 'system', content: sys }, { role: 'user', content: userText }],
          temperature: 0.6,
          max_tokens: 400
        })
      });
      if (!res.ok) return null;
      const data = await res.json();
      const out = data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
      return out ? String(out).trim() : null;
    } catch (e) {
      return null;
    }
  }

  /* ---------------- 5. VOICE ----------------
     Do engine:
     a) device voice (browser/OS) — free, offline. Best Hindi female voice khud chunti hai.
     b) cloud voice — Sarvam / ElevenLabs / Google TTS. Real ladki jaisi. Key user ki.
     ------------------------------------------------------------ */
  let voicesCache = [];
  let currentAudio = null;
  let lastTtsError = '';

  const FEMALE_HINTS = ['female','woman','swara','neerja','ananya','aarohi','heera','kalpana','lekha','asha','aasha','priya','riya','zira','samantha','ava','jenny','aria','sonia','natasha','veena','shruti','hindi'];
  const NATURAL_HINTS = ['natural','neural','online','enhanced','premium','wavenet','studio','hd','multilingual'];
  const BAD_HINTS = ['male','man ','david','mark','ravi','george','rishi','daniel','alex'];

  function loadVoices() {
    try { voicesCache = window.speechSynthesis ? window.speechSynthesis.getVoices() : []; }
    catch (e) { voicesCache = []; }
    return voicesCache;
  }

  function allVoices() {
    if (!voicesCache.length) loadVoices();
    return (voicesCache || []).map((v) => ({ name: v.name, lang: v.lang, local: v.localService }));
  }

  function findVoice(name) {
    if (!voicesCache.length) loadVoices();
    return (voicesCache || []).find((v) => v.name === name) || null;
  }

  function scoreVoice(v) {
    const n = String(v.name || '').toLowerCase();
    const l = String(v.lang || '').toLowerCase();
    let s = 0;
    if (l.indexOf('hi') === 0) s += 100;               // Hindi — sabse pehle
    else if (l.indexOf('en-in') === 0) s += 55;         // Indian English
    else if (l.indexOf('en') === 0) s += 10;
    if (FEMALE_HINTS.some((h) => n.indexOf(h) >= 0)) s += 45;
    if (NATURAL_HINTS.some((h) => n.indexOf(h) >= 0)) s += 30;
    if (BAD_HINTS.some((h) => n.indexOf(h) >= 0)) s -= 60;
    if (v.localService === false) s += 12;              // cloud voices zyada natural
    return s;
  }

  function bestVoice() {
    if (!voicesCache.length) loadVoices();
    const list = (voicesCache || []).slice();
    if (!list.length) return null;
    list.sort((a, b) => scoreVoice(b) - scoreVoice(a));
    return list[0];
  }

  function chosenVoice() {
    const saved = state.profile.voiceName;
    if (saved) {
      const v = findVoice(saved);
      if (v) return v;
    }
    return bestVoice();
  }

  /* -------- device speak -------- */
  function deviceSpeak(text) {
    try {
      if (!window.speechSynthesis) { lastTtsError = 'Is browser me speech nahi hai'; return false; }
      window.speechSynthesis.cancel();
      const clean = String(text).replace(/[*_#•>`]/g, ' ').replace(/\n+/g, ' ');
      const u = new SpeechSynthesisUtterance(clean);
      const v = chosenVoice();
      /* voice set karna kabhi fail ho sakta hai (stale/invalid voice) — app na ruke */
      let voiceSet = false;
      if (v) {
        try { u.voice = v; voiceSet = true; } catch (e) { voiceSet = false; }
        try { u.lang = v.lang || 'hi-IN'; } catch (e) {}
      }
      if (!voiceSet) u.lang = 'hi-IN';
      u.rate = Number(state.profile.voiceRate) || 0.98;
      u.pitch = Number(state.profile.voicePitch) || 1.08;
      window.speechSynthesis.speak(u);
      lastTtsError = '';
      return true;
    } catch (e) {
      lastTtsError = e.message || 'device speak fail';
      return false;
    }
  }

  /* -------- cloud speak -------- */
  async function cloudSpeak(text) {
    const provider = state.profile.ttsProvider || 'device';
    const key = String(state.profile.ttsKey || '').trim();
    if (provider === 'device' || !key) return false;

    const send = String(text).replace(/[*_#•>`]/g, ' ').replace(/\n+/g, ' ').slice(0, 900);
    let src = null;

    try {
      if (provider === 'sarvam') {
        const speaker = state.profile.ttsVoice || 'anushka';
        const r = await fetch('https://api.sarvam.ai/text-to-speech', {
          method: 'POST',
          headers: { 'api-subscription-key': key, 'Content-Type': 'application/json' },
          body: JSON.stringify({
            inputs: [send], target_language_code: 'hi-IN', speaker,
            model: 'bulbul:v2', speech_sample_rate: 22050, enable_preprocessing: true
          })
        });
        if (!r.ok) throw new Error('Sarvam ' + r.status);
        const j = await r.json();
        const b64 = (j.audios && j.audios[0]) || j.audio;
        if (!b64) throw new Error('Sarvam: audio nahi mila');
        src = 'data:audio/wav;base64,' + b64;

      } else if (provider === 'elevenlabs') {
        const voiceId = state.profile.ttsVoice || '21m00Tcm4TlvDq8ikWAM';
        const r = await fetch('https://api.elevenlabs.io/v1/text-to-speech/' + voiceId + '?output_format=mp3_44100_128', {
          method: 'POST',
          headers: { 'xi-api-key': key, 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text: send, model_id: 'eleven_multilingual_v2',
            voice_settings: { stability: 0.4, similarity_boost: 0.8, style: 0.2 }
          })
        });
        if (!r.ok) throw new Error('ElevenLabs ' + r.status);
        const blob = await r.blob();
        src = URL.createObjectURL(blob);

      } else if (provider === 'google') {
        const voice = state.profile.ttsVoice || 'hi-IN-Neural2-A';
        const r = await fetch('https://texttospeech.googleapis.com/v1/text:synthesize?key=' + encodeURIComponent(key), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            input: { text: send },
            voice: { languageCode: 'hi-IN', name: voice },
            audioConfig: { audioEncoding: 'MP3', speakingRate: Number(state.profile.voiceRate) || 1.0, pitch: 0 }
          })
        });
        if (!r.ok) throw new Error('Google TTS ' + r.status);
        const j = await r.json();
        if (!j.audioContent) throw new Error('Google: audio nahi mila');
        src = 'data:audio/mp3;base64,' + j.audioContent;
      }

      if (!src) return false;
      stopSpeak();
      currentAudio = new Audio(src);
      await currentAudio.play().catch(() => {});
      return true;
    } catch (e) {
      lastTtsError = e.message || 'cloud voice fail';
      return false;
    }
  }

  /* -------- public speak -------- */
  async function speak(text) {
    if (!state.profile.voice) return false;
    const t = String(text || '').trim();
    if (!t) return false;

    if ((state.profile.ttsProvider || 'device') !== 'device' && state.profile.ttsKey) {
      const ok = await cloudSpeak(t);
      if (ok) return true;
      /* cloud fail — device voice se bol do, aur ek baar batao */
      if (typeof toast === 'function') toast('Cloud voice fail: ' + lastTtsError + ' — device voice use kar rahi hoon');
    }
    return deviceSpeak(t);
  }

  function stopSpeak() {
    try { window.speechSynthesis && window.speechSynthesis.cancel(); } catch (e) {}
    try {
      if (currentAudio) { currentAudio.pause(); currentAudio.currentTime = 0; currentAudio = null; }
    } catch (e) {}
  }

  /* -------- voice test (Settings se) -------- */
  async function testVoice(sample) {
    const line = sample || ('Namaste Aadil! Main Zara hoon. Aaj ka pehla kaam: Python functions practice. '
      + 'Chalo shuru karein — sirf paanch minute lagenge.');
    if (!state.profile.voice) state.profile.voice = true;
    return await speak(line);
  }

  function ttsStatus() {
    const v = chosenVoice();
    return {
      engine: (state.profile.ttsProvider || 'device') === 'device' ? 'device' : state.profile.ttsProvider,
      voice: v ? v.name : '—',
      lang: v ? v.lang : '—',
      error: lastTtsError
    };
  }

  /* -------- speech-to-text (mic) -------- */
  function listen(onText, onErr) {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { onErr && onErr('Is browser me mic support nahi hai. Chrome use karo.'); return; }
    try {
      const rec = new SR();
      rec.lang = 'hi-IN';
      rec.interimResults = false;
      rec.maxAlternatives = 1;
      rec.onresult = (e) => {
        const txt = e.results[0][0].transcript;
        onText && onText(txt);
      };
      rec.onerror = (e) => onErr && onErr('Mic error: ' + (e.error || 'unknown') + '. Permission check karo.');
      rec.start();
    } catch (e) {
      onErr && onErr('Mic start nahi hua. Permission do ya Chrome me kholo.');
    }
  }

  if (typeof window !== 'undefined' && window.speechSynthesis) {
    try { window.speechSynthesis.onvoiceschanged = loadVoices; } catch (e) {}
    setTimeout(loadVoices, 300);
    setTimeout(loadVoices, 1500);
  }

  return { promptFeedback, englishFeedback, reply, askLLM, speak, stopSpeak, listen,
           allVoices, findVoice, bestVoice, chosenVoice, testVoice, ttsStatus, loadVoices };
})();
