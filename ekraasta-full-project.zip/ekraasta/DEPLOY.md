# Deploy + Cloud sync — 5 minute

Sab ready hai. Bas 2 cheezein karni hain: app live karna, aur cloud on karna.

---

## 1. App live karo (1 min)

1. Netlify kholo → **dynamic-florentine-124b28** site → **Deploys** tab
2. Neeche **"Deploy manually"** box me `ekraasta-site.zip` drag-drop karo
   (ya "Browse to publish" → same file chuno)
3. 30-60 sec wait. Deploy khatam hone pe **same URL** khulega: `https://dynamic-florentine-124b28.netlify.app`

**Check karo:**
- [ ] App dark me khulta hai (kaala background, violet hero card)
- [ ] Upar `90 Din ⇄ Learning` switch dabane pe hero ka rang violet ↔ cyan badalta hai
- [ ] Neeche 4 tab: Ghar / Plan / Practice / Aur

> Pehli baar khulte waqt bhi purana version dikhe to: browser me **Ctrl+Shift+R**
> (phone pe: tab band karke dobara kholo). Service worker cache v4 kar diya hai.

---

## 2. Cloud sync on karo (3 min, ek baar)

App me: **Aur → Settings → Cloud sync** card. Wahin step-by-step likha hai, short version:

### Step A — Supabase project
1. `supabase.com` → **Start your project** (Google/GitHub se login chalega)
2. **New project** → region **Mumbai** (ya Singapore) → database password yaad rakho
3. 2 min wait

### Step B — SQL chalao
1. Supabase sidebar → **SQL Editor** → **New query**
2. App ke Settings card me **Step 2** kholо → **"SQL copy karo"**
3. Paste → **RUN**. "Success" aana chahiye.

Yeh SQL kya karta hai: `user_state` table banata hai aur **Row Level Security** on karta hai —
matlab tumhare account ka data sirf tum hi padh sakte ho, koi doosra user nahi.

### Step C — URL + key
1. Supabase → **Project Settings → API**
2. **Project URL** copy → app me paste (`https://xxxxx.supabase.co`)
3. **anon public** key copy → app me paste
4. App me **Test karo** dabao → green box "Connected — table bhi mil gaya" aaye
5. Phir **Auth → Providers → Email → "Confirm email" OFF** kar do (warna signup ke baad login nahi hoga)

### Step D — account banao
1. App me email + password (6+ char) daalo → **Naya account**
2. Login ho jayega, card pe **Cloud** badge aa jayega
3. Ab har change 3 sec me cloud pe chala jayega

---

## 3. Doosre device pe (phone / PC)

1. Wahi app URL kholo (ya standalone file)
2. Settings → Cloud sync → **wahi email/password** se **Login**
3. Pehli baar: **Pull** dabao — PC ka data phone pe aa jayega

Data rule: **jo last me change hua wahi jeetega** (last-write-wins). Ek hi waqt pe
do device pe kaam mat karo, warna ek ki mehnat overwrite ho sakti hai.

---

## Kya cloud pe jata hai, kya nahi

| Jata hai | Nahi jata |
|---|---|
| progress, tasks, projects, kamai, platforms, chat, logs | Supabase URL/key |
| naam, dates, settings | Groq/AI apiKey |
| | device ki voice setting |

Yaani tumhari API key kabhi cloud pe nahi jaati — sirf us device pe rehti hai.

---

## Backup (optional, 10 sec)

Settings → Data → **Export** → `.json` file save ho jaati hai.
Kuch gadbad lage to **Import** se wapas laa sakte ho.

---

## Files

| File | Kaam |
|---|---|
| `ekraasta-site.zip` | Netlify pe drag karne wala build |
| `ekraasta/ekraasta-standalone.html` | single file — double click, offline chalta hai |
| `ekraasta/DEPLOY.md` | yeh file |
| `ekraasta/README.md` | poora technical docs (SQL, structure) |
