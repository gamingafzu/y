# ekRaasta — PROJECT FULL (code + poora context)

> **Yeh file kya hai:** ek single-file handoff. Isse kisi bhi AI tool (ChatGPT / Claude / Gemini / Cursor)
> ko de sakte ho — usme app ka poora context, rules, architecture aur **line-by-line source code** hai.
> Neeche section 16 me saara code hai; upar ke sections bataate hain ki cheezein *kyun* aisi hain.
>
> **Version:** v4.1 (dark UI + violet/cyan palette) · **Files:** 9 source + 3 support · **Dependencies:** zero
> **Last updated:** 2026-10-31

---

## 1. Ek line me app

**ekRaasta** = ek personal progress app jisme do roadmap ek saath rehte hain — **90-din ka paisa plan**
(fixed dates) aur **12–13 mahine ka AI-engineer learning track** (flexible) — aur upar ek switch se
turant badal jaate hain. Plus daily blocks, prompt/English practice, Zara (Hinglish voice + chat),
projects, kamai tracker, platforms, cloud sync.

Ye ek **single-user, offline-first PWA** hai. Koi backend nahi (cloud optional hai), koi login zaroori nahi.

---

## 2. User kaun hai (context — isse design decisions samajh aayenge)

- **Aadil**, 19 saal, Godhra (Gujarat). 11th pass, CSE diploma beech me chhoda.
- Python basic (number-guessing game, unit converter), AI tools thode use kiye hain.
- **English likhne me kamzor** — isliye har cheez Hinglish me hai.
- **Paisa jaldi chahiye** — isliye 90-din track pehle aata hai aur Karya (Hindi/Gujarati tasks) sabse pehle.
- Degree nahi hai — isliye roadmap "degree" pe nahi, "proof of work" (GitHub + demos) pe khada hai.
- Track A chuna hai: **AI training / evaluation platforms** (Karya → Outlier → Stellar → Mindrift → Mercor →
  DataAnnotation → Alignerr). Tuition/shop/Fiverr wale tracks **user ne reject kiye** hain.

**Roz ka time:** ~**3.5 ghante** (core 2h45 = 165 min + buffer). Yeh `TOTAL_MINS` aur `DAILY_BLOCKS` me fixed hai.

---

## 3. Non-negotiable product rules

| # | Rule | Kyun |
|---|---|---|
| 1 | Sab kuch **Hinglish (Roman)** | User ki English weak hai |
| 2 | **Ek app, do roadmap, ek-tap switch** | User ne do alag app/screen reject kiye |
| 3 | 90-din track **date-based** (fixed), Learning **flexible** | Paisa deadline pe, seekhna pace pe |
| 4 | **Dark default** — violet `#7c5cff` + cyan `#38bdf8` | User ka final palette (obsidian/crimson try reject hua) |
| 5 | Roadmap ka **personalization** (Excel/Power BI hataya) | 11th pass + paisa jaldi chahiye |
| 6 | Feedback **blunt**, sugar-coated nahi | "Yeh galti aapki hai" tone |
| 7 | **Zero dependency**, vanilla JS + 1 CSS | file:// pe chale, offline, PC+phone dono |
| 8 | Mobile-first, PC pe bhi theek | 390px aur 1280px dono test hote hain |

---

## 4. Tech stack

- **HTML** — ek `index.html`, static shell (appbar, tabbar, FAB, chat sheet, modal, toast).
- **CSS** — ek `css/app.css`, CSS variables se light/dark theme. Koi framework/preprocessor nahi.
- **JS** — 7 plain script files, global scope, koi bundler nahi. Sab `index.html` me `<script>` se load.
- **Storage** — `localStorage` (key `ekraasta_v2`), memory fallback agar storage band ho.
- **Optional cloud** — Supabase REST (fetch), SDK nahi.
- **PWA** — `manifest.webmanifest` + `sw.js` (cache-first, cache name `ekraasta-v4`).
- **Standalone build** — `build-single.py` sab inline karke ek HTML banata hai (offline double-click).

---

## 5. Files aur load order

```
ekraasta/
├── index.html               # shell: appbar, screen, tabbar, FAB, chat sheet, modal, toast
├── css/app.css              # poora design system (tokens + components + print + media queries)
├── js/data.js               # SAARA content: daily blocks, PLAN_90, LEARN_MONTHS, prompt/english/quiz
├── js/store.js              # state, localStorage, date helpers, stats
├── js/ui.js                 # icons, esc, toast, theme, modal, ring/progress, hydrateIcons
├── js/cloud.js              # Supabase auth + push/pull + test + SQL constant
├── js/zara.js               # dimag: prompt scorer, english eval, chat router, LLM, TTS/STT
├── js/views.js              # har screen ka HTML + `ui` (view state) + `draft`
├── js/app.js                # boot, render loop, event delegation (saare `data-act`)
├── sw.js                    # service worker
├── manifest.webmanifest     # PWA metadata (theme #08090c)
├── build-single.py          # inline sab kuch → ekraasta-standalone.html
├── desktop/                 # Electron wrapper (.exe build ke liye, optional)
└── icons/icon-192.png, icon-512.png
```

**Load order `index.html` me:** `data → cloud → store → ui → zara → views → app`

> `cloud.js` `store.js` se pehle load hota hai, par `state` ko sirf functions ke andar chhoota hai
> (call time pe milta hai). Refactor karte waqt dhyan rakhna.

---

## 6. Runtime architecture

### 6.1 Boot

```
DOM ready → boot() (app.js)
  ├─ print styles inject
  ├─ beforeinstallprompt capture (PWA install button)
  ├─ service worker register (sirf http/https pe, file:// pe nahi)
  ├─ applyTheme()  ← state.profile.theme ('dark' default)
  ├─ icons inject (theme, gear, FAB, mic, send) + hydrateIcons()
  ├─ bind: click delegation (document pe ek hi listener), chat form, mic
  └─ render()
```

### 6.2 Render loop (poore app ka dil)

App me koi framework nahi. Pattern hai: **state → HTML string → innerHTML**.

```js
function render() {
  flushInputs();                                   // textarea/input ki value state me le lo
  const html = (SCREENS[ui.nav] || vHome)();       // screen ka HTML string
  document.getElementById('screen').innerHTML = html;
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('on', t.dataset.nav === ui.nav));
  document.getElementById('logoSub').textContent = ...;   // appbar ka subtitle
  // live bindings: english word count, voice sliders
}
```

- `SCREENS = { home: vHome, plan: vPlan, practice: vPractice, more: vMore }`
- `ui` = **view state** (kahan ho, kaunsa mode, kaunsa accordion khula) — localStorage me **nahi** jaata.
- `state` = **data** — localStorage me jaata hai, cloud pe jaata hai.
- Har interaction: state ya `ui` badlo → `render()`.

**Scroll rule:** tab change pe `scrollTo(0,0)`; task tick pe nahi (jhatka na lage).
Chhote actions (checkbox) pe bhi poora screen re-render hota hai — isliye scroll position manually manage hota hai.

### 6.3 Event delegation

Ek hi listener: `document.addEventListener('click', handler)`. Har button pe `data-act="..."` hota hai,
handler `switch` me case chalata hai. Extra data `data-*` me aata hai.

| `data-act` | Kaam |
|---|---|
| `nav` | tab/screen badlo (`data-nav`), `t90`/`learn` → plan + mode |
| `mode` | roadmap switch (`data-mode="90" \| "learn"`) |
| `toggle-block` | aaj ka daily block tick (`data-id`) |
| `save-log` | aaj ka log save |
| `open-phase` / `open-month` | accordion kholo/band |
| `toggle-t90` / `toggle-learn` | task/week/project tick (`data-key`) |
| `practice-tab` | Prompt Lab / English / Tests |
| `check-prompt`, `prompt-example`, `prompt-save` | prompt lab |
| `check-english`, `eval-save`, `load-samples` | english drill |
| `start-test`, `answer`, `next-q`, `end-test` | quiz |
| `add-earn`, `del-earn`, `add-idea`, `del-idea`, `save-week` | money / ideas / weekly |
| `more` | Aur ke sub-screen (`data-sub`) |
| `theme` | dark/light |
| `voice-*`, `cloud-voice-*` | TTS voice settings |
| `cloud-config`, `cloud-test`, `cloud-copy-sql`, `cloud-signup`, `cloud-login`, `cloud-push`, `cloud-pull`, `cloud-logout`, `cloud-forget` | cloud sync |
| `install`, `export`, `import`, `reset`, `print` | PWA + data |
| `open-zara`, `quick`, `speak`, `voice-test` | Zara |

### 6.4 `ui` object (view state)

```js
const ui = {
  nav: 'home',        // home | plan | practice | more
  mode: '90',         // 90 | learn   ← roadmap switch ka dil
  more: null,         // projects | money | platforms | ideas | weekly | settings | adapted
  practice: 'prompt', // prompt | english | tests
  openPhase: 'p1',    // kaunsa 90-din phase khula hai
  openMonth: null,    // kaunsa learning month khula hai (null = current month)
  promptRes: null,    // prompt check ka result
  englishRes: null,
  quiz: null,
  cloudTest: null
};
const draft = { prompt: '', english: '' };   // jo type ho raha hai
```

---

## 7. State schema (`js/store.js`)

`localStorage["ekraasta_v2"]` me poora JSON. Load pe `seedState()` ke saath shallow-merge hota hai,
isliye naye field add karne se purana data nahi tootta.

```js
{
  v: 2,
  profile: {
    name: 'Aadil',
    startDate: '2026-10-31',    // 90-din ka Day 1
    learnStart: '2026-10-31',   // learning track ka start
    theme: 'dark',              // dark | light
    uiV: 4,                     // migration flag (purane user ko ek baar dark pe laata hai)
    hoursPerDay: 3.5,
    usdRate: 88,
    apiKey: '',                 // Groq/OpenAI key — CLOUD PE NAHI JAATI
    apiBase: 'https://api.groq.com/openai/v1',
    apiModel: 'llama-3.1-8b-instant',
    voice: true,                // Zara bole ya chup rahe
    voiceName: '', voiceRate: 0.98, voicePitch: 1.08,
    ttsProvider: 'device',      // device | cloud
    ttsKey: '', ttsVoice: '',
    supabaseUrl: '', supabaseKey: ''   // CLOUD PE NAHI JAATE
  },
  daily: { 'YYYY-MM-DD': { blocks: { learn: true, ... }, log: '...' } },
  t90:   { done: { 'p1-0': 'YYYY-MM-DD', ... } },      // 90-din tasks
  learn: { done: { 'm1-w1': '...', 'm1-proj': '...' }, open: 1 },
  projects: [ { id, name, status: 'done'|'wip'|'todo', tags: [], link } ],  // 9 seeded, 2 done
  evals: [], prompts: [], tests: [],
  earnings: [ { id, date, platform, amount, cur, note } ],
  platforms: [ { id, name, status, rate, next, due, notes } ],              // 7 seeded
  ideas: [], weekly: [ { week, hours, ... } ],
  chat: [ { role: 'user'|'zara', text, at } ],
  updatedAt: 0                // epoch ms — cloud me last-write-wins ke liye
}
```

**Helpers (`store.js`):**

| Function | Return |
|---|---|
| `todayISO()`, `isoOf(d)`, `addDays(iso, n)`, `daysBetween(a,b)`, `weekStartISO(iso)` | date utils |
| `fmtDate`, `fmtDateFull` | Hinglish-friendly display |
| `save()`, `saveNow()` | debounce 60ms / turant; save pe cloud auto-push 3s |
| `day90()` | start date se aaj tak ka din number (1-based) |
| `todayRec()` | aaj ka `{ blocks:{}, log:'' }` record |
| `blocksDone(rec)`, `minsDone(rec)` | aaj ka progress |
| `streak()` | lagataar din jisme ≥4 block done (aaj complete na ho to kal se ginti) |
| `t90Stats()`, `phaseStats(ph)` | `{done,total,pct}` |
| `learnStats()`, `monthStats(mo)` | weeks + project ko count karte hain |
| `inr(n)`, `toINR(amount, cur)`, `monthEarn()`, `totalEarn()` | paisa |
| `shippedCount()`, `weekHours(weekStart)`, `weekRow()` | stats |

---

## 8. Content data model (`js/data.js`)

| Constant | Shape | Kaam |
|---|---|---|
| `DAILY_BLOCKS` | `[{ id, track:'90'\|'learn'\|'both', title, mins, hint }]` | roz ke 5 block (50+50+40+20+5) |
| `TOTAL_MINS` | `165` | din ka target |
| `PLAN_90` | `[{ id:'p1', name, range:'Day 1-30', goal, tasks:[{ t, how:[], why }] }]` | 4 phase × ~5-6 task |
| `LEARN_MONTHS` | `[{ m:1, title, focus, weeks:[{w:1,d:'...'}], project:{t,steps:[]}, res:[{l,u}], note }]` | 13 mahine |
| `PROMPT_PARTS` | `[{ name:'Role', ex:'...' }]` | prompt ke 5 part |
| `PROMPT_EXAMPLES` | `[{ good:'...', bad:'...' }]` | example button |
| `ENGLISH_TEMPLATES` | `[{ g:'Feedback', items:[] }]` | 15+ fixed eval sentences |
| `QUIZ_BANK` | `[{ q, opts:[], a:index, why }]` | 15 sawaal |

**Content likhne ke rules:** sab Hinglish, chhote vaakya, har task me "kaise karna hai" practical (tool ka naam,
kahan click), aur jahan ho sake resource **Hindi-first** (CodeWithHarry, CampusX, Krish Naik).

---

## 9. Zara — dimag aur awaaz (`js/zara.js`)

### 9.1 Prompt scorer (`promptFeedback`)

Base 20, phir 5 part pe +15 each, example +5, minus: vague words −8, 3+ sawaal −8, 120 char se chhota −5.
`< 30` char pe seedha 0.

| Part | Detect (regex, Hinglish+English) |
|---|---|
| Role | `tum ek`, `aap ek`, `senior`, `expert`, `you are`, `act as` |
| Task | `likho`, `banao`, `dhundo`, `samjhao`, `fix`, `summar`, `review`... |
| Context | `main `, `mera`, `beginner`, `11th pass`, `student`... |
| Format | `table`, `json`, `bullet`, `list`, `step by step`, `words`... |
| Constraint | `sirf`, `only`, `max`, `do not`, `exactly`, `nahi chahiye`... |

Output: `{ score, items:[{type:'good'|'meh'|'bad', text}], next }`.
Score < 50 pe UI me **"Yeh galti tumhari hai — prompt adhoora hai"** dikhta hai. Yeh jaan-boojh ke blunt hai.

### 9.2 English eval (`englishFeedback`)

Patterns dhoondhta hai: 120+ words (+25), eval templates (+25), capital start (+15), `I` capital (+10),
a/an sahi (+8), punctuation (+7); minus: Hindi words −10, filler, chhota text.
Yeh **assessment-style feedback** ki practice karata hai (Outlier/DataAnnotation ka core skill).

### 9.3 Chat router (`reply`)

Keyword-based offline brain: `aaj kya karna`, `kitne ghante`, `prompt`, `english`, `eval`, `rag`, `paisa`,
`karya`, `outlier|dataannotation`, `test`, `roadmap`, `atka/lost`, `platform`, `resume`...
Har jawab me Hinglish + next step. Agar `state.profile.apiKey` set hai to `askLLM()` asli AI (Groq/OpenAI
compatible) se jawab leta hai — warna offline rule-based.

### 9.4 Awaaz (TTS) + sunna (STT)

- `loadVoices()` → `allVoices()` → `scoreVoice()` (Hindi `hi-IN` + female names ko priority: Swara, Kalpana,
  Heera, Google हिन्दी...) → `bestVoice()`; user ka chunav `chosenVoice()` me pehle aata hai.
- `deviceSpeak()` — `speechSynthesis`; `u.voice` assignment **try/catch** me (kuch browsers throw karte hain),
  fallback `u.lang='hi-IN'`.
- `cloudSpeak()` — provider `sarvam` / `elevenlabs` / `google` ke liye REST call (key user daalta hai).
- `testVoice()`, `ttsStatus()` — settings UI ko status deta hai.
- `listen()` — `webkitSpeechRecognition`, `hi-IN`.

**User ki requirement:** asli ladki jaisi Hindi/Hinglish awaaz — default robotic browser voice reject ki gayi thi.
Best free option jo test me chala: **Microsoft Swara Online (Natural) - Hindi** (Edge/Chrome Windows).

---

## 10. Cloud sync (`js/cloud.js`)

Supabase REST, **SDK nahi**. Session `localStorage["ekraasta_cloud_session"]` me.

| Function | Kaam |
|---|---|
| `cfg()` / `ready()` | `profile.supabaseUrl + supabaseKey` set hai? |
| `signup(email, pass)` / `login(...)` | `/auth/v1/signup`, `/auth/v1/token?grant_type=password` |
| `refreshSession()` / `ensureToken()` | token expire hone pe refresh |
| `push(silent)` | upsert `/rest/v1/user_state` with `Prefer: resolution=merge-duplicates` |
| `pull(silent)` | `select=data,updated_at`; remote naya ho to `applyRemote()` |
| `pushSoon()` | `save()` se bula ke 3 sec debounce me push |
| `test()` | table/URL/key verify — 404 = "table nahi hai", 401/403 = "key galat" |
| `SQL` | ready SQL string (app me copy button se copy hota hai) |

**Merge rule:** `updated_at` compare (1.5s tolerance). Remote naya → apply. Warna local push.
**Secrets:** `apiKey`, `supabaseUrl`, `supabaseKey`, `theme` **cloud se apply nahi hote** (device ke rehte hain).

**SQL (app ke andar `Cloud.SQL`):** table `public.user_state(user_id uuid pk → auth.users, data jsonb,
updated_at timestamptz)` + RLS on + select/insert/update policies `auth.uid() = user_id`.

---

## 11. PWA, build, deploy

- **PWA:** `manifest.webmanifest` (theme `#08090c`, violet icons), `sw.js` cache-first, cache `ekraasta-v6`.
  Install button Settings me hai (`beforeinstallprompt` capture).
- **Standalone:** `python3 build-single.py` → `ekraasta-standalone.html` (~180 KB) — sab inline, file:// pe chalta hai.
- **Deploy:** `index.html manifest.webmanifest sw.js css/ js/ icons/` ko zip karke Netlify pe drag.
  Live: `https://dynamic-florentine-124b28.netlify.app`
- **Desktop:** `desktop/` me Electron wrapper (signed .exe yahan se nahi ban sakta, `BUILD-EXE-APK.md` dekho).

---

## 12. Design system (`css/app.css`)

### Tokens (dark default)

| Token | Dark | Light |
|---|---|---|
| `--bg` | `#08090c` | `#f5f6fa` |
| `--surface` | `#101216` | `#ffffff` |
| `--surface-2/3` | `#151821` / `#1b1f28` | `#f7f8fb` / `#eef0f5` |
| `--line` | `#232733` | `#e4e7ee` |
| `--text / -2 / -3` | `#edf0f6` / `#98a0b0` / `#68707f` | `#0f1419` / `#596274` / `#8b93a3` |
| `--accent` (90-din) | `#7c5cff` violet | `#6d4aff` |
| `--learn` (learning) | `#38bdf8` cyan | `#0284c7` |
| `--ok` / `--warn` | `#34d399` / `#fbbf24` | `#0e9f6e` / `#b45309` |

### Components

- `.appbar` — sticky, blur, logo + `#logoSub` + theme/gear buttons
- `.modeswitch` — 2-part segmented control; active side apne track ka halka tint
  (violet = 90 Din, cyan = Learning) — pehle kaali dikh rahi thi, wo fix kiya gaya
- `.hero` — gradient card (`m90` violet / `mlearn` cyan), `.hero-pill` + `.hero-bar` + 3 stats
- `.blk` — daily block row; title ke aage chhota **track dot** (`.trk-90/.trk-learn/.trk-both`);
  right side pe kuch nahi (pehle tag box title ko tod raha tha)
- `.card / .card.tight / .card.flat`, `.btn` (`accent`, `indigo`, `soft`, `ghost`, `danger`, `sm`, `block`)
- `.phase / .mon-head / .head-bar / .cnt / .chev` — accordions, progress bar head ke neeche full width
- `.sheet` (Zara chat: `.chat-body`, `.msg`, `.chat-quick`, `.chat-input`), `.modal`, `.toast`
- `.tabbar` + `.fab` (48px, content ko dhakta nahi), `.test-box.ok/.bad`
- Print rules (`#printArea`), desktop `@media (min-width: 900px)` — nav bottom-docked, content 780px

### UX rules jo pehle tod diye gaye the (dobara mat todna)

1. Ek hi baat 3 jagah na dikhe (ring + hint + right column %).
2. Title ki width kam na karo right-side badge se.
3. Same kaam ke 2 button na ho (switch + "track kholo").
4. Tab switch pe page top pe jaye; chhote tick pe scroll jump na ho.
5. PC pe nav content ke upar na tayre.

---

## 13. Roadmap personalization (jo user ne manga)

`adaptedCard()` me UI me dikhta hai, aur `LEARN_MONTHS` me actually lagu hai:

| Kahan | Kya badla | Kyun |
|---|---|---|
| Month 1 | Excel dashboard hataya → Python + scripts | AI engineer ko Excel ka basic kaafi |
| Month 3 | EDA 4 → 3 hafte | 4th hafta SQL ko |
| Month 4 | Power BI/Tableau **skip** → FastAPI early | Data-analyst track nahi chahiye |
| Month 7 | DL 4 → 3 hafte | CNN rakha, RNN sirf concept |
| Month 12–13 | buffer month | 13 mahine lage to guilt nahi |
| Resources | Hindi-first | English weak hai |
| Resume | sample copy nahi, projects se | Sample 10 saal experience wale ka tha |

**Isse undo mat karo bina user se poochhe.**

---

## 14. Abhi kya baaki hai (open items)

1. **Real Supabase pe verify** — flow mock pe test hua hai; user ke apne project pe ek baar chalana hai.
2. **`your-github-username`** — `store.js` ke 2 seeded project links me placeholder hai; user ke username se replace karna.
3. **TTS provider keys** — Sarvam/ElevenLabs/Google key user daalega; free device voice default hai.
4. **Icons** — naye violet icon ban gaye hain; phone pe purana install delete karke dobara add karna padega.
5. **Netlify deploy** — zip banaya hua hai, user ko drag karna hai (credentials mere paas nahi).
6. **Notifications/reminders** — socha hua hai, banaya nahi.

---

## 15. POORA SOURCE CODE (copy-paste ready)

Yeh section hi asli app hai. File ka naam heading me hai — us naam se file banao aur code paste karo.
**Load order** `index.html` me tay hota hai: `data → store → ui → cloud → zara → views → app`.

> Note: `js/cloud.js` ko `index.html` me `store.js` se **pehle** load kiya gaya hai, lekin wo `state` ko
> sirf function ke andar use karta hai, isliye order se farak nahi padta. Agar refactor karo to dhyan rakhna.

#### `index.html`

```text
<!DOCTYPE html>
<html lang="hi" data-theme="light">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
<meta name="theme-color" content="#08090c" />
<title>ekRaasta — AI Engineer ka raasta</title>
<link rel="manifest" href="manifest.webmanifest" />
<link rel="icon" href="icons/icon-192.png" type="image/png" />
<link rel="apple-touch-icon" href="icons/icon-192.png" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-mobile-web-app-title" content="ekRaasta" />
<link rel="stylesheet" href="css/app.css" />
</head>
<body>

<!-- ============ TOP BAR ============ -->
<header class="appbar" id="appbar">
  <div class="appbar-left">
    <div class="logo-mark">eR</div>
    <div>
      <div class="logo-text">ekRaasta</div>
      <div class="logo-sub" id="logoSub">Day 1 / 90</div>
    </div>
  </div>
  <div class="appbar-right">
    <button class="icon-btn" id="btnTheme" aria-label="Theme"></button>
    <button class="icon-btn" id="btnSettingsTop" aria-label="Settings"></button>
  </div>
</header>

<!-- ============ SCREEN ============ -->
<main id="screen" class="screen"></main>

<!-- ============ BOTTOM NAV ============ -->
<nav class="tabbar" id="tabbar">
  <button class="tab" data-nav="home"><span class="ti" data-ico="home"></span><span class="tl">Ghar</span></button>
  <button class="tab" data-nav="plan"><span class="ti" data-ico="layers"></span><span class="tl">Plan</span></button>
  <button class="tab" data-nav="practice"><span class="ti" data-ico="spark"></span><span class="tl">Practice</span></button>
  <button class="tab" data-nav="more"><span class="ti" data-ico="grid"></span><span class="tl">Aur</span></button>
</nav>

<button class="fab" id="fabZara" data-ico="zara" aria-label="Zara se baat karo"></button>

<!-- ============ ZARA CHAT SHEET ============ -->
<div class="sheet-wrap hidden" id="zaraSheet">
  <div class="sheet-backdrop" data-close="zara"></div>
  <div class="sheet">
    <div class="sheet-head">
      <div class="zara-ava">Z</div>
      <div style="flex:1">
        <div class="sheet-title">Zara</div>
        <div class="sheet-sub" id="zaraStatus">Tumhari padhai partner · Hinglish</div>
      </div>
      <button class="icon-btn" id="btnZaraVoice" aria-label="Voice"></button>
      <button class="icon-btn" data-close="zara" data-ico="close" aria-label="Close"></button>
    </div>
    <div class="chat-body" id="chatBody"></div>
    <div class="chat-quick" id="chatQuick"></div>
    <form class="chat-input" id="chatForm">
      <button type="button" class="icon-btn" id="btnMic" data-ico="mic" aria-label="Bolo"></button>
      <input id="chatText" type="text" autocomplete="off" placeholder="Zara se kuch bhi poocho..." />
      <button type="submit" class="send-btn" data-ico="send" aria-label="Send"></button>
    </form>
  </div>
</div>

<!-- ============ GENERIC MODAL ============ -->
<div class="modal-wrap hidden" id="modal">
  <div class="modal-backdrop" data-close="modal"></div>
  <div class="modal-box" id="modalBox"></div>
</div>

<!-- ============ TOAST ============ -->
<div class="toast hidden" id="toast"></div>

<!-- data + logic -->
<script src="js/data.js"></script>
<script src="js/cloud.js"></script>
<script src="js/store.js"></script>
<script src="js/ui.js"></script>
<script src="js/zara.js"></script>
<script src="js/views.js"></script>
<script src="js/app.js"></script>
</body>
</html>
```

#### `css/app.css`

```css
/* ============================================================
   ekRaasta — app.css  (v3 · professional UI)
   Ek hi app, do mode: 90 Din (red) aur Learning (indigo).
   Light + dark. Sab local, koi external font/image nahi.
   ============================================================ */

:root,
[data-theme="dark"] {
  /* ---- DARK (default) ---- */
  --bg: #08090c;
  --bg-soft: #0c0e12;
  --surface: #101216;
  --surface-2: #151821;
  --surface-3: #1b1f28;
  --line: #232733;
  --line-strong: #2e3342;
  --text: #edf0f6;
  --text-2: #98a0b0;
  --text-3: #68707f;
  --accent: #7c5cff;
  --accent-2: #a78bfa;
  --accent-ink: #b9a6ff;
  --accent-soft: #17142e;
  --accent-line: #2c2554;
  --accent-on: #ffffff;
  --learn: #38bdf8;
  --learn-2: #7dd3fc;
  --learn-ink: #8ad8fb;
  --learn-soft: #0e2130;
  --learn-line: #1d3a4f;
  --ok: #34d399;
  --ok-soft: #0e241c;
  --warn: #fbbf24;
  --warn-soft: #241d0f;
  --shadow-xs: none;
  --shadow-sm: 0 1px 2px rgba(0,0,0,.55);
  --shadow-md: 0 18px 44px -18px rgba(0,0,0,.85);
  --nav: rgba(16,18,22,.96);
  --nav-solid: #101216;
  --radius: 18px;
  --radius-sm: 12px;
}

[data-theme="light"] {
  /* ---- LIGHT (optional) ---- */
  --bg: #f5f6fa;
  --bg-soft: #eceef4;
  --surface: #ffffff;
  --surface-2: #f7f8fb;
  --surface-3: #eef0f5;
  --line: #e4e7ee;
  --line-strong: #d5dae4;
  --text: #0f1419;
  --text-2: #596274;
  --text-3: #8b93a3;
  --accent: #6d4aff;
  --accent-2: #8b6cff;
  --accent-ink: #5133d6;
  --accent-soft: #efecff;
  --accent-line: #d9d1ff;
  --accent-on: #ffffff;
  --learn: #0284c7;
  --learn-2: #0ea5e9;
  --learn-ink: #0369a1;
  --learn-soft: #e8f4fd;
  --learn-line: #c6e4f8;
  --ok: #0e9f6e;
  --ok-soft: #e7f8f1;
  --warn: #b45309;
  --warn-soft: #fdf3e2;
  --shadow-xs: 0 1px 2px rgba(15,20,25,.04);
  --shadow-sm: 0 1px 3px rgba(15,20,25,.06), 0 6px 16px -10px rgba(15,20,25,.16);
  --shadow-md: 0 10px 30px -12px rgba(15,20,25,.22);
  --nav: rgba(255,255,255,.97);
  --nav-solid: #ffffff;
  --radius: 18px;
  --radius-sm: 12px;
}

* { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }

html, body {
  margin: 0; padding: 0;
  background: var(--bg);
  color: var(--text);
  font-family: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  font-size: 15px;
  line-height: 1.5;
  -webkit-font-smoothing: antialiased;
  text-rendering: optimizeLegibility;
}

body { padding-bottom: 96px; }

.hidden { display: none !important; }
.muted { color: var(--text-2); }
.tiny { font-size: 11.5px; }
.small { font-size: 12.5px; }
.center { text-align: center; }
.mt6 { margin-top: 6px; } .mt10 { margin-top: 10px; } .mt14 { margin-top: 14px; } .mt20 { margin-top: 20px; }
.num { font-variant-numeric: tabular-nums; letter-spacing: -.4px; }

/* ---------------- APP BAR ---------------- */
.appbar {
  position: sticky; top: 0; z-index: 30;
  display: flex; align-items: center; gap: 12px;
  padding: 12px 16px;
  background: var(--nav);
  backdrop-filter: saturate(180%) blur(14px);
  border-bottom: 1px solid var(--line);
}
.appbar-left { display: flex; align-items: center; gap: 11px; min-width: 0; flex: 1; }
.appbar-right { display: flex; align-items: center; gap: 6px; }

.logo-mark {
  width: 34px; height: 34px; border-radius: 10px; flex: 0 0 auto;
  background: var(--accent); color: #fff;
  display: grid; place-items: center;
  font-weight: 800; font-size: 13px; letter-spacing: -.5px;
  box-shadow: 0 6px 16px -6px rgba(124,92,255,.6);
}
.logo-text { font-size: 15px; font-weight: 750; letter-spacing: -.3px; line-height: 1.2; }
.logo-sub { font-size: 11.5px; color: var(--text-2); font-weight: 500; }

.icon-btn {
  width: 36px; height: 36px; flex: 0 0 auto;
  display: grid; place-items: center;
  border-radius: 10px;
  border: 1px solid var(--line);
  background: var(--surface);
  color: var(--text-2);
  cursor: pointer;
  transition: background .15s, color .15s, transform .1s;
}
.icon-btn:hover { background: var(--surface-3); color: var(--text); }
.icon-btn:active { transform: scale(.94); }
.icon-btn svg { width: 18px; height: 18px; }

/* ---------------- SCREEN ---------------- */
.screen {
  padding: 16px 16px 8px;
  max-width: 680px;
  margin: 0 auto;
}
@media (min-width: 900px) { .screen { max-width: 780px; padding-top: 24px; } }

/* section heading */
.sec {
  display: flex; align-items: baseline; justify-content: space-between;
  margin: 22px 2px 10px;
}
.sec h3 {
  margin: 0;
  font-size: 12px; font-weight: 700;
  letter-spacing: .08em; text-transform: uppercase;
  color: var(--text-3);
}
.sec .link {
  font-size: 12.5px; font-weight: 650;
  color: var(--accent); background: none; border: none;
  font-family: inherit; cursor: pointer; padding: 0;
}
.sec .link:hover { text-decoration: underline; }

/* card */
.card {
  background: var(--surface);
  border: 1px solid var(--line);
  border-radius: var(--radius);
  padding: 16px;
  box-shadow: var(--shadow-xs);
  margin-bottom: 12px;
}
.card.tight { padding: 0; overflow: hidden; }
.card.flat { box-shadow: none; background: var(--surface-2); border-color: transparent; }
.card-title { font-size: 14px; font-weight: 700; letter-spacing: -.2px; margin: 0 0 2px; }
.card-sub { font-size: 12.5px; color: var(--text-2); }

.row { display: flex; align-items: center; }
.row.gap { gap: 8px; }
.row.between { justify-content: space-between; }
.row.wrap { flex-wrap: wrap; }
.spacer { flex: 1; }

/* ---------------- MODE SWITCH ---------------- */
.modeswitch {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 4px;
  padding: 4px;
  background: var(--surface-2);
  border: 1px solid var(--line);
  border-radius: 14px;
  margin-bottom: 14px;
}
.modeswitch button {
  border: none; background: transparent; cursor: pointer;
  font-family: inherit; color: var(--text-2);
  padding: 9px 8px; border-radius: 11px;
  font-size: 13px; font-weight: 650;
  display: flex; align-items: center; justify-content: center; gap: 7px;
  transition: background .18s, color .18s, box-shadow .18s;
  position: relative;
}
.modeswitch button .dot {
  width: 6px; height: 6px; border-radius: 50%;
  background: currentColor; opacity: .45;
}
.modeswitch button[data-mode="90"].on {
  background: var(--accent-soft);
  color: var(--accent-ink);
  box-shadow: inset 0 0 0 1px var(--accent-line);
}
.modeswitch button[data-mode="learn"].on {
  background: var(--learn-soft);
  color: var(--learn-ink);
  box-shadow: inset 0 0 0 1px var(--learn-line);
}
.modeswitch button.on .dot { opacity: 1; }
.modeswitch .count {
  font-size: 10.5px; font-weight: 700; opacity: .75;
  background: rgba(255,255,255,.08); padding: 1px 6px; border-radius: 20px;
}
.modeswitch button.on .count { background: currentColor; color: var(--surface); }
.modeswitch button[data-mode="90"].on .count { background: var(--accent-soft); color: var(--accent-ink); }
.modeswitch button[data-mode="learn"].on .count { background: var(--learn-soft); color: var(--learn-ink); }

/* ---------------- HERO ---------------- */
.hero {
  position: relative;
  border-radius: 20px;
  padding: 18px 18px 16px;
  margin-bottom: 16px;
  overflow: hidden;
  color: #fff;
  isolation: isolate;
}
.hero-top { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
.hero-pill {
  font-size: 11px; font-weight: 750; letter-spacing: -.2px;
  padding: 4px 9px; border-radius: 999px;
  background: rgba(255,255,255,.2); color: #fff;
}
.hero-bar {
  height: 5px; border-radius: 999px; margin-top: 14px;
  background: rgba(255,255,255,.24); overflow: hidden;
}
.hero-bar i {
  display: block; height: 100%; border-radius: 999px; background: #fff;
  transition: width .5s cubic-bezier(.4,0,.2,1);
}
.hero.m90 { background: linear-gradient(145deg, #6d4aff 0%, #4b2fd6 46%, #241a63 100%); }
.hero.mlearn { background: linear-gradient(145deg, #0b82c4 0%, #0a5f92 46%, #07304a 100%); }
.hero::after {
  content: ""; position: absolute; z-index: -1;
  width: 220px; height: 220px; border-radius: 50%;
  right: -70px; top: -90px;
  background: rgba(255,255,255,.14);
}
.hero::before {
  content: ""; position: absolute; z-index: -1;
  width: 140px; height: 140px; border-radius: 50%;
  right: 30px; bottom: -80px;
  background: rgba(255,255,255,.08);
}
.hero .eyebrow {
  font-size: 10.5px; font-weight: 700; letter-spacing: .12em;
  text-transform: uppercase; opacity: .8;
}
.hero h2 { margin: 8px 0 0; font-size: 22px; font-weight: 750; letter-spacing: -.5px; line-height: 1.2; }
.hero p { margin: 4px 0 0; font-size: 13px; opacity: .85; }
.hero-stats { display: flex; margin-top: 15px; }
.hero-stat { flex: 1; min-width: 0; position: relative; padding-left: 12px; }
.hero-stat:first-child { padding-left: 0; }
.hero-stat + .hero-stat::before { content: ""; position: absolute; left: 0; top: 3px; bottom: 3px; width: 1px; background: rgba(255,255,255,.22); }
.hero-stat b { display: block; font-size: 19px; font-weight: 750; line-height: 1.15; font-variant-numeric: tabular-nums; }
.hero-stat span { font-size: 10.5px; opacity: .82; font-weight: 550; white-space: nowrap; display: block; }
.hero-ring { position: absolute; right: 18px; top: 20px; width: 62px; height: 62px; }
.hero-ring svg { transform: rotate(-90deg); }
.hero-ring .bg { stroke: rgba(255,255,255,.26); }
.hero-ring .fg { stroke: #fff; stroke-linecap: round; transition: stroke-dashoffset .6s cubic-bezier(.4,0,.2,1); }
.hero-ring .pct {
  position: absolute; inset: 0; display: grid; place-items: center;
  font-size: 13px; font-weight: 750; font-variant-numeric: tabular-nums;
}
.hero .hint { margin-top: 14px; font-size: 11.5px; opacity: .78; }

.test-box {
  display: flex; align-items: flex-start; gap: 8px;
  margin-top: 10px; padding: 10px 12px; border-radius: 12px;
  font-size: 12px; line-height: 1.5;
}
.test-box svg { width: 15px; height: 15px; flex: 0 0 auto; margin-top: 1px; }
.test-box.ok { background: var(--ok-soft); color: var(--ok); }
.test-box.bad { background: var(--warn-soft); color: var(--warn); }

/* ---------------- DAILY BLOCKS ---------------- */
.blk {
  display: flex; align-items: center; gap: 12px;
  padding: 13px 15px;
  border-bottom: 1px solid var(--line);
  cursor: pointer;
  transition: background .15s;
}
.blk:last-child { border-bottom: none; }
.blk:hover { background: var(--surface-2); }
.blk:active { background: var(--surface-3); }
.cb {
  width: 22px; height: 22px; flex: 0 0 auto;
  border-radius: 7px; border: 2px solid var(--line-strong);
  display: grid; place-items: center;
  color: #fff;
  transition: background .18s, border-color .18s, transform .12s;
}
.cb svg { width: 13px; height: 13px; opacity: 0; stroke-width: 3; }
.blk.done .cb, .task.done .cb { background: var(--ok); border-color: var(--ok); }
.blk.done .cb svg, .task.done .cb svg { opacity: 1; }
.blk-main { flex: 1; min-width: 0; }
.blk-title { font-size: 14px; font-weight: 620; letter-spacing: -.15px; line-height: 1.35; display: flex; align-items: baseline; gap: 7px; }
.blk.done .blk-title { color: var(--text-3); text-decoration: line-through; text-decoration-thickness: 1px; }
.blk-hint { font-size: 11.5px; color: var(--text-2); margin-top: 3px; font-variant-numeric: tabular-nums; }
.blk-time {
  font-size: 11px; font-weight: 650; color: var(--text-3);
  font-variant-numeric: tabular-nums;
}

.trk { width: 6px; height: 6px; border-radius: 50%; flex: 0 0 auto; display: inline-block; transform: translateY(-2px); }
.trk-90 { background: var(--accent); }
.trk-learn { background: var(--learn); }
.trk-both { background: var(--text-3); }

/* plan section head */
.blk-head { margin: 2px 2px 12px; }
.blk-head-t { font-size: 16.5px; font-weight: 750; letter-spacing: -.35px; }
.blk-head-s { font-size: 11.5px; color: var(--text-2); margin-top: 2px; }

.head-bar { padding: 0 16px 11px; }
.head-bar .bar { height: 5px; }

/* tag */
.tag {
  font-size: 10px; font-weight: 750; letter-spacing: .04em; text-transform: uppercase;
  padding: 3px 7px; border-radius: 6px;
  background: var(--surface-3); color: var(--text-2);
}
.tag.red { background: var(--accent-soft); color: var(--accent-ink); }
.tag.indigo { background: var(--learn-soft); color: var(--learn-ink); }
.tag.green { background: var(--ok-soft); color: var(--ok); }
.tag.amber { background: var(--warn-soft); color: var(--warn); }

/* ---------------- BUTTONS ---------------- */
.btn {
  white-space: nowrap;
  border: 1px solid var(--line);
  background: var(--surface);
  color: var(--text);
  border-radius: 12px;
  padding: 11px 16px;
  font-size: 13px; font-weight: 650;
  font-family: inherit; cursor: pointer;
  transition: background .15s, transform .1s, border-color .15s;
  display: inline-flex; align-items: center; justify-content: center; gap: 7px;
}
.btn:hover { background: var(--surface-2); border-color: var(--line-strong); }
.btn:active { transform: scale(.985); }
.btn.block { display: flex; width: 100%; }
.btn.primary {
  background: var(--text); color: var(--surface); border-color: var(--text);
}
.btn.primary:hover { background: var(--text); opacity: .9; }
.btn.accent { background: var(--accent); color: #fff; border-color: var(--accent); }
.btn.indigo { background: var(--learn); color: #fff; border-color: var(--learn); }
.btn.soft { background: var(--surface-3); border-color: transparent; color: var(--text); }
.btn.danger { background: var(--accent-soft); border-color: transparent; color: var(--accent-ink); }
.btn.ghost { background: transparent; border-color: var(--line); }
.btn.sm { padding: 7px 12px; font-size: 12px; border-radius: 9px; }
.btn svg { width: 15px; height: 15px; }
.btn:disabled { opacity: .45; pointer-events: none; }

/* ---------------- FORMS ---------------- */
label.f { display: block; margin-bottom: 12px; }
label.f > span {
  display: block; font-size: 11.5px; font-weight: 650;
  color: var(--text-2); margin-bottom: 6px; letter-spacing: .01em;
}
input, textarea, select {
  width: 100%;
  background: var(--surface-2);
  border: 1px solid var(--line);
  color: var(--text);
  border-radius: 11px;
  padding: 11px 12px;
  font-size: 13.5px;
  font-family: inherit;
  transition: border-color .15s, box-shadow .15s, background .15s;
}
input:hover, textarea:hover, select:hover { border-color: var(--line-strong); }
input:focus, textarea:focus, select:focus {
  outline: none;
  background: var(--surface);
  border-color: var(--text-3);
  box-shadow: 0 0 0 3px var(--surface-3);
}
textarea { resize: vertical; min-height: 92px; line-height: 1.55; }
input[type="date"] { color-scheme: light; }
[data-theme="dark"] input[type="date"] { color-scheme: dark; }
input[type="range"] {
  padding: 0; background: transparent; border: none; height: 26px;
  accent-color: var(--accent);
}
.g2 { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
.g3 { display: grid; grid-template-columns: repeat(3,1fr); gap: 10px; }

/* ---------------- PROGRESS ---------------- */
.bar { height: 6px; background: var(--surface-3); border-radius: 20px; overflow: hidden; }
.bar > i {
  display: block; height: 100%; border-radius: 20px;
  background: var(--accent);
  transition: width .5s cubic-bezier(.4,0,.2,1);
}
.bar.indigo > i { background: var(--learn); }
.bar.ok > i { background: var(--ok); }
.bar.thin { height: 4px; }

/* ---------------- LIST ---------------- */
.item {
  display: flex; align-items: center; gap: 12px;
  padding: 13px 16px;
  border-bottom: 1px solid var(--line);
  cursor: pointer;
  transition: background .15s;
}
.item:last-child { border-bottom: none; }
.item:hover { background: var(--surface-2); }
.item-ico {
  width: 34px; height: 34px; border-radius: 10px; flex: 0 0 auto;
  display: grid; place-items: center;
  background: var(--surface-3); color: var(--text-2);
}
.item-ico svg { width: 16px; height: 16px; }
.item-body { flex: 1; min-width: 0; }
.item-title { font-size: 13.5px; font-weight: 650; letter-spacing: -.1px; }
.item-sub { font-size: 11.5px; color: var(--text-2); margin-top: 1px; }
.item-right { color: var(--text-3); }
.item-right svg { width: 16px; height: 16px; }

/* ---------------- PLAN LISTS ---------------- */
.phase { padding: 0; overflow: hidden; margin-bottom: 10px; }
.phase-head {
  display: flex; align-items: center; gap: 13px;
  padding: 14px 16px 10px; cursor: pointer;
  transition: background .15s;
}
.phase-head:hover { background: var(--surface-2); }
.phase-num {
  width: 30px; height: 30px; border-radius: 9px; flex: 0 0 auto;
  background: var(--surface-3); color: var(--text-2);
  display: grid; place-items: center;
  font-weight: 750; font-size: 12.5px;
  font-variant-numeric: tabular-nums;
}
.phase.is-90 .phase-num { background: var(--accent-soft); color: var(--accent-ink); }
.phase.is-learn .phase-num { background: var(--learn-soft); color: var(--learn-ink); }
.phase-meta { flex: 1; min-width: 0; }
.phase-name { font-size: 13.5px; font-weight: 700; letter-spacing: -.15px; }
.phase-range { font-size: 11.5px; color: var(--text-2); margin-top: 1px; }
.ph-end { display: flex; align-items: center; gap: 6px; flex: 0 0 auto; }
.cnt { font-size: 11px; font-weight: 700; color: var(--text-3); background: var(--surface-2); padding: 3px 7px; border-radius: 7px; letter-spacing: -.2px; }
.chev { color: var(--text-3); transition: transform .22s; display: grid; place-items: center; }
.chev svg { width: 16px; height: 16px; }
.chev.open { transform: rotate(180deg); }

.task { border-top: 1px solid var(--line); padding: 13px 16px; }
.task-top { display: flex; align-items: flex-start; gap: 11px; cursor: pointer; }
.task-txt { flex: 1; font-size: 13px; font-weight: 600; line-height: 1.45; }
.task.done .task-txt { color: var(--text-3); text-decoration: line-through; }
details.how {
  margin: 9px 0 0 33px;
  font-size: 12px;
}
details.how summary {
  cursor: pointer; color: var(--text-2); font-weight: 650;
  list-style: none; display: flex; align-items: center; gap: 5px;
}
details.how summary::-webkit-details-marker { display: none; }
details.how summary::before {
  content: ""; width: 5px; height: 5px; border-right: 1.6px solid currentColor;
  border-bottom: 1.6px solid currentColor; transform: rotate(-45deg);
  transition: transform .2s; margin-right: 2px;
}
details.how[open] summary::before { transform: rotate(45deg); }
details.how .how-body {
  margin-top: 8px; padding: 11px 12px;
  background: var(--surface-2); border-radius: 11px;
  color: var(--text-2); line-height: 1.55;
}
details.how ol { margin: 0; padding-left: 17px; }
details.how li { margin-bottom: 5px; }
details.how li:last-child { margin-bottom: 0; }

/* month card */
.mon-head { display: flex; gap: 13px; align-items: center; padding: 14px 16px 10px; cursor: pointer; }
.mon-head:hover { background: var(--surface-2); }
.mon-badge {
  width: 42px; height: 42px; border-radius: 12px; flex: 0 0 auto;
  background: var(--learn-soft); color: var(--learn-ink);
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  line-height: 1;
}
.mon-badge b { font-size: 15px; font-weight: 750; font-variant-numeric: tabular-nums; }
.mon-badge i { font-size: 8px; font-style: normal; font-weight: 700; letter-spacing: .06em; opacity: .8; margin-top: 1px; }
.mon-body { border-top: 1px solid var(--line); padding: 14px 16px; }
.week { display: flex; gap: 11px; padding: 9px 0; border-bottom: 1px dashed var(--line); cursor: pointer; }
.week:last-of-type { border-bottom: none; }
.week-n {
  font-size: 9.5px; font-weight: 750; letter-spacing: .04em;
  color: var(--learn-ink); background: var(--learn-soft);
  border-radius: 5px; padding: 3px 6px; height: fit-content; flex: 0 0 auto;
  margin-top: 1px;
}
.week-txt { font-size: 12.5px; flex: 1; line-height: 1.5; }
.week.done .week-txt { color: var(--text-3); text-decoration: line-through; }

.proj-box {
  background: var(--surface-2);
  border-radius: 12px;
  padding: 13px;
  font-size: 12.5px;
  margin-top: 12px;
}
.proj-box b { font-size: 12.5px; }
.proj-box ol { margin: 7px 0 0; padding-left: 17px; color: var(--text-2); }
.proj-box li { margin-bottom: 4px; }

.res-links { display: flex; flex-direction: column; gap: 2px; margin-top: 12px; }
.res-link {
  font-size: 12.5px; color: var(--text); text-decoration: none; font-weight: 600;
  display: flex; align-items: center; gap: 8px;
  padding: 9px 10px; border-radius: 10px;
  transition: background .15s;
}
.res-link:hover { background: var(--surface-2); color: var(--accent); }
.res-link svg { width: 14px; height: 14px; color: var(--text-3); flex: 0 0 auto; }
.res-link:hover svg { color: var(--accent); }

/* ---------------- PRACTICE ---------------- */
.seg {
  display: flex; gap: 2px; padding: 3px;
  background: var(--surface-3); border-radius: 12px; margin-bottom: 14px;
}
.seg button {
  flex: 1; border: none; background: transparent;
  color: var(--text-2); font-family: inherit;
  font-size: 12.5px; font-weight: 650;
  padding: 8px 6px; border-radius: 9px; cursor: pointer;
  transition: background .18s, color .18s;
}
.seg button:hover { color: var(--text); }
.seg button.on { background: var(--surface); color: var(--text); box-shadow: var(--shadow-xs); }

.score-head { display: flex; align-items: center; gap: 16px; }
.score-num {
  font-size: 36px; font-weight: 750; line-height: 1; letter-spacing: -1.5px;
  font-variant-numeric: tabular-nums;
}
.score-num.good { color: var(--ok); }
.score-num.mid { color: var(--warn); }
.score-num.low { color: var(--accent); }
.score-meta { flex: 1; }

.fb { display: flex; gap: 10px; padding: 10px 0; border-bottom: 1px solid var(--line); font-size: 12.5px; line-height: 1.5; }
.fb:last-child { border-bottom: none; }
.fb-dot { width: 6px; height: 6px; border-radius: 50%; margin-top: 7px; flex: 0 0 auto; }
.fb-dot.good { background: var(--ok); }
.fb-dot.bad { background: var(--accent); }
.fb-dot.meh { background: var(--warn); }

.tpl {
  padding: 11px 12px; background: var(--surface-2);
  border-radius: 10px; font-size: 12.5px; margin-bottom: 7px;
  border-left: 2px solid var(--line-strong);
}
.tpl b { display: block; font-size: 10.5px; color: var(--text-3); letter-spacing: .05em; text-transform: uppercase; margin-bottom: 3px; }

.qbox { font-size: 15px; font-weight: 700; letter-spacing: -.2px; margin-bottom: 14px; line-height: 1.45; }
.opt {
  display: block; width: 100%; text-align: left;
  padding: 12px 14px; margin-bottom: 8px;
  background: var(--surface-2); border: 1px solid var(--line);
  border-radius: 12px; font-size: 13px; font-family: inherit;
  color: var(--text); cursor: pointer;
  transition: background .15s, border-color .15s;
}
.opt:hover { background: var(--surface-3); border-color: var(--line-strong); }
.opt.right { background: var(--ok-soft); border-color: var(--ok); color: var(--ok); font-weight: 650; }
.opt.wrong { background: var(--accent-soft); border-color: var(--accent); color: var(--accent-ink); font-weight: 650; }

/* ---------------- CHAT ---------------- */
.sheet-wrap { position: fixed; inset: 0; z-index: 80; }
.sheet-backdrop { position: absolute; inset: 0; background: rgba(9,11,14,.5); backdrop-filter: blur(3px); }
.sheet {
  position: absolute; inset: 0;
  background: var(--surface);
  display: flex; flex-direction: column;
  max-width: 620px; margin: 0 auto;
  animation: sheetIn .28s cubic-bezier(.2,.8,.2,1);
}
@keyframes sheetIn { from { opacity: 0; transform: translateY(14px); } to { opacity: 1; transform: none; } }
@media (min-width: 720px) {
  .sheet { inset: 28px auto 28px 50%; transform: translateX(-50%); border-radius: 20px; box-shadow: var(--shadow-md); overflow: hidden; }
}
.sheet-head {
  display: flex; align-items: center; gap: 11px;
  padding: 12px 14px; border-bottom: 1px solid var(--line);
  background: var(--surface);
}
.sheet-title { font-size: 14.5px; font-weight: 700; }
.sheet-sub { font-size: 11px; color: var(--text-2); }
.zara-ava {
  width: 36px; height: 36px; border-radius: 50%; flex: 0 0 auto;
  background: linear-gradient(140deg, var(--accent-2), var(--accent));
  color: #fff; font-weight: 750; font-size: 14px;
  display: grid; place-items: center;
}
.chat-body {
  flex: 1; overflow-y: auto;
  padding: 16px 14px;
  display: flex; flex-direction: column; gap: 10px;
  background: var(--bg-soft);
}
.msg {
  max-width: 84%; padding: 11px 13px; border-radius: 16px;
  font-size: 13.5px; white-space: pre-wrap; line-height: 1.5;
  animation: msgIn .22s ease-out;
}
@keyframes msgIn { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: none; } }
.msg.zara { background: var(--surface); align-self: flex-start; border-bottom-left-radius: 6px; box-shadow: var(--shadow-xs); border: 1px solid var(--line); }
.msg.user { background: var(--text); color: var(--surface); align-self: flex-end; border-bottom-right-radius: 6px; }
.msg.typing { color: var(--text-3); font-style: italic; }
.chat-quick { display: flex; gap: 7px; overflow-x: auto; padding: 10px 14px; border-top: 1px solid var(--line); background: var(--surface); }
.qchip {
  white-space: nowrap; font-size: 12px; font-weight: 600;
  padding: 8px 12px; border-radius: 20px;
  background: var(--surface-2); border: 1px solid var(--line);
  color: var(--text); font-family: inherit; cursor: pointer;
  transition: background .15s;
}
.qchip:hover { background: var(--surface-3); }
.chat-input {
  display: flex; gap: 8px; padding: 10px 12px calc(10px + env(safe-area-inset-bottom));
  border-top: 1px solid var(--line); background: var(--surface);
}
.chat-input input { flex: 1; border-radius: 22px; padding: 11px 16px; }
.send-btn {
  width: 42px; height: 42px; border-radius: 50%; flex: 0 0 auto;
  background: var(--text); color: var(--surface); border: none; cursor: pointer;
  display: grid; place-items: center;
  transition: transform .1s;
}
.send-btn:active { transform: scale(.92); }
.send-btn svg { width: 17px; height: 17px; }

/* ---------------- MODAL ---------------- */
.modal-wrap { position: fixed; inset: 0; z-index: 90; }
.modal-backdrop { position: absolute; inset: 0; background: rgba(9,11,14,.5); backdrop-filter: blur(3px); }
.modal-box {
  position: absolute; left: 0; right: 0; bottom: 0;
  background: var(--surface);
  border-radius: 22px 22px 0 0;
  padding: 18px 16px calc(18px + env(safe-area-inset-bottom));
  max-height: 88vh; overflow-y: auto;
  max-width: 620px; margin: 0 auto;
  animation: sheetIn .26s cubic-bezier(.2,.8,.2,1);
}
@media (min-width: 720px) {
  .modal-box {
    inset: auto; position: fixed; top: 50%; left: 50%;
    transform: translate(-50%, -50%);
    border-radius: 20px; max-width: 560px; width: calc(100% - 40px);
    box-shadow: var(--shadow-md);
  }
}
.modal-title { font-size: 16px; font-weight: 750; margin: 0 0 4px; }

/* ---------------- TABBAR + FAB ---------------- */
.tabbar {
  position: fixed; left: 0; right: 0; bottom: 0; z-index: 40;
  display: flex; align-items: stretch;
  height: 64px; padding-bottom: env(safe-area-inset-bottom);
  background: var(--nav);
  backdrop-filter: saturate(180%) blur(16px);
  border-top: 1px solid var(--line);
}
.tab {
  flex: 1; border: none; background: none;
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  gap: 3px; color: var(--text-3); font-family: inherit;
  font-size: 10px; font-weight: 600; cursor: pointer;
  transition: color .15s;
  position: relative;
}
.tab .ti {
  display: grid; place-items: center;
  width: 44px; height: 26px; border-radius: 9px;
  transition: background .18s, color .18s;
}
.tab .ti svg { width: 20px; height: 20px; }
.tab:hover { color: var(--text-2); }
.tab.on { color: var(--text); font-weight: 700; }
.tab.on .ti { background: var(--accent-soft); color: var(--accent-ink); }

.fab {
  position: fixed; right: 16px; bottom: 78px; z-index: 45;
  width: 48px; height: 48px; border-radius: 50%;
  border: none; cursor: pointer;
  background: linear-gradient(145deg, var(--accent-2), var(--accent));
  color: var(--accent-on);
  display: grid; place-items: center;
  box-shadow: 0 10px 26px -8px rgba(124,92,255,.7);
  transition: transform .12s, box-shadow .2s;
}
.fab:hover { transform: translateY(-2px); box-shadow: 0 16px 30px -8px rgba(124,92,255,.85); }
.fab:active { transform: scale(.94); }
.fab svg { width: 23px; height: 23px; }

/* ---------------- TOAST ---------------- */
.toast {
  position: fixed; left: 50%; bottom: 84px; transform: translateX(-50%);
  background: var(--text); color: var(--surface);
  padding: 11px 16px; border-radius: 12px;
  font-size: 12.5px; font-weight: 600;
  z-index: 100; max-width: 86vw; text-align: center;
  box-shadow: var(--shadow-md);
  animation: toastIn .2s ease-out;
}
@keyframes toastIn { from { opacity: 0; transform: translate(-50%, 8px); } to { opacity: 1; transform: translate(-50%, 0); } }

/* ---------------- MISC ---------------- */
.empty { text-align: center; padding: 30px 18px; color: var(--text-2); font-size: 12.5px; line-height: 1.6; }
.empty svg { width: 26px; height: 26px; margin-bottom: 10px; opacity: .35; }
.hr-label {
  font-size: 10.5px; font-weight: 700; color: var(--text-3);
  letter-spacing: .08em; text-transform: uppercase; margin: 16px 2px 8px;
}
.divider { height: 1px; background: var(--line); margin: 14px 0; }
.kv { display: flex; justify-content: space-between; gap: 10px; padding: 7px 0; font-size: 12.5px; }
.kv b { font-weight: 650; font-variant-numeric: tabular-nums; }
.badge {
  font-size: 10.5px; font-weight: 700; padding: 4px 9px; border-radius: 20px;
  background: var(--surface-3); color: var(--text-2);
}
.badge.ok { background: var(--ok-soft); color: var(--ok); }
.badge.warn { background: var(--warn-soft); color: var(--warn); }
.badge.red { background: var(--accent-soft); color: var(--accent-ink); }
.badge.indigo { background: var(--learn-soft); color: var(--learn-ink); }

.stat-row { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 12px; }
.stat {
  background: var(--surface); border: 1px solid var(--line);
  border-radius: 14px; padding: 12px;
  text-align: center;
}
.stat b { display: block; font-size: 20px; font-weight: 750; letter-spacing: -.6px; font-variant-numeric: tabular-nums; }
.stat span { font-size: 10.5px; color: var(--text-2); font-weight: 550; }

.money-big { font-size: 32px; font-weight: 750; letter-spacing: -1.4px; font-variant-numeric: tabular-nums; line-height: 1.1; }

/* print */
#printArea { display: none; }
/* ---------------- DESKTOP: floating pill nav ---------------- */
@media (min-width: 900px) {
  body { padding-bottom: 120px; }
  .appbar { padding: 10px max(20px, calc((100vw - 780px) / 2)); }
  .tabbar {
    left: 0; right: 0; transform: none; bottom: 0;
    width: auto; height: 58px; border-radius: 0;
    border-top: 1px solid var(--line); box-shadow: none;
    padding: 0 max(0px, calc((100vw - 780px) / 2));
    background: var(--nav-solid);
  }
  .tab .ti svg { width: 20px; height: 20px; }
  .tab { font-size: 10.5px; }
  .fab { right: calc(50% - 420px); bottom: 76px; }
  .hero { padding: 24px 26px 22px; }
  .hero h2 { font-size: 27px; }
}

@media print {
  body > *:not(#printArea) { display: none !important; }
  #printArea { display: block !important; padding: 18px; color: #000; background: #fff; }
  body { background: #fff; padding: 0; }
}
```

#### `js/data.js`

```js
/* ============================================================
   data.js — saara content ek jagah
   (90-din plan, 12-mahine ka learning roadmap, practice material)
   ============================================================ */

/* ---------- ROZ KE 5 BLOCK (90 + Learning dono) ---------- */
const DAILY_BLOCKS = [
  { id: 'learn',   track: 'learn', title: 'Learning — video + code along', mins: 50, hint: 'Learning tab: is hafte ka topic, saath me code karo' },
  { id: 'build',   track: 'learn', title: 'Learning — project ka kaam',     mins: 50, hint: 'Is month ka project aage badhao' },
  { id: 'cash',    track: '90',    title: 'Paisa — Karya / platform / apply', mins: 40, hint: '90 Din tab: aaj ka cash task' },
  { id: 'english', track: '90',    title: 'Practice — English drill',        mins: 20, hint: 'Practice tab: 150 words feedback' },
  { id: 'log',     track: 'both',  title: 'Log likho',                       mins: 5,  hint: 'Kya banaya · kya atka · kal kya' }
];
const TOTAL_MINS = 165; // 2h 45m core, +30-45 min buffer = ~3.5 ghante

/* ============================================================
   PART 1 — 90 DIN (fixed dates)
   ============================================================ */
const PLAN_90 = [
  {
    id: 'p1', name: 'Foundation + Proof', range: 'Day 1-30',
    goal: 'Skill haath me wapas + dikhane layak proof',
    tasks: [
      {
        t: 'Python basics revise — functions, dict, list, files, try/except',
        how: [
          'Learning tab ka Month 1 kholo — wahi tumhara syllabus hai',
          'Roz 1 topic: functions → dict/list → file I/O → try/except',
          'Har topic pe 3 chhote script likho, GitHub pe push karo'
        ],
        why: 'Interview me Python ka basic compulsory hai.'
      },
      {
        t: '3 working demo banao (chalte hon, sirf code na ho)',
        how: [
          'Demo 1: number guessing game (ban chuka hai — sudharo)',
          'Demo 2: unit converter (ban chuka hai — main() + constants add karo)',
          'Demo 3: naya — expense tracker ya CSV cleaner',
          'Har demo ka README + 60 sec screen recording (Loom free)'
        ],
        why: 'Client/recruiter code nahi, chalta hua cheez dekhta hai.'
      },
      {
        t: 'GitHub profile saaf karo',
        how: [
          'Username professional banao (gamingafzu nahi)',
          'Har repo me README: kya hai, kaise chalayein, kya seekha',
          '4 best repos pin karo, file names me typo check karo'
        ]
      },
      {
        t: 'Portfolio page banao',
        how: ['GitHub Pages pe free — simple HTML', 'Har project: Problem → Solution → Demo → Link'],
        why: 'Ek link bhejna padta hai, 5 link nahi.'
      },
      {
        t: 'Karya app install + profile 100%',
        how: [
          'Play Store: Karya (DAIA Tech)',
          'Profile me Gujarati + Hindi + English teeno language add karo',
          'Task mile to turant karo — pehle 10 task slow, quality pe'
        ],
        why: 'Pehla paisa — English ki zarurat sabse kam.'
      },
      {
        t: 'Roz 1 English eval drill (Practice tab)',
        how: [
          'Zara se ek bad AI answer + rubric maango',
          '150 words me feedback likho — pehle Hindi me socho, phir English',
          'Practice → English me save karo, galtiyan note karo'
        ],
        why: 'Yahi skill Outlier/DataAnnotation me paisa deti hai.'
      }
    ]
  },
  {
    id: 'p2', name: 'Pehla Paisa', range: 'Day 31-60',
    goal: 'Kam se kam ek rupya apne dum pe',
    tasks: [
      {
        t: 'Outlier — multilingual Hindi track apply',
        how: [
          'Generalist English track nahi — multilingual select karo',
          'ID + selfie verification (VPN band)',
          'Assessment ek hi sitting me, jaldi mat karo',
          'Fail ho to 30-90 din baad dusre domain se retry'
        ],
        why: 'Hindi/Gujarati me competition kam hai — yahi tumhara edge.'
      },
      {
        t: '2 local client (Godhra) — ₹3,000-5,000',
        how: [
          '25 dukaan/coaching ki list banao',
          'Offer: "PDF bills se Excel data" ₹500-1,500 (ek shaam ka kaam)',
          'Ya: "WhatsApp enquiry auto-reply" ₹3,000-5,000',
          '50% advance lo — yeh rule kabhi na todo'
        ]
      },
      {
        t: 'Python tuition — 3 students (₹800-1,500 each)',
        how: [
          '10 coaching class pe jao — "aapke students ko Python batch doon"',
          'Hafta me 2 din, 1 ghanta, ghar pe',
          'Pehla demo class free'
        ],
        why: 'Sabse fast cash, aur padhane se apni basics pakki.'
      },
      {
        t: '30 eval drills complete',
        how: ['Roz 1 — Practice tab me save hoga', 'Hafte me galtiyan wali list dobara padho']
      },
      {
        t: '3 testimonial lo (video ya written)',
        how: ['Kaam ke baad turant maango', 'Video 30 sec — "kya kaam hua, kitna time bacha"']
      },
      {
        t: 'Fiverr pe 3 gig live',
        how: [
          '"Fix your Python script in 24h" — $10',
          '"PDF/Excel data to clean Google Sheet" — $10',
          '"Scrape website data to Excel" — $15',
          'Har gig me 40 sec screen recording'
        ]
      }
    ]
  },
  {
    id: 'p3', name: 'Coding Track + Foreign', range: 'Day 61-90',
    goal: 'Rate double + ek foreign client',
    tasks: [
      {
        t: 'Coding track assessment (Outlier / DataAnnotation)',
        how: [
          'Pehle 3 hafte coding practice — GitHub pe doosre ka code padho',
          'Prompt ke constraints 3 baar padho — 40% reject isi wajah se',
          'Pehle bug fix, baad me refactor — refactor boring rakho'
        ],
        why: 'Coding track $22-32/hr deta hai — generalist ka double.'
      },
      {
        t: 'Hafte me 5 proposals (Upwork/Fiverr)',
        how: [
          'Sirf: n8n, Zapier migration, email automation, API integration',
          'Feature list nahi — unke problem ka 60 sec Loom bhejo',
          'Pehle 3-4 job $50-150 me (sirf review ke liye)'
        ]
      },
      {
        t: '1 foreign client ($300+)',
        how: [
          'Roz 20 cold email/DM — business owner ko',
          'Subject: "quick idea for [Business]"',
          '50% advance (Wise/Payoneer) — bina advance kaam nahi'
        ]
      },
      {
        t: 'Portfolio me 4 case studies',
        how: ['Problem → kya banaya → result → demo video', 'Numbers likho: "6 ghante bachaye", "₹X"']
      },
      {
        t: 'Weekly scorecard har Sunday (More tab)',
        how: ['6 number: ghante, repo, eval, outreach, reply, ₹']
      }
    ]
  },
  {
    id: 'p4', name: 'Repeat + Scale', range: 'Day 91-120',
    goal: '90 din khatam — ab repeatable banao',
    tasks: [
      {
        t: '90 din ka review — kya chala, kya nahi',
        how: ['Platform wise paisa dekho', 'Jo channel sabse zyada reply de raha hai — sirf wahi karo']
      },
      {
        t: 'Retainer client banao (monthly ₹1,000-2,000)',
        how: ['Ek baar ka kaam → monthly maintenance me badlo', '2-3 retainer = base income']
      },
      {
        t: 'Naya 90-din cycle: rate 2x',
        how: ['Jo kaam ₹3,000 me kiya, wahi ₹6,000 me becho', 'Case study + testimonial ke saath']
      }
    ]
  }
];

/* ============================================================
   PART 2 — 12 MAHINE LEARNING (flexible, 13 bhi chalega)
   Tumhare hisaab se badla: degree nahi hai, paisa chahiye,
   civil engineer ka context hata diya.
   ============================================================ */
const LEARN_MONTHS = [
  {
    m: 1, title: 'Python Foundations', focus: 'Programming base — sab isi pe khada hai',
    weeks: [
      { w: 'W1', d: 'Python syntax, variables, data types, loops, conditionals' },
      { w: 'W2', d: 'Functions, OOP basics (class/object), error handling, file I/O' },
      { w: 'W3', d: 'Statistics basics — mean/median/mode, std dev, distribution, correlation' },
      { w: 'W4', d: '30+ chhote scripts + mini project' }
    ],
    project: {
      t: 'Python scripts kit + expense tracker',
      steps: ['unit converter (ban chuka)', 'number guessing game (ban chuka)', 'expense tracker (file me save kare)', 'CSV cleaner (duplicate + empty rows hatao)']
    },
    res: [
      { l: 'Python Full Course — CodeWithHarry (Hindi)', u: 'https://youtube.com/playlist?list=PLu0W_9lII9agwh1XjRt242xIpHhPT2llg' },
      { l: '100 Days of Python (Days 1-25) — CampusX', u: 'https://youtube.com/playlist?list=PLKnIA16_Rmvb1RYR-iTA_hzckhdONtSW4' }
    ],
    note: 'Excel/dashboard wala part skip karo — AI engineer ko Excel ka basic kaafi hai. Time Python pe lagao.'
  },
  {
    m: 2, title: 'Pandas / NumPy + Git', focus: 'Data se kaam karna + professional version control',
    weeks: [
      { w: 'W1', d: 'NumPy — arrays, vectorized operations, broadcasting' },
      { w: 'W2', d: 'Pandas — Series/DataFrame, filter, groupby, merge, missing values' },
      { w: 'W3', d: 'Git & GitHub — commit, branch, pull request; Colab/Jupyter workflow' },
      { w: 'W4', d: 'Real dataset pe apply karo + GitHub pe push' }
    ],
    project: {
      t: 'Dataset analysis notebook',
      steps: ['Kaggle se ek dataset lo (sales ya HR)', 'Pandas se clean karo', '3-4 insight likho', 'README ke saath GitHub pe']
    },
    res: [
      { l: '100 Days of Python (Days 26-60) — CampusX', u: 'https://youtube.com/playlist?list=PLKnIA16_Rmvb1RYR-iTA_hzckhdONtSW4' },
      { l: 'Git & GitHub — YouTube pe "Git and GitHub for beginners" search karo', u: 'https://www.youtube.com/results?search_query=git+and+github+for+beginners+hindi' }
    ],
    note: 'Yeh month tumhare liye double kaam ka hai — Pandas wahi skill hai jo freelance me sabse pehle bikti hai (data cleaning).'
  },
  {
    m: 3, title: 'EDA + Visualization', focus: 'Data ko samajhna — jo log skip karte hain aur baad me pachhtate hain',
    weeks: [
      { w: 'W1', d: 'Matplotlib & Seaborn — plots, styling, subplots' },
      { w: 'W2', d: 'EDA process — univariate/bivariate, outliers, missing values' },
      { w: 'W3', d: 'Kaggle dataset pe full EDA' },
      { w: 'W4', d: 'SQL basics shuru (SELECT, WHERE, GROUP BY, JOIN)' }
    ],
    project: {
      t: 'EDA report — portfolio piece #1',
      steps: ['Kaggle dataset chuno (house price ya HR attrition)', '10+ visuals banao', 'Har visual ke saath 2 line insight likho', 'GitHub pe notebook + README']
    },
    res: [
      { l: 'EDA — CampusX (Session 29)', u: 'https://www.youtube.com/live/PPEHpg2RixQ' },
      { l: 'EDA & Feature Engineering — Krish Naik', u: 'https://youtu.be/xhB-dmKmzRk' }
    ],
    note: 'Roadmap me is month 4 hafte the — tumhare liye 3 hafte kaafi hain. Chautha hafta SQL ko de diya, taaki Month 4 halka pade.'
  },
  {
    m: 4, title: 'SQL + FastAPI (early start)', focus: 'Database + apna API banane ki shuruaat',
    weeks: [
      { w: 'W1', d: 'SQL advanced — subqueries, window functions, CTE' },
      { w: 'W2', d: 'SQL project — ek database pe 10 query likho' },
      { w: 'W3', d: 'FastAPI intro — route, request/response, Pydantic validation' },
      { w: 'W4', d: 'Chhota API banao jo Python function ko expose kare' }
    ],
    project: {
      t: 'SQL queries + pehla FastAPI endpoint',
      steps: ['Chinook/Sample DB pe 10 query likho', 'FastAPI me /convert aur /health endpoint banao', 'Local pe chalao, screenshots README me']
    },
    res: [
      { l: 'SQL — YouTube pe "SQL for data science full course" (CampusX)', u: 'https://www.youtube.com/results?search_query=sql+for+data+science+full+course+campusx' },
      { l: 'FastAPI for ML — CampusX', u: 'https://youtube.com/playlist?list=PLKnIA16_RmvZ41tjbKB2ZnwchfniNsMuQ' }
    ],
    note: 'Power BI / Tableau SKIP — woh data analyst ka kaam hai. FastAPI pehle seekho, kyunki API deploy karna = paisa kamane layak banna.'
  },
  {
    m: 5, title: 'Machine Learning Foundations', focus: 'Algorithm samjho, sirf .fit() nahi',
    weeks: [
      { w: 'W1', d: 'Linear & Logistic Regression, cost function, gradient descent' },
      { w: 'W2', d: 'Classification — KNN, Decision Tree, Naive Bayes' },
      { w: 'W3', d: 'Unsupervised — K-Means, PCA; evaluation metrics' },
      { w: 'W4', d: 'End-to-end ML project' }
    ],
    project: {
      t: 'Churn ya house-price prediction — portfolio piece #2',
      steps: ['Raw data → clean → split → train → evaluate', '2 model compare karo', 'Confusion matrix + metrics likho']
    },
    res: [
      { l: '100 Days of Machine Learning — CampusX', u: 'https://youtube.com/playlist?list=PLKnIA16_Rmvbr7zKYQuBfsVkjoLcJgxHH' }
    ],
    note: 'Math ka perfection mat dhoondo. Intuition kaafi hai — interview me "kyun" poochha jaata hai, derivation nahi.'
  },
  {
    m: 6, title: 'Advanced ML + XGBoost', focus: 'Notebook se production-jaisa code',
    weeks: [
      { w: 'W1', d: 'Feature engineering & feature selection' },
      { w: 'W2', d: 'Ensemble — Random Forest, Gradient Boosting, XGBoost' },
      { w: 'W3', d: 'Hyperparameter tuning, cross-validation, overfitting' },
      { w: 'W4', d: 'Clean repo structure — config, tests, folders' }
    ],
    project: {
      t: 'Month 5 project ka v2 — XGBoost ke saath',
      steps: ['Feature engineering lagao', 'XGBoost train karo', 'Cross-validation se compare karo', 'Clean repo structure me push karo']
    },
    res: [
      { l: '100 Days of ML (aage ke modules) — CampusX', u: 'https://youtube.com/playlist?list=PLKnIA16_Rmvbr7zKYQuBfsVkjoLcJgxHH' },
      { l: 'XGBoost tutorial — YouTube search', u: 'https://www.youtube.com/results?search_query=xgboost+tutorial+for+beginners' }
    ]
  },
  {
    m: 7, title: 'Deep Learning', focus: 'Neural network — LLM samajhne ke liye zaroori',
    weeks: [
      { w: 'W1', d: 'Perceptron, activation functions, forward/backward propagation' },
      { w: 'W2', d: 'CNN — image ke liye' },
      { w: 'W3', d: 'RNN/LSTM — sequence ke liye (basics, gehrai nahi)' },
      { w: 'W4', d: 'CNN project train + evaluate karo' }
    ],
    project: {
      t: 'Image classifier (CNN) — portfolio piece #3',
      steps: ['Cats vs dogs ya digit recognition', 'Colab free GPU use karo', 'Accuracy + loss graph README me']
    },
    res: [
      { l: '100 Days of Deep Learning — CampusX', u: 'https://youtube.com/playlist?list=PLKnIA16_RmvYuZauWaPlRTC54KxSNLtNn' }
    ],
    note: 'Roadmap me 4 hafte — tumhare liye 3 kaafi. RNN sirf samajhne ke liye, project CNN hi rakho.'
  },
  {
    m: 8, title: 'Cloud + Docker + Deploy', focus: 'Model ko internet pe live karna',
    weeks: [
      { w: 'W1', d: 'Cloud basics — compute, storage, IAM (GCP/AWS/Azure me farq)' },
      { w: 'W2', d: 'Ek cloud chuno (GCP free tier recommend) + Docker basics' },
      { w: 'W3', d: 'FastAPI me ML model ko serve karo' },
      { w: 'W4', d: 'Cloud pe deploy karo' }
    ],
    project: {
      t: 'Live API — portfolio piece #4 (public link)',
      steps: ['Model ko FastAPI me wrap karo', 'Dockerfile banao', 'GCP Cloud Run ya Railway pe deploy', 'Live URL README me']
    },
    res: [
      { l: 'GCP Zero to Hero — Abhishek Veeramalla', u: 'https://youtu.be/N5rXROueKhw' },
      { l: 'AWS Zero to Hero — Abhishek Veeramalla', u: 'https://youtu.be/GkKNxyLp_V0' },
      { l: 'Azure Zero to Hero — Abhishek Veeramalla', u: 'https://youtu.be/10jm7Waan8M' },
      { l: 'FastAPI for ML — CampusX', u: 'https://youtube.com/playlist?list=PLKnIA16_RmvZ41tjbKB2ZnwchfniNsMuQ' }
    ],
    note: 'Yeh month sabse important hai — deploy karna aana = freelance me paisa. Railway/Render ka free tier bhi chalega.'
  },
  {
    m: 9, title: 'Generative AI + LLM + LangChain', focus: 'Model banane se model ke upar product banane tak',
    weeks: [
      { w: 'W1', d: 'LLM basics — token, context window, text kaise generate hota hai' },
      { w: 'W2', d: 'Prompt engineering — zero-shot, few-shot, structured output' },
      { w: 'W3', d: 'Embeddings & vector representation' },
      { w: 'W4', d: 'LangChain — chain, memory, tool use' }
    ],
    project: {
      t: 'Document summarizer ya Q&A bot — portfolio piece #5',
      steps: ['LangChain + Groq/Gemini free API', 'Ek PDF summarizer banao', 'Streamlit UI lagao']
    },
    res: [
      { l: 'Generative AI using LangChain — CampusX', u: 'https://youtube.com/playlist?list=PLKnIA16_RmvaTbihpo4MtzVm4XOQa0ER0' }
    ],
    note: 'Yahan se tumhari paisa-earning skill shuru hoti hai. Prompt Lab (Practice tab) roz use karo — theory yahan kaam aayegi.'
  },
  {
    m: 10, title: 'RAG Chatbots', focus: 'Sabse zyada demand wala GenAI pattern',
    weeks: [
      { w: 'W1', d: 'RAG theory — retrieval + generation, chunking strategies' },
      { w: 'W2', d: 'Vector DB — FAISS/Chroma/Pinecone, similarity search' },
      { w: 'W3', d: 'Apne PDFs pe full RAG pipeline' },
      { w: 'W4', d: 'FastAPI backend + Streamlit/Gradio UI' }
    ],
    project: {
      t: 'RAG chatbot — portfolio piece #6 (flagship)',
      steps: ['Apne notes/resume/PDFs pe chatbot', 'Citation ke saath answer', '"I don\'t know" handle karo', 'Deploy karke live link lo']
    },
    res: [
      { l: 'Complete RAG Playlist — Krish Naik', u: 'https://youtube.com/playlist?list=PLZoTAELRMXVM8Pf4U67L4UuDRgV4TNX9D' },
      { l: 'FastAPI for ML (backend ke liye) — CampusX', u: 'https://youtube.com/playlist?list=PLKnIA16_RmvZ41tjbKB2ZnwchfniNsMuQ' }
    ],
    note: 'Yeh project tumhare resume ka sabse strong point hoga. Isko 2 hafte extra do agar zarurat ho — 13 mahine chalega to chalega.'
  },
  {
    m: 11, title: 'Agentic AI + MCP + Claude Code', focus: 'Frontier — agent jo tool use karke kaam kare',
    weeks: [
      { w: 'W1', d: 'Agent concepts — planning, memory, tool calling; LangGraph basics' },
      { w: 'W2', d: 'Multi-step agent workflow banao' },
      { w: 'W3', d: 'MCP (Model Context Protocol) — tools/data se connect' },
      { w: 'W4', d: 'Claude Code — AI coding agent se project fast banao' }
    ],
    project: {
      t: 'Agent workflow — portfolio piece #7 (flagship)',
      steps: ['Research agent ya support-ticket triage agent', 'Kam se kam 1 MCP tool connect karo', 'Error handling + cost limit lagao', 'Claude Code se refactor karo']
    },
    res: [
      { l: 'Agentic AI using LangGraph — CampusX', u: 'https://youtube.com/playlist?list=PLKnIA16_RmvYsvB8qkUQuJmJNuiCUJFPL' },
      { l: 'Model Context Protocol — CampusX', u: 'https://youtube.com/playlist?list=PLKnIA16_Rmva_oZ9F4ayUu9qcWgF7Fyc0' },
      { l: 'Claude Code Full Course 12h — Mayank Aggarwal', u: 'https://youtu.be/05aY2LRIC3s' }
    ]
  },
  {
    m: 12, title: 'Capstone + Portfolio + Job', focus: 'Sab jodo, aur naukri/client ke liye ready ho jao',
    weeks: [
      { w: 'W1', d: '1-2 capstone chuno (ML + GenAI + Cloud + FastAPI)' },
      { w: 'W2', d: 'Saare repos polish — README, docs, tests, structure' },
      { w: 'W3', d: 'Portfolio website + 3-4 LinkedIn posts' },
      { w: 'W4', d: 'Resume, mock interview, applications shuru' }
    ],
    project: {
      t: '3 flagship projects live',
      steps: ['ML model deployment (live API)', 'RAG chatbot (live)', 'Agentic workflow (live)', 'Sab ka link ek portfolio page pe']
    },
    res: [
      { l: 'Interview 150 Questions (tumhari PDF)', u: '' },
      { l: 'AI System Design Playbook (tumhari PDF)', u: '' },
      { l: 'Resume sample (tumhari PDF) — apna banao, copy nahi', u: '' }
    ],
    note: 'Yahan tak 12 mahine, par 13 ya 14 lage to koi problem nahi — yeh deadline nahi, direction hai. Roz 50 min = aage badhna.'
  },
  {
    m: 13, title: 'Buffer Month (agar zarurat pade)', focus: 'Jo reh gaya wo pakka karo — koi naya topic nahi',
    weeks: [
      { w: 'W1', d: 'Jo month adhoora chhoot gaya — wahi dobara' },
      { w: 'W2', d: 'Sabse kamzor 1 topic deep karo' },
      { w: 'W3', d: 'Interview questions practice (150 PDF)' },
      { w: 'W4', d: 'Applications + freelance proposals roz' }
    ],
    project: { t: 'Koi naya project nahi', steps: ['Purane project polish karo', 'Ek project me tests + docs add karo'] },
    res: [],
    note: 'Yeh month optional hai. Agar 12 me ho gaya to seedha job/freelance pe jao.'
  }
];

/* ============================================================
   PLAYGROUND — PROMPT FRAMEWORK (Zara sikhayegi)
   ============================================================ */
const PROMPT_PARTS = [
  { key: 'role',      name: 'Role',       desc: 'AI ko batao wo kaun hai', ex: 'Tum ek senior Python teacher ho.' },
  { key: 'task',      name: 'Task',       desc: 'Ek hi kaam, saaf shabdon me', ex: 'Mujhe yeh code samjhao aur bug batao.' },
  { key: 'context',   name: 'Context',    desc: 'Background — kya, kyun, kis ke liye', ex: 'Main beginner hoon, 11th pass, English kamzor.' },
  { key: 'format',    name: 'Format',     desc: 'Output kaisa chahiye', ex: 'Table me: bug, kyun, fix.' },
  { key: 'constraint',name: 'Constraint', desc: 'Limit aur rules', ex: 'Hinglish me. 150 words max. Sirf 3 bugs.' }
];

const PROMPT_EXAMPLES = [
  {
    bad: 'python code fix karo',
    good: 'Tum ek senior Python developer ho. Neeche diye code me bug dhundo. Main beginner hoon, isliye simple bhasha me samjhao. Output table me do: (1) bug kahan hai, (2) kyun problem hai, (3) fix kaise karna hai. Sirf 3 sabse badi galtiyan batao. Hinglish me likho. Code: [yahan paste]',
    why: 'Role + Task + Context + Format + Constraint — paanchon hai. Isliye answer usable aata hai.'
  },
  {
    bad: 'make my english good',
    good: 'Tum ek English teacher ho jo Hinglish bolne wale students ko padhata hai. Meri neeche 150-word writing check karo. Sirf grammar galtiyan batao — text ko rewrite mat karo. Output: table me "galti | rule | kaise theek karein". Maximum 5 galtiyan. Simple English me samjhao, difficult words mat use karo.',
    why: '"Rewrite mat karo" — yeh constraint hi asli kaam karta hai.'
  }
];

const ENGLISH_TEMPLATES = [
  { g: 'Accuracy', items: [
    'This statement is factually correct.',
    'This statement is incorrect. The correct value is ___ .',
    'I cannot verify this claim, so I will not score it as accurate.',
    'The response contains a hallucination: it states ___ , which is not true.'
  ]},
  { g: 'Completeness', items: [
    'The response is correct but incomplete. It should also mention ___ .',
    'It does not answer the second part of the user\'s question.',
    'No example is given, which makes the answer harder to follow.'
  ]},
  { g: 'Instruction-following', items: [
    'The response ignores the constraint: "___" .',
    'The user asked for JSON, but the response returns a Python dictionary.',
    'The response follows all stated constraints.'
  ]},
  { g: 'Clarity / tone', items: [
    'The explanation is correct but poorly organized. The steps should be in order.',
    'The tone is appropriate for the target audience.'
  ]},
  { g: 'Suggested fix', items: [
    'Suggested fix: add a short example after the definition.',
    'Minimal edit required: change ___ to ___ .',
    'Overall score: 3/5. Reason: correct but incomplete, and one constraint was missed.'
  ]}
];

/* ---------- MCQ BANK (Practice → Tests) ---------- */
const QUIZ_BANK = [
  {
    q: 'Prompt ka kaunsa part missing hai: "Mujhe Python seekhna hai, batao"?',
    o: ['Role', 'Context aur Format dono', 'Kuch missing nahi', 'Sirf title'],
    a: 1,
    e: 'Kaun ho, kis level pe ho (context) aur output kaisa chahiye (format) — dono missing hain. Isliye jawab general aayega.'
  },
  {
    q: 'LLM "hallucination" kya hoti hai?',
    o: ['Model slow chalna', 'Model galat ya bana hua fact confidence se bolna', 'API band ho jana', 'Token khatam hona'],
    a: 1,
    e: 'Hallucination = model aisi baat bol de jo sach nahi hai, par confident lage. RAG isi ko kam karta hai.'
  },
  {
    q: 'RAG me "R" ka matlab?',
    o: ['Random', 'Retrieval', 'React', 'Repeat'],
    a: 1,
    e: 'Retrieval-Augmented Generation — pehle apne data me se relevant hissa dhoondo, phir LLM se jawab banao.'
  },
  {
    q: 'Eval me sabse zaroori cheez kya hai?',
    o: ['Lambe jawab', 'Rubric aur consistent scoring', 'Tez type karna', 'Zyada adjectives'],
    a: 1,
    e: 'Rubric pehle padho, har criterion alag score karo. Consistency hi paisa deti hai.'
  },
  {
    q: 'Good prompt ka sabse bada dushman kya hai?',
    o: ['Constraint dena', 'Ek message me 5 alag kaam maangna', 'Format batana', 'Example dena'],
    a: 1,
    e: 'Ek prompt = ek kaam. Multiple kaam maango to output adhoora aata hai.'
  },
  {
    q: 'Coding assessment me sabse zyada reject kis wajah se hote hain?',
    o: ['Code slow likhna', 'Prompt me diya constraint miss karna', 'Comment likhna', 'Test chalana'],
    a: 1,
    e: '40% reject "missed a stated constraint" se hote hain — jaldi padhne ki wajah se.'
  },
  {
    q: '"Rewrite mat karo, sirf galtiyan batao" — yeh prompt ka kaunsa part hai?',
    o: ['Role', 'Constraint', 'Context', 'Title'],
    a: 1,
    e: 'Constraint = limit/rules. Yahi line output ko control karti hai.'
  },
  {
    q: 'Vector database ka kaam kya hai?',
    o: ['Text ko design karna', 'Similarity search — matlab jaisa matlab waisa dhoondhna', 'Database ko slow karna', 'Model train karna'],
    a: 1,
    e: 'Embedding ke vectors me nearest match dhoondhta hai — RAG ka retrieval step.'
  },
  {
    q: 'Agent aur normal chatbot me farq?',
    o: ['Agent zyada colorful hota hai', 'Agent tool use karke multi-step kaam karta hai', 'Kuch farq nahi', 'Agent sirf English bolta hai'],
    a: 1,
    e: 'Agent plan banata hai, tool call karta hai, result dekhke agla step leta hai.'
  },
  {
    q: 'Eval feedback me "This is good" kyun reject hota hai?',
    o: ['Bahut lamba hai', 'Specific nahi — kya, kahan, kyun missing hai', 'Grammar galat hai', 'English me hai'],
    a: 1,
    e: 'Vague feedback = reject. Sentence quote karo aur exact problem likho.'
  },
  {
    q: 'Zero-shot prompt kya hai?',
    o: ['Bina example diye instruction', 'Zero degree temperature', 'Bina API key', 'Chhota prompt'],
    a: 0,
    e: 'Zero-shot = koi example nahi. Few-shot = 1-3 example diye.'
  },
  {
    q: 'Tumhe LLM se JSON output chahiye. Sabse safe tarika?',
    o: ['"JSON do" likhna', 'Schema example ke saath format specify karna', 'Model ka naam badalna', 'Lambe prompt'],
    a: 1,
    e: 'Expected JSON ka exact shape dikhao + "sirf JSON, koi text nahi" constraint lagao.'
  },
  {
    q: 'Karya jaisa platform kis cheez ka paisa deta hai?',
    o: ['Code likhne ka', 'Native language me AI training data (voice/text)', 'Design ka', 'Marketing ka'],
    a: 1,
    e: 'Hindi/Gujarati voice aur text data — isliye English ki zarurat kam.'
  },
  {
    q: 'Freelance me 50% advance kyun zaroori hai?',
    o: ['Client ko impress karne ke liye', 'Kaam ke baad paisa na milne ka risk kam karne ke liye', 'Tax ke liye', 'Zaroori nahi'],
    a: 1,
    e: 'Bina advance bada kaam = risk. Advance = commitment ka proof.'
  },
  {
    q: '"I don\'t know" handling RAG me kyun zaroori hai?',
    o: ['Model ko aaram chahiye', 'Data me jawab na ho to hallucination rokta hai', 'Speed badhata hai', 'Zaroori nahi'],
    a: 1,
    e: 'Agar retrieval me jawab nahi mila to LLM ko "nahi pata" bolna chahiye — warna bana dega.'
  }
];
```

#### `js/store.js`

```js
/* ============================================================
   store.js — data layer
   Sab kuch localStorage me. Koi backend nahi, koi external call nahi.
   ============================================================ */

const STORE_KEY = 'ekraasta_v2';

/* localStorage band ho (iframe/private mode) to memory fallback */
const store = (function () {
  try {
    localStorage.setItem('__t', '1');
    localStorage.removeItem('__t');
    return localStorage;
  } catch (e) {
    const mem = {};
    return {
      getItem: (k) => (k in mem ? mem[k] : null),
      setItem: (k, v) => { mem[k] = String(v); },
      removeItem: (k) => { delete mem[k]; }
    };
  }
})();

/* ---------------- date helpers ---------------- */
const pad2 = (n) => String(n).padStart(2, '0');

function todayISO() {
  const d = new Date();
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}
function isoOf(d) { return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`; }
function parseISO(iso) {
  const p = String(iso || '').split('-').map(Number);
  return new Date(p[0], (p[1] || 1) - 1, p[2] || 1);
}
function addDays(iso, n) {
  const d = parseISO(iso); d.setDate(d.getDate() + n); return isoOf(d);
}
function daysBetween(a, b) { return Math.round((parseISO(b) - parseISO(a)) / 86400000); }
function weekStartISO(iso) {
  const d = parseISO(iso);
  const shift = (d.getDay() + 6) % 7;
  d.setDate(d.getDate() - shift);
  return isoOf(d);
}
const MONTH_SHORT = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
function fmtDate(iso) {
  if (!iso) return '';
  const d = parseISO(iso);
  return `${d.getDate()} ${MONTH_SHORT[d.getMonth()]}`;
}
function fmtDateFull(iso) {
  if (!iso) return '';
  const d = parseISO(iso);
  return `${d.getDate()} ${MONTH_SHORT[d.getMonth()]} ${d.getFullYear()}`;
}
function uid() { return Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-3); }

/* ---------------- seed ---------------- */
function seedState() {
  const today = todayISO();
  return {
    v: 2,
    profile: {
      name: 'Aadil',
      startDate: today,          // 90-din ka Day 1
      learnStart: today,         // learning track ka start
      theme: 'dark',
      uiV: 6,
      hoursPerDay: 3.5,
      usdRate: 88,
      apiKey: '',
      apiBase: 'https://api.groq.com/openai/v1',
      apiModel: 'llama-3.1-8b-instant',
      voice: true,
      voiceName: '',
      voiceRate: 0.98,
      voicePitch: 1.08,
      ttsProvider: 'device',
      ttsKey: '',
      ttsVoice: '',
      supabaseUrl: '',
      supabaseKey: ''
    },
    daily: {},                   // date -> { blocks:{}, log }
    t90: { done: {} },           // taskKey -> iso date
    learn: { done: {}, open: 1 },// key: m1-w1, m1-proj
    projects: [
      { id: uid(), name: 'Number Guessing Game', status: 'done', tags: ['loops','random','try/except'], link: 'https://github.com/your-github-username/build-01-number-guessing-game' },
      { id: uid(), name: 'Unit Converter', status: 'done', tags: ['functions','validation'], link: 'https://github.com/your-github-username/build-02-unit-converter' },
      { id: uid(), name: 'Expense Tracker (file save)', status: 'todo', tags: ['file I/O','json'], link: '' },
      { id: uid(), name: 'CSV / Excel Cleaner', status: 'todo', tags: ['pandas'], link: '' },
      { id: uid(), name: 'Dataset Analysis Notebook', status: 'todo', tags: ['pandas','eda'], link: '' },
      { id: uid(), name: 'Churn / Price Prediction', status: 'todo', tags: ['sklearn'], link: '' },
      { id: uid(), name: 'Live FastAPI Deployment', status: 'todo', tags: ['fastapi','cloud'], link: '' },
      { id: uid(), name: 'RAG Chatbot (flagship)', status: 'todo', tags: ['rag','vector db'], link: '' },
      { id: uid(), name: 'Agent Workflow (flagship)', status: 'todo', tags: ['langgraph','mcp'], link: '' }
    ],
    evals: [],
    prompts: [],
    tests: [],
    earnings: [],
    platforms: [
      { id: uid(), name: 'Karya', status: 'start', rate: '$5/hr', next: 'App install + profile 100%', due: today, notes: 'Pehla paisa. UPI me aata hai.' },
      { id: uid(), name: 'Outlier (Hindi multilingual)', status: 'later', rate: '$15-24/hr', next: '2-3 hafte baad apply', due: addDays(today, 21), notes: 'Generalist nahi — multilingual track.' },
      { id: uid(), name: 'Stellar AI', status: 'later', rate: '$18-25/hr', next: 'Outlier ke baad', due: addDays(today, 30), notes: '' },
      { id: uid(), name: 'Mindrift', status: 'later', rate: 'varies', next: 'Backup', due: addDays(today, 30), notes: '' },
      { id: uid(), name: 'Mercor', status: 'later', rate: '$20-75/hr', next: '2 mahine baad (video interview)', due: addDays(today, 60), notes: 'Bolne ki English chahiye.' },
      { id: uid(), name: 'DataAnnotation', status: 'later', rate: '$22-32/hr', next: '2 mahine baad — SIRF 1 attempt', due: addDays(today, 60), notes: 'Starter assessment retake nahi.' },
      { id: uid(), name: 'Alignerr', status: 'later', rate: 'varies', next: 'Low priority', due: '', notes: 'Join aasan, kaam mushkil.' }
    ],
    ideas: [],
    weekly: [],
    chat: [],
    updatedAt: 0
  };
}

/* ---------------- state load/save ---------------- */
let state = loadState();

function loadState() {
  const base = seedState();
  try {
    const raw = store.getItem(STORE_KEY);
    if (!raw) return base;
    const p = JSON.parse(raw);
    const merged = Object.assign(base, p);
    merged.profile = Object.assign(base.profile, p.profile || {});
    merged.t90 = Object.assign(base.t90, p.t90 || {});
    merged.learn = Object.assign(base.learn, p.learn || {});
    if (!Array.isArray(merged.projects) || !merged.projects.length) merged.projects = base.projects;
    if (!merged.profile.name) merged.profile.name = 'Aadil';
    /* v4: naya dark palette — purane users ko bhi ek baar dark pe le aao */
    if (merged.profile.uiV !== 6) {
      merged.profile.uiV = 6;
      merged.profile.theme = 'dark';
    }
    return merged;
  } catch (e) {
    return base;
  }
}

let saveTimer = null;
function save() {
  state.updatedAt = Date.now();
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try { store.setItem(STORE_KEY, JSON.stringify(state)); } catch (e) {}
  }, 60);
  /* cloud sync — agar login hai to 3 sec baad apne aap push */
  try {
    if (typeof Cloud !== 'undefined' && Cloud.auto()) Cloud.pushSoon();
  } catch (e) {}
}
function saveNow() {
  clearTimeout(saveTimer);
  try { store.setItem(STORE_KEY, JSON.stringify(state)); } catch (e) {}
}

/* ---------------- derived data ---------------- */
function day90() {
  const diff = daysBetween(state.profile.startDate, todayISO());
  return Math.min(Math.max(diff + 1, 1), 999);
}
function learnDay() {
  return Math.max(1, daysBetween(state.profile.learnStart, todayISO()) + 1);
}
function todayRec() {
  const t = todayISO();
  if (!state.daily[t]) state.daily[t] = { blocks: {}, log: '' };
  if (!state.daily[t].blocks) state.daily[t].blocks = {};
  return state.daily[t];
}
function blocksDone(rec) {
  if (!rec || !rec.blocks) return 0;
  return DAILY_BLOCKS.filter((b) => rec.blocks[b.id]).length;
}
function minsDone(rec) {
  if (!rec || !rec.blocks) return 0;
  return DAILY_BLOCKS.reduce((s, b) => s + (rec.blocks[b.id] ? b.mins : 0), 0);
}
function streak() {
  let n = 0;
  let cursor = todayISO();
  if (blocksDone(state.daily[cursor]) < 4) cursor = addDays(cursor, -1);
  for (let i = 0; i < 500; i++) {
    if (blocksDone(state.daily[cursor]) >= 4) { n++; cursor = addDays(cursor, -1); }
    else break;
  }
  return n;
}
function weekHours(ws) {
  let total = 0;
  for (let i = 0; i < 7; i++) total += minsDone(state.daily[addDays(ws, i)]) / 60;
  return Math.round(total * 10) / 10;
}
function toINR(amount, cur) {
  const n = Number(amount) || 0;
  return cur === 'USD' ? Math.round(n * (Number(state.profile.usdRate) || 88)) : n;
}
function inr(n) { return '₹' + (Math.round(Number(n) || 0)).toLocaleString('en-IN'); }

/* 90-din progress */
function t90Stats() {
  let total = 0, done = 0;
  PLAN_90.forEach((ph) => ph.tasks.forEach((t, i) => { total++; if (state.t90.done[ph.id + '-' + i]) done++; }));
  return { total, done, pct: total ? Math.round((done / total) * 100) : 0 };
}
function phaseStats(ph) {
  let done = 0;
  ph.tasks.forEach((t, i) => { if (state.t90.done[ph.id + '-' + i]) done++; });
  return { done, total: ph.tasks.length };
}
/* learning progress */
function learnStats() {
  let total = 0, done = 0;
  LEARN_MONTHS.forEach((mo) => {
    mo.weeks.forEach((w) => { total++; if (state.learn.done['m' + mo.m + '-' + w.w]) done++; });
    total++; if (state.learn.done['m' + mo.m + '-proj']) done++;
  });
  return { total, done, pct: total ? Math.round((done / total) * 100) : 0 };
}
function monthStats(mo) {
  let total = 0, done = 0;
  mo.weeks.forEach((w) => { total++; if (state.learn.done['m' + mo.m + '-' + w.w]) done++; });
  total++; if (state.learn.done['m' + mo.m + '-proj']) done++;
  return { done, total };
}
function currentMonth() {
  const mo = LEARN_MONTHS.filter((x) => monthStats(x).done < monthStats(x).total);
  return mo.length ? mo[0] : LEARN_MONTHS[LEARN_MONTHS.length - 1];
}
function shippedCount() { return state.projects.filter((p) => p.status === 'done').length; }
function monthEarn() {
  const mk = todayISO().slice(0, 7);
  return state.earnings.filter((e) => String(e.date).slice(0, 7) === mk).reduce((s, e) => s + toINR(e.amount, e.cur), 0);
}
function totalEarn() { return state.earnings.reduce((s, e) => s + toINR(e.amount, e.cur), 0); }

/* weekly scorecard row */
function weekRow(ws) {
  const found = state.weekly.find((w) => w.week === ws);
  let evals = 0;
  state.evals.forEach((e) => { if (weekStartISO(e.date) === ws) evals++; });
  let rupees = 0;
  state.earnings.forEach((e) => { if (weekStartISO(e.date) === ws) rupees += toINR(e.amount, e.cur); });
  return {
    week: ws,
    hours: weekHours(ws),
    evals,
    rupees,
    repos: found ? found.repos || 0 : 0,
    outreach: found ? found.outreach || 0 : 0,
    replies: found ? found.replies || 0 : 0
  };
}
```

#### `js/ui.js`

```js
/* ============================================================
   ui.js — icons, chhote UI helpers, theme, toast, modal
   ============================================================ */

const ICONS = {
  home: '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 10h18"/>',
  book: '<path d="M4 5a2 2 0 0 1 2-2h12v18H6a2 2 0 0 1-2-2z"/><path d="M8 7h6M8 11h6"/>',
  spark: '<path d="M12 3l1.8 4.7L18.5 9.5 13.8 11.3 12 16l-1.8-4.7L5.5 9.5l4.7-1.8z"/><path d="M18 16l.9 2.3L21 19l-2.1.7L18 22l-.9-2.3L15 19l2.1-.7z"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  chev: '<path d="m6 9 6 6 6-6"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  trash: '<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
  mic: '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v4"/>',
  send: '<path d="M22 2 11 13"/><path d="M22 2l-7 20-4-9-9-4z"/>',
  wallet: '<rect x="3" y="6" width="18" height="13" rx="3"/><path d="M3 10h18M16 14h2"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-2.9 1.2 2 2 0 1 1-4 0 1.7 1.7 0 0 0-2.9-1.2l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.7 1.7 0 0 0 4.6 15a2 2 0 1 1 0-4 1.7 1.7 0 0 0 1.2-2.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.7 1.7 0 0 0 11.5 4a2 2 0 1 1 4 0 1.7 1.7 0 0 0 2.9 1.2l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1A1.7 1.7 0 0 0 19.4 11a2 2 0 1 1 0 4z"/>',
  bulb: '<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-4 10.5V16h8v-2.5A6 6 0 0 0 12 3z"/>',
  link: '<path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/>',
  play: '<path d="M6 4l14 8-14 8z"/>',
  close: '<path d="M18 6 6 18M6 6l12 12"/>',
  zara: '<path d="M12 3a9 9 0 0 1 9 9 9 9 0 0 1-9 9 8.9 8.9 0 0 1-4-1L3 21l1.1-4.2A9 9 0 0 1 12 3z"/><path d="M9 10h6l-6 4h6"/>',
  arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 8h.01M11 12h1v4h1"/>',
  flame: '<path d="M12 3c3 4 6 6 6 10a6 6 0 0 1-12 0c0-2 1-3.5 2-5 .5 1.5 1.5 2 2 2 0-3 1-5 2-7z"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  code: '<path d="m8 6-6 6 6 6M16 6l6 6-6 6"/>',
  cloud: '<path d="M17 18a4 4 0 0 0 0-8 6 6 0 0 0-11.6 1.6A3.5 3.5 0 0 0 6 18z"/>',
  bot: '<rect x="4" y="7" width="16" height="12" rx="3"/><path d="M12 3v4M9 13h.01M15 13h.01M9 17h6"/>',
  layers: '<path d="m12 3 9 5-9 5-9-5 9-5z"/><path d="m3 13 9 5 9-5"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7z"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  edit: '<path d="M4 20h4l10-10-4-4L4 16z"/><path d="M14 6l4 4"/>',
  target2: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/>'
};

function icon(name, cls) {
  const p = ICONS[name] || '';
  return `<svg class="${cls || ''}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
}

/* icons ko <span data-ico="name"> me bhar do (tabbar, sheet buttons) */
function hydrateIcons(root) {
  (root || document).querySelectorAll('[data-ico]').forEach((el) => {
    const n = el.getAttribute('data-ico');
    if (n && !el.firstChild) el.innerHTML = icon(n);
  });
}

function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

let toastTimer = null;
function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add('hidden'), 2000);
}

/* ---------------- theme ---------------- */
function applyTheme() {
  const t = state.profile.theme === 'dark' ? 'dark' : 'light';
  document.documentElement.setAttribute('data-theme', t);
  const btn = document.getElementById('btnTheme');
  if (btn) btn.innerHTML = icon(t === 'dark' ? 'sun' : 'moon');
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', t === 'dark' ? '#08090c' : '#6d4aff');
}
function toggleTheme() {
  state.profile.theme = state.profile.theme === 'dark' ? 'light' : 'dark';
  applyTheme(); save();
  toast(state.profile.theme === 'dark' ? 'Dark theme on' : 'Light theme on');
}

/* ---------------- modal ---------------- */
function openModal(html) {
  document.getElementById('modalBox').innerHTML = html;
  document.getElementById('modal').classList.remove('hidden');
}
function closeModal() {
  document.getElementById('modal').classList.add('hidden');
  document.getElementById('modalBox').innerHTML = '';
}

/* ---------------- misc ---------------- */
function ringPct(pct, size, stroke) {
  const r = (size / 2) - (stroke / 2) - 2;
  const c = 2 * Math.PI * r;
  const off = c - (Math.min(100, Math.max(0, pct)) / 100) * c;
  return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
    <circle class="bg" cx="${size/2}" cy="${size/2}" r="${r}" fill="none" stroke-width="${stroke}"/>
    <circle class="fg" cx="${size/2}" cy="${size/2}" r="${r}" fill="none" stroke-width="${stroke}"
      stroke-dasharray="${c.toFixed(1)}" stroke-dashoffset="${off.toFixed(1)}"/>
  </svg>`;
}

function progressBar(pct, cls) {
  return `<div class="bar ${cls || ''}"><i style="width:${Math.min(100, pct)}%"></i></div>`;
}

function emptyBox(iconName, text) {
  return `<div class="empty">${icon(iconName || 'info')}<div>${text}</div></div>`;
}

const PLATFORM_STATUS = {
  start: 'Shuru karo',
  later: 'Abhi nahi',
  applied: 'Applied',
  assessed: 'Assessment diya',
  passed: 'Pass',
  tasks: 'Tasks mil rahe',
  paid: 'Paisa aaya'
};
```

#### `js/cloud.js`

```js
/* ============================================================
   cloud.js — Supabase login + multi-device sync
   SDK nahi — seedha REST API (fetch). Isliye kuch install nahi karna.

   Kaam:
   - signup / login / logout (email + password)
   - push: local state -> Supabase (user_state table)
   - pull: Supabase -> local state (agar remote naya ho)
   - auto: save hone pe 3 sec baad apne aap push

   Security: har user ka data alag (Row Level Security SQL README me hai).
   API key (Groq) aur Supabase key cloud pe kabhi nahi jaate.
   ============================================================ */

/* Supabase me ek baar chalane wala SQL — app ke andar se copy kar sakte ho */
const CLOUD_SQL = `-- ekRaasta cloud sync: Supabase > SQL Editor me paste karke RUN
create table if not exists public.user_state (
  user_id uuid primary key references auth.users on delete cascade,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.user_state enable row level security;

drop policy if exists "own rows read"   on public.user_state;
drop policy if exists "own rows insert" on public.user_state;
drop policy if exists "own rows update" on public.user_state;

create policy "own rows read"   on public.user_state for select using (auth.uid() = user_id);
create policy "own rows insert" on public.user_state for insert with check (auth.uid() = user_id);
create policy "own rows update" on public.user_state for update using (auth.uid() = user_id) with check (auth.uid() = user_id);`;

const Cloud = (function () {
  const SS = 'ekraasta_cloud_session';
  let pushTimer = null;
  let busy = false;
  let lastStatus = '';   // '', 'syncing', 'synced', 'error'
  let lastAt = 0;
  let lastErr = '';

  function cfg() {
    return {
      url: String(state.profile.supabaseUrl || '').replace(/\/+$/, ''),
      key: String(state.profile.supabaseKey || '').trim()
    };
  }
  function ready() {
    const c = cfg();
    return !!(c.url && c.key);
  }
  function session() {
    try { return JSON.parse(store.getItem(SS) || 'null'); } catch (e) { return null; }
  }
  function setSession(s) {
    try {
      if (s) store.setItem(SS, JSON.stringify(s));
      else store.removeItem(SS);
    } catch (e) {}
  }
  function signedIn() {
    const s = session();
    return !!(s && s.access && s.refresh);
  }
  function userEmail() {
    const s = session();
    return s && s.email ? s.email : '';
  }
  function status() {
    return { ready: ready(), signedIn: signedIn(), email: userEmail(), state: lastStatus, at: lastAt, err: lastErr };
  }
  function auto() { return ready() && signedIn(); }

  function jwtSub(token) {
    try {
      const part = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
      const json = decodeURIComponent(escape(window.atob(part)));
      const obj = JSON.parse(json);
      return obj.sub || (obj.user_id || null);
    } catch (e) { return null; }
  }

  function headers(extra) {
    const c = cfg();
    const s = session();
    const h = Object.assign({
      'apikey': c.key,
      'Content-Type': 'application/json'
    }, extra || {});
    if (s && s.access) h['Authorization'] = 'Bearer ' + s.access;
    return h;
  }

  async function authFetch(path, body) {
    const c = cfg();
    const res = await fetch(c.url + path, { method: 'POST', headers: headers(), body: JSON.stringify(body) });
    const text = await res.text();
    let data = {};
    try { data = text ? JSON.parse(text) : {}; } catch (e) { data = { raw: text }; }
    if (!res.ok) {
      const msg = data.error_description || data.msg || data.message || data.error || ('HTTP ' + res.status);
      throw new Error(msg);
    }
    return data;
  }

  function remember(data, email) {
    const now = Date.now();
    const s = {
      access: data.access_token,
      refresh: data.refresh_token,
      expires: now + ((data.expires_in || 3600) * 1000),
      email: email || (data.user && data.user.email) || ''
    };
    setSession(s);
    return s;
  }

  async function signup(email, password) {
    if (!ready()) throw new Error('Pehle Supabase URL aur key save karo');
    const data = await authFetch('/auth/v1/signup', { email, password });
    if (data.access_token) { remember(data, email); return { ok: true, needsConfirm: false }; }
    return { ok: true, needsConfirm: true };
  }

  async function login(email, password) {
    if (!ready()) throw new Error('Pehle Supabase URL aur key save karo');
    const data = await authFetch('/auth/v1/token?grant_type=password', { email, password });
    remember(data, email);
    return { ok: true };
  }

  async function refreshSession() {
    const s = session();
    if (!s || !s.refresh) return false;
    const c = cfg();
    try {
      const res = await fetch(c.url + '/auth/v1/token?grant_type=refresh_token', {
        method: 'POST',
        headers: { 'apikey': c.key, 'Content-Type': 'application/json' },
        body: JSON.stringify({ refresh_token: s.refresh })
      });
      if (!res.ok) return false;
      const data = await res.json();
      remember(data, s.email);
      return true;
    } catch (e) { return false; }
  }

  async function ensureToken() {
    const s = session();
    if (!s) return false;
    if (Date.now() < (s.expires - 60000)) return true;
    return await refreshSession();
  }

  function logout() {
    setSession(null);
    lastStatus = '';
  }

  /* -------- push -------- */
  async function push(silent) {
    if (!auto()) return false;
    if (busy) return false;
    busy = true; lastStatus = 'syncing';
    try {
      if (!(await ensureToken())) throw new Error('Session expire — dobara login karo');
      const s = session();
      const uid = jwtSub(s.access);
      if (!uid) throw new Error('User id nahi mila — dobara login karo');

      /* sensitive local-only fields hata ke bhejo */
      const payload = JSON.parse(JSON.stringify(state));
      delete payload.profile.apiKey;
      delete payload.profile.supabaseKey;
      delete payload.profile.supabaseUrl;
      delete payload.profile.supabaseAnon;
      payload.updatedAt = Date.now();

      const c = cfg();
      const res = await fetch(c.url + '/rest/v1/user_state', {
        method: 'POST',
        headers: headers({
          'Prefer': 'resolution=merge-duplicates,return=minimal'
        }),
        body: JSON.stringify({
          user_id: uid,
          data: payload,
          updated_at: new Date().toISOString()
        })
      });
      if (!res.ok) {
        const t = await res.text();
        throw new Error(t.slice(0, 160) || ('HTTP ' + res.status));
      }
      lastStatus = 'synced'; lastAt = Date.now(); lastErr = '';
      if (!silent && typeof toast === 'function') toast('Cloud pe save ho gaya');
      return true;
    } catch (e) {
      lastStatus = 'error'; lastErr = e.message || 'push fail';
      if (!silent && typeof toast === 'function') toast('Sync fail: ' + lastErr);
      return false;
    } finally {
      busy = false;
    }
  }

  function pushSoon() {
    if (!auto()) return;
    clearTimeout(pushTimer);
    pushTimer = setTimeout(() => push(true), 3000);
  }

  /* -------- pull -------- */
  async function pull(silent) {
    if (!auto()) return { ok: false, reason: 'signed-out' };
    lastStatus = 'syncing';
    try {
      if (!(await ensureToken())) throw new Error('Session expire — dobara login karo');
      const s = session();
      const uid = jwtSub(s.access);
      const c = cfg();
      const res = await fetch(c.url + '/rest/v1/user_state?user_id=eq.' + uid + '&select=data,updated_at', {
        headers: headers()
      });
      if (!res.ok) {
        const t = await res.text();
        throw new Error(t.slice(0, 160) || ('HTTP ' + res.status));
      }
      const rows = await res.json();
      if (!rows.length) {
        /* cloud khaali — pehla device: local data chadha do */
        lastStatus = 'synced'; lastAt = Date.now();
        await push(true);
        return { ok: true, applied: false, reason: 'cloud-empty' };
      }

      const row = rows[0];
      const remote = row.data || {};
      const remoteAt = new Date(row.updated_at).getTime() || 0;
      const localAt = Number(state.updatedAt) || 0;

      if (remoteAt > localAt + 1500) {
        applyRemote(remote);
        lastStatus = 'synced'; lastAt = Date.now(); lastErr = '';
        if (!silent && typeof toast === 'function') toast('Cloud se latest data aa gaya');
        return { ok: true, applied: true };
      }

      lastStatus = 'synced'; lastAt = Date.now();
      await push(true);
      return { ok: true, applied: false };
    } catch (e) {
      lastStatus = 'error'; lastErr = e.message || 'pull fail';
      if (!silent && typeof toast === 'function') toast('Pull fail: ' + lastErr);
      return { ok: false, error: lastErr };
    }
  }


  /* ---- connection test (URL + key sahi hai ya nahi) ---- */
  async function test() {
    const c = cfg();
    if (!c.url || !c.key) return { ok: false, msg: 'URL ya key khaali hai' };
    if (!/^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(c.url)) {
      return { ok: false, msg: 'URL aisa hona chahiye: https://xxxxx.supabase.co' };
    }
    try {
      const res = await fetch(c.url + '/rest/v1/user_state?select=user_id&limit=1', {
        headers: { apikey: c.key, Authorization: 'Bearer ' + c.key }
      });
      if (res.status === 404) {
        return { ok: false, code: 404, msg: 'Project mil gaya, par table "user_state" nahi hai — SQL chalao' };
      }
      if (res.status === 401 || res.status === 403) {
        return { ok: false, code: res.status, msg: 'Key galat hai — Settings → API se "anon public" key copy karo' };
      }
      if (!res.ok) {
        const t = await res.text();
        return { ok: false, code: res.status, msg: (t || 'HTTP ' + res.status).slice(0, 160) };
      }
      return { ok: true, msg: 'Connected — table bhi mil gaya' };
    } catch (e) {
      return { ok: false, msg: 'Internet/URL problem: ' + (e.message || 'fetch fail') };
    }
  }

  function applyRemote(remote) {
    const localSecrets = {
      apiKey: state.profile.apiKey,
      supabaseUrl: state.profile.supabaseUrl,
      supabaseKey: state.profile.supabaseKey
    };
    const base = seedState();
    const merged = Object.assign(base, remote);
    merged.profile = Object.assign(base.profile, remote.profile || {});
    merged.profile.apiKey = localSecrets.apiKey || '';
    merged.profile.supabaseUrl = localSecrets.supabaseUrl || '';
    merged.profile.supabaseKey = localSecrets.supabaseKey || '';
    merged.profile.theme = state.profile.theme;
    state = merged;
    saveNow();
    if (typeof applyTheme === 'function') applyTheme();
    if (typeof render === 'function') render();
  }

  return {
    ready, signedIn, userEmail, status, auto,
    signup, login, logout, push, pull, pushSoon, applyRemote, test, SQL: CLOUD_SQL
  };
})();
```

#### `js/zara.js`

```js
/* ============================================================
   zara.js — Zara ka "dimag"
   1. Prompt checker (rule-based, offline)
   2. English eval checker (rule-based, offline)
   3. Chat replies (offline knowledge)
   4. Optional real LLM (agar user apni free API key daale)
   5. Voice: bolna + sunna (browser speech)
   ============================================================ */

const Zara = (function () {

  /* ---------------- 1. PROMPT CHECKER ---------------- */
  function promptFeedback(raw) {
    const text = String(raw || '').trim();
    const items = [];
    let score = 20;

    if (text.length < 30) {
      return {
        score: 0,
        items: [{ type: 'bad', text: 'Yeh prompt bahut chhota hai. Kam se kam 2-3 line likho — role, kaam, aur output format.' }],
        next: '"python fix karo" nahi — "Tum senior Python dev ho. Is code me bug dhundo. Output table me: bug, kyun, fix. Sirf 3 bugs." aisa likho.'
      };
    }

    const has = (re) => re.test(text);

    const role = has(/(you are|act as|tum ek|aap ek|tum ho|senior|expert|teacher|developer ho|as a)/i);
    const task = has(/(write|likho|banao|banado|explain|samjhao|fix|theek|find|dhundo|summar|convert|generate|list|batao|check|review|improve)/i);
    const context = has(/(i am|main |mera|mere|beginner|context|background|kis liye|for my|because|kyunki|student)/i);
    const format = has(/(json|table|bullet|list|markdown|csv|words|format|step by step|numbered|paragraph|heading)/i);
    const constraint = has(/(only|sirf|max|maximum|minimum|do not|mat |no more|limit|at least|exactly|nahi chahiye|short)/i);
    const example = has(/(example|jaise|for instance|e\.g\.|sample)/i);
    const vague = has(/\b(good|nice|better|best|accha|achha|thik|theek)\b/i);

    if (role) { score += 15; items.push({ type: 'good', text: 'Role diya — AI ko pata hai wo kis nazar se jawab de.' }); }
    else { items.push({ type: 'bad', text: 'Role missing. Pehli line me likho: "Tum ek senior Python developer ho."' }); }

    if (task) { score += 15; items.push({ type: 'good', text: 'Kaam saaf hai — kya karna hai wo pata chalta hai.' }); }
    else { items.push({ type: 'bad', text: 'Kaam (task) clear nahi. Ek verb se shuru karo: "samjhao", "dhundo", "banao".' }); }

    if (context) { score += 15; items.push({ type: 'good', text: 'Context diya — level/background batane se jawab tumhare layak aata hai.' }); }
    else { items.push({ type: 'meh', text: 'Context add karo: "Main beginner hoon, 11th pass, English kamzor hai." Isse jawab simple aayega.' }); }

    if (format) { score += 15; items.push({ type: 'good', text: 'Output format bataya — jawab usable form me aayega.' }); }
    else { items.push({ type: 'bad', text: 'Format missing. Likhо: "Output table me do" ya "5 bullet points me".' }); }

    if (constraint) { score += 15; items.push({ type: 'good', text: 'Constraint diya — AI limit me rahega.' }); }
    else { items.push({ type: 'meh', text: 'Constraint add karo: "SIRF 3 bug batao", "150 words max", "rewrite mat karo".' }); }

    if (example) { score += 5; items.push({ type: 'good', text: 'Example diya — yeh best practice hai (few-shot).' }); }

    if (vague) { score -= 8; items.push({ type: 'bad', text: '"good / best / accha" jaise vague words hatao — unki jagah exactly likho kya chahiye.' }); }

    const qCount = (text.match(/\?/g) || []).length;
    if (qCount > 2) { score -= 8; items.push({ type: 'meh', text: 'Ek prompt me 3 se zyada sawaal hain. Ek prompt = ek kaam. Baaki agle message me poocho.' }); }

    if (text.length < 120) { score -= 5; items.push({ type: 'meh', text: 'Thoda detail aur add karo — 3-6 line ka prompt best chalta hai.' }); }

    score = Math.max(0, Math.min(100, score));

    const next = score >= 80
      ? 'Bahut badhiya. Ab isi prompt se jawab lo, aur jawab ache na aaye to ek line aur add karo — "pehle 1 line summary, phir detail".'
      : 'Sabse bada gap: ' + (items.find((i) => i.type === 'bad') || {}).text;

    return { score, items, next };
  }

  /* ---------------- 2. ENGLISH EVAL CHECKER ---------------- */
  function englishFeedback(raw) {
    const text = String(raw || '').trim();
    const items = [];
    let score = 0;

    if (!text) {
      return { score: 0, words: 0, items: [{ type: 'bad', text: 'Kuch likho — kam se kam 100 words.' }], next: 'Practice → English me 150 words likho.' };
    }

    const words = text.split(/\s+/).filter(Boolean).length;
    const sentences = text.split(/[.!?]+/).filter((s) => s.trim().length > 2);

    /* length */
    if (words >= 120) { score += 25; items.push({ type: 'good', text: `Length theek hai (${words} words). Eval me 120+ words kaafi hote hain.` }); }
    else if (words >= 60) { score += 14; items.push({ type: 'meh', text: `${words} words — thoda kam. 120-150 words tak le jao.` }); }
    else { items.push({ type: 'bad', text: `Sirf ${words} words. Eval feedback me kam se kam 120 words chahiye.` }); }

    /* templates usage */
    const tplHits = [
      /correct but incomplete/i,
      /should also mention/i,
      /factually (correct|incorrect)/i,
      /ignores? the constraint/i,
      /suggested fix/i,
      /overall score/i,
      /hallucinat/i,
      /follows all stated constraints/i
    ].filter((re) => re.test(text)).length;
    if (tplHits >= 2) { score += 25; items.push({ type: 'good', text: 'Template patterns use kiye — yahi assessment me kaam aata hai.' }); }
    else if (tplHits === 1) { score += 12; items.push({ type: 'meh', text: 'Ek template use hua. Practice tab ke 15 templates me se 2-3 patterns roz use karo.' }); }
    else { items.push({ type: 'bad', text: 'Koi fixed eval pattern nahi mila. "This response is correct but incomplete. It should also mention ..." jaise sentences use karo.' }); }

    /* sentence start capital */
    const lowerStarts = sentences.filter((s) => /^[a-z]/.test(s.trim()));
    if (lowerStarts.length === 0) { score += 15; items.push({ type: 'good', text: 'Har sentence capital letter se shuru hoti hai.' }); }
    else { items.push({ type: 'bad', text: `${lowerStarts.length} sentence small letter se shuru ho rahi hain. Capital se shuru karo.` }); }

    /* i instead of I */
    if (/\bi\b/.test(text.replace(/\bi'm\b/gi, ''))) items.push({ type: 'bad', text: 'English me "I" hamesha capital hota hai ("i think" → "I think").' });
    else score += 10;

    /* a/an */
    const aVowel = text.match(/\ba\s+[aeiouAEIOU]/g);
    const anCons = text.match(/\ban\s+[^aeiouAEIOU\s]/g);
    if (aVowel || anCons) {
      items.push({ type: 'bad', text: `Article galti: ${(aVowel || []).concat(anCons || []).slice(0, 3).join(', ')} — vowel se pehle "an", consonant se pehle "a".` });
    } else score += 8;

    /* punctuation */
    if (/[.!?]$/.test(text)) score += 7;
    else items.push({ type: 'meh', text: 'Aakhir me full stop lagao.' });

    /* Hindi words */
    const hindi = text.match(/\b(hai|nahi|karo|bohot|bahut|mera|tum|aap|kar|raha|rahe)\b/gi);
    if (hindi && hindi.length) {
      score -= 10;
      items.push({ type: 'bad', text: `Eval text me Hindi words mile (${hindi.slice(0, 3).join(', ')}). Assessment me sirf English likhna hota hai — Hindi me socho, English me likho.` });
    }

    /* filler */
    const filler = text.match(/\b(very|really|thing|things|stuff|etc)\b/gi);
    if (filler && filler.length > 2) {
      score -= 5;
      items.push({ type: 'meh', text: '"very / really / thing" jaise filler words kam karo — specific words likho.' });
    }

    /* specific quoting (best practice) */
    if (/["']/.test(text) || /says|states|mentions/i.test(text)) {
      score += 8;
      items.push({ type: 'good', text: 'Response ki baat quote/reference ki — specific feedback strong hota hai.' });
    } else {
      items.push({ type: 'meh', text: 'Response ka exact sentence quote karo — "it states ___". Isse feedback strong lagta hai.' });
    }

    score = Math.max(0, Math.min(100, Math.round((score / 108) * 100)));

    const next = score >= 75
      ? 'Achha hai. Ab isi ko GitHub pe `evals/` folder me daalo — portfolio bhi ban raha hai.'
      : 'Do cheezein sudharo: (1) template patterns use karo, (2) 120+ words likho. Baaki apne aap theek hoga.';

    return { score, words, items, next };
  }

  /* ---------------- 3. CHAT (offline knowledge) ---------------- */
  function todaySummary() {
    const rec = todayRec();
    const left = DAILY_BLOCKS.filter((b) => !rec.blocks[b.id]);
    if (!left.length) return 'Aaj ke saare 5 block ho gaye. Shabaash! Ab kal ka plan dekh lo — ya 30 min buffer me project pe kaam karo.';
    return 'Aaj baaki hai:\n' + left.map((b) => `• ${b.title} (${b.mins} min)`).join('\n') + '\n\nEk-ek karo, ek saath nahi.';
  }

  function reply(q) {
    const t = String(q || '').toLowerCase();

    if (/(aaj|today).*(kya|kaam|karna)|kya karu/.test(t)) return todaySummary();

    if (/(kitne|how many).*(ghante|hour)|time/.test(t)) {
      return 'Do track milaakar roz 3.5 ghante:\n• 50 min learning (video + code)\n• 50 min project ka kaam\n• 40 min paisa (Karya/platform/apply)\n• 20 min English drill\n• 5 min log\n\n90-din akela 3 ghante maangta hai, 12-mahine akela 2 ghante. Overlap ki wajah se 3+2 = 5 nahi, 3.5 banta hai.';
    }

    if (/prompt/.test(t)) {
      return 'Prompt ke 5 part hote hain:\n1. Role — "Tum ek senior Python dev ho"\n2. Task — ek kaam: "is code me bug dhundo"\n3. Context — "main beginner hoon"\n4. Format — "table me: bug, kyun, fix"\n5. Constraint — "sirf 3 bugs, Hinglish me"\n\nPractice → Prompt Lab me likho, main check karungi.';
    }

    if (/(english|angrezi|grammar)/.test(t)) {
      return 'English ke liye roz 20 min: ek bad AI answer lo, 150 words me feedback likho, phir mujhse check karwao.\n\nAsli baat: tumhe fancy English nahi chahiye — 15 fixed patterns chahiye. Practice → English me templates hain.';
    }

    if (/(eval|evaluation)/.test(t)) {
      return 'Eval matlab: AI ke jawab ko rubric se naapna. Formula:\n1. Rubric pehle padho\n2. Har criterion alag score karo (average mat banao)\n3. Exact sentence quote karo\n4. Batao: kya galat, kyun galat, kaise fix\n\nVague feedback ("this is good") = reject. Specific feedback = paisa.';
    }

    if (/(rag)/.test(t)) {
      return 'RAG = Retrieval-Augmented Generation.\nMatlab: pehle tumhare documents me se relevant hissa dhoondo, phir LLM ko wahi deke jawab banwao. Isse hallucination kam hoti hai.\n\nLearning Month 10 me pura month isi pe hai.';
    }

    if (/(paisa|kamai|money|earn)/.test(t)) {
      return 'Sabse fast paisa: Karya (Hindi/Gujarati task, UPI me) → 2-4 hafte.\nUske baad: Outlier multilingual → $15-24/hr.\nCoding track (45-60 din baad) → $22-32/hr.\nLocal: tuition ₹800-1,500/bacche, dukaan ka chhota automation ₹2,000-5,000.\n\n90 Din tab me pura order hai.';
    }

    if (/(karya)/.test(t)) {
      return 'Karya: Play Store se install karo (DAIA Tech). Profile me Gujarati + Hindi + English teeno daalo. Task mile to slow aur perfect karo — pehle 10 task audition hote hain.\nPaisa UPI/bank me, log 15 working days bolte hain. Cap ~$1,500 hai, isliye isko base income na samjho.';
    }

    if (/(outlier|dataannotation|mercora|alignerr)/.test(t)) {
      return 'Order important hai:\n1. Karya (abhi)\n2. Outlier — sirf multilingual Hindi track (2-3 hafte baad)\n3. Stellar / Mindrift (backup)\n4. Mercor, DataAnnotation (2 mahine baad — English chahiye; DA ka sirf 1 attempt)\n\nEk platform pe bharosa mat karo. 3-4 pe active raho.';
    }

    if (/(test|quiz|exam)/.test(t)) {
      return 'Practice → Tests tab kholo. 5 sawaal aayenge, har jawab ke baad explanation milegi. Kam se kam 80% aaye to topic clear hai.';
    }

    if (/(kaun ho|tum kon|who are you|tumhara naam)/.test(t)) {
      return 'Main Zara hoon — tumhari padhai partner. Main is app ke andar rehti hoon: prompt check karti hoon, English sudharti hoon, aur plan yaad dilati hoon.\n\nNote: bina API key ke main rules se chalti hoon (offline). Key daal do to main asli AI se jawab dungi.';
    }

    if (/(thak|bore|mann nahi|motivat)/.test(t)) {
      return 'Thak gaya to 50 min ka rule lagao: sirf 50 min karo, phir 10 min break. Motivation ka intezaar mat karo — timer chalao.\n\nAur yaad rakho: tumhari problem knowledge ki nahi, finish karne ki thi. Aaj ek chhota kaam poora karo — bas ek.';
    }

    if (/(idea|naya|switch|badal)/.test(t)) {
      return 'Naya idea aaya? More → Ideas me park karo. 90 din tak woh band rahega — yeh maine tumhare liye hi banaya hai, kyunki field badalna tumhara sabse bada risk hai.';
    }

    if (/(kya seekh|learning|roadmap|month)/.test(t)) {
      const mo = currentMonth();
      return `Abhi tum Month ${mo.m} pe ho: ${mo.title}.\n\nIs month ka project: ${mo.project.t}\n\nLearning tab me iss month ke 4 week aur resources hain.`;
    }

    /* fallback */
    return 'Samajh gayi. Main in cheezon me madad kar sakti hoon:\n• "aaj kya karna hai"\n• "prompt kaise likhu"\n• "English kaise improve karu"\n• "paisa kaise kamaun"\n• "eval kya hai"\n• "test lo"\n\nYa Practice tab me likho, main check karungi.';
  }

  /* ---------------- 4. OPTIONAL REAL LLM ---------------- */
  async function askLLM(userText) {
    const key = (state.profile.apiKey || '').trim();
    if (!key) return null;
    const base = (state.profile.apiBase || '').replace(/\/$/, '');
    const model = state.profile.apiModel || 'llama-3.1-8b-instant';
    const sys = 'Tum Zara ho — ek padhai partner jo Hinglish (Roman Hindi) me baat karti hai. '
      + 'User 19 saal ka ladka hai, Godhra Gujarat se, AI engineer banna chahta hai, English kamzor hai, paisa kamana chahta hai. '
      + 'Chhote jawab do (max 150 words), simple bhasha, actionable steps. Bullets use karo. Formalities mat karo.';
    try {
      const res = await fetch(base + '/chat/completions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key },
        body: JSON.stringify({
          model,
          messages: [{ role: 'system', content: sys }, { role: 'user', content: userText }],
          temperature: 0.6,
          max_tokens: 400
        })
      });
      if (!res.ok) return null;
      const data = await res.json();
      const out = data && data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
      return out ? String(out).trim() : null;
    } catch (e) {
      return null;
    }
  }

  /* ---------------- 5. VOICE ----------------
     Do engine:
     a) device voice (browser/OS) — free, offline. Best Hindi female voice khud chunti hai.
     b) cloud voice — Sarvam / ElevenLabs / Google TTS. Real ladki jaisi. Key user ki.
     ------------------------------------------------------------ */
  let voicesCache = [];
  let currentAudio = null;
  let lastTtsError = '';

  const FEMALE_HINTS = ['female','woman','swara','neerja','ananya','aarohi','heera','kalpana','lekha','asha','aasha','priya','riya','zira','samantha','ava','jenny','aria','sonia','natasha','veena','shruti','hindi'];
  const NATURAL_HINTS = ['natural','neural','online','enhanced','premium','wavenet','studio','hd','multilingual'];
  const BAD_HINTS = ['male','man ','david','mark','ravi','george','rishi','daniel','alex'];

  function loadVoices() {
    try { voicesCache = window.speechSynthesis ? window.speechSynthesis.getVoices() : []; }
    catch (e) { voicesCache = []; }
    return voicesCache;
  }

  function allVoices() {
    if (!voicesCache.length) loadVoices();
    return (voicesCache || []).map((v) => ({ name: v.name, lang: v.lang, local: v.localService }));
  }

  function findVoice(name) {
    if (!voicesCache.length) loadVoices();
    return (voicesCache || []).find((v) => v.name === name) || null;
  }

  function scoreVoice(v) {
    const n = String(v.name || '').toLowerCase();
    const l = String(v.lang || '').toLowerCase();
    let s = 0;
    if (l.indexOf('hi') === 0) s += 100;               // Hindi — sabse pehle
    else if (l.indexOf('en-in') === 0) s += 55;         // Indian English
    else if (l.indexOf('en') === 0) s += 10;
    if (FEMALE_HINTS.some((h) => n.indexOf(h) >= 0)) s += 45;
    if (NATURAL_HINTS.some((h) => n.indexOf(h) >= 0)) s += 30;
    if (BAD_HINTS.some((h) => n.indexOf(h) >= 0)) s -= 60;
    if (v.localService === false) s += 12;              // cloud voices zyada natural
    return s;
  }

  function bestVoice() {
    if (!voicesCache.length) loadVoices();
    const list = (voicesCache || []).slice();
    if (!list.length) return null;
    list.sort((a, b) => scoreVoice(b) - scoreVoice(a));
    return list[0];
  }

  function chosenVoice() {
    const saved = state.profile.voiceName;
    if (saved) {
      const v = findVoice(saved);
      if (v) return v;
    }
    return bestVoice();
  }

  /* -------- device speak -------- */
  function deviceSpeak(text) {
    try {
      if (!window.speechSynthesis) { lastTtsError = 'Is browser me speech nahi hai'; return false; }
      window.speechSynthesis.cancel();
      const clean = String(text).replace(/[*_#•>`]/g, ' ').replace(/\n+/g, ' ');
      const u = new SpeechSynthesisUtterance(clean);
      const v = chosenVoice();
      /* voice set karna kabhi fail ho sakta hai (stale/invalid voice) — app na ruke */
      let voiceSet = false;
      if (v) {
        try { u.voice = v; voiceSet = true; } catch (e) { voiceSet = false; }
        try { u.lang = v.lang || 'hi-IN'; } catch (e) {}
      }
      if (!voiceSet) u.lang = 'hi-IN';
      u.rate = Number(state.profile.voiceRate) || 0.98;
      u.pitch = Number(state.profile.voicePitch) || 1.08;
      window.speechSynthesis.speak(u);
      lastTtsError = '';
      return true;
    } catch (e) {
      lastTtsError = e.message || 'device speak fail';
      return false;
    }
  }

  /* -------- cloud speak -------- */
  async function cloudSpeak(text) {
    const provider = state.profile.ttsProvider || 'device';
    const key = String(state.profile.ttsKey || '').trim();
    if (provider === 'device' || !key) return false;

    const send = String(text).replace(/[*_#•>`]/g, ' ').replace(/\n+/g, ' ').slice(0, 900);
    let src = null;

    try {
      if (provider === 'sarvam') {
        const speaker = state.profile.ttsVoice || 'anushka';
        const r = await fetch('https://api.sarvam.ai/text-to-speech', {
          method: 'POST',
          headers: { 'api-subscription-key': key, 'Content-Type': 'application/json' },
          body: JSON.stringify({
            inputs: [send], target_language_code: 'hi-IN', speaker,
            model: 'bulbul:v2', speech_sample_rate: 22050, enable_preprocessing: true
          })
        });
        if (!r.ok) throw new Error('Sarvam ' + r.status);
        const j = await r.json();
        const b64 = (j.audios && j.audios[0]) || j.audio;
        if (!b64) throw new Error('Sarvam: audio nahi mila');
        src = 'data:audio/wav;base64,' + b64;

      } else if (provider === 'elevenlabs') {
        const voiceId = state.profile.ttsVoice || '21m00Tcm4TlvDq8ikWAM';
        const r = await fetch('https://api.elevenlabs.io/v1/text-to-speech/' + voiceId + '?output_format=mp3_44100_128', {
          method: 'POST',
          headers: { 'xi-api-key': key, 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text: send, model_id: 'eleven_multilingual_v2',
            voice_settings: { stability: 0.4, similarity_boost: 0.8, style: 0.2 }
          })
        });
        if (!r.ok) throw new Error('ElevenLabs ' + r.status);
        const blob = await r.blob();
        src = URL.createObjectURL(blob);

      } else if (provider === 'google') {
        const voice = state.profile.ttsVoice || 'hi-IN-Neural2-A';
        const r = await fetch('https://texttospeech.googleapis.com/v1/text:synthesize?key=' + encodeURIComponent(key), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            input: { text: send },
            voice: { languageCode: 'hi-IN', name: voice },
            audioConfig: { audioEncoding: 'MP3', speakingRate: Number(state.profile.voiceRate) || 1.0, pitch: 0 }
          })
        });
        if (!r.ok) throw new Error('Google TTS ' + r.status);
        const j = await r.json();
        if (!j.audioContent) throw new Error('Google: audio nahi mila');
        src = 'data:audio/mp3;base64,' + j.audioContent;
      }

      if (!src) return false;
      stopSpeak();
      currentAudio = new Audio(src);
      await currentAudio.play().catch(() => {});
      return true;
    } catch (e) {
      lastTtsError = e.message || 'cloud voice fail';
      return false;
    }
  }

  /* -------- public speak -------- */
  async function speak(text) {
    if (!state.profile.voice) return false;
    const t = String(text || '').trim();
    if (!t) return false;

    if ((state.profile.ttsProvider || 'device') !== 'device' && state.profile.ttsKey) {
      const ok = await cloudSpeak(t);
      if (ok) return true;
      /* cloud fail — device voice se bol do, aur ek baar batao */
      if (typeof toast === 'function') toast('Cloud voice fail: ' + lastTtsError + ' — device voice use kar rahi hoon');
    }
    return deviceSpeak(t);
  }

  function stopSpeak() {
    try { window.speechSynthesis && window.speechSynthesis.cancel(); } catch (e) {}
    try {
      if (currentAudio) { currentAudio.pause(); currentAudio.currentTime = 0; currentAudio = null; }
    } catch (e) {}
  }

  /* -------- voice test (Settings se) -------- */
  async function testVoice(sample) {
    const line = sample || ('Namaste Aadil! Main Zara hoon. Aaj ka pehla kaam: Python functions practice. '
      + 'Chalo shuru karein — sirf paanch minute lagenge.');
    if (!state.profile.voice) state.profile.voice = true;
    return await speak(line);
  }

  function ttsStatus() {
    const v = chosenVoice();
    return {
      engine: (state.profile.ttsProvider || 'device') === 'device' ? 'device' : state.profile.ttsProvider,
      voice: v ? v.name : '—',
      lang: v ? v.lang : '—',
      error: lastTtsError
    };
  }

  /* -------- speech-to-text (mic) -------- */
  function listen(onText, onErr) {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { onErr && onErr('Is browser me mic support nahi hai. Chrome use karo.'); return; }
    try {
      const rec = new SR();
      rec.lang = 'hi-IN';
      rec.interimResults = false;
      rec.maxAlternatives = 1;
      rec.onresult = (e) => {
        const txt = e.results[0][0].transcript;
        onText && onText(txt);
      };
      rec.onerror = (e) => onErr && onErr('Mic error: ' + (e.error || 'unknown') + '. Permission check karo.');
      rec.start();
    } catch (e) {
      onErr && onErr('Mic start nahi hua. Permission do ya Chrome me kholo.');
    }
  }

  if (typeof window !== 'undefined' && window.speechSynthesis) {
    try { window.speechSynthesis.onvoiceschanged = loadVoices; } catch (e) {}
    setTimeout(loadVoices, 300);
    setTimeout(loadVoices, 1500);
  }

  return { promptFeedback, englishFeedback, reply, askLLM, speak, stopSpeak, listen,
           allVoices, findVoice, bestVoice, chosenVoice, testVoice, ttsStatus, loadVoices };
})();
```

#### `js/views.js`

```js
/* ============================================================
   views.js — v3 UX
   Ek app, do mode: 90 Din (red) aur Learning (indigo).
   Upar switch se turant badal jata hai. Neeche ka "aaj" same rehta hai.
   ============================================================ */

const ui = {
  nav: 'home',        // home | plan | practice | more
  mode: '90',         // 90 | learn  <- roadmap switch
  more: null,
  practice: 'prompt',
  openPhase: 'p1',
  openMonth: null,
  promptRes: null,
  englishRes: null,
  quiz: null,
  cloudTest: null
};

const draft = { prompt: '', english: '' };

/* ---------------- shared bits ---------------- */
function modeSwitch() {
  const t90 = t90Stats();
  const lr = learnStats();
  return `
    <div class="modeswitch">
      <button data-act="mode" data-mode="90" class="${ui.mode === '90' ? 'on' : ''}">
        <span class="dot"></span> 90 Din${t90.pct ? ` <span class="count">${t90.pct}%</span>` : ''}
      </button>
      <button data-act="mode" data-mode="learn" class="${ui.mode === 'learn' ? 'on' : ''}">
        <span class="dot"></span> Learning${lr.pct ? ` <span class="count">${lr.pct}%</span>` : ''}
      </button>
    </div>`;
}

function nextTask90() {
  for (const ph of PLAN_90) {
    for (let i = 0; i < ph.tasks.length; i++) {
      if (!state.t90.done[ph.id + '-' + i]) return { ph, i, t: ph.tasks[i] };
    }
  }
  return null;
}

function nextWeekLearn() {
  const mo = currentMonth();
  for (const w of mo.weeks) {
    if (!state.learn.done['m' + mo.m + '-' + w.w]) return { mo, w };
  }
  if (!state.learn.done['m' + mo.m + '-proj']) return { mo, proj: true };
  return { mo };
}

/* ============================================================
   HOME — dono track ek jagah
   ============================================================ */
function vHome() {
  const rec = todayRec();
  const done = blocksDone(rec);
  const pct = Math.round((done / DAILY_BLOCKS.length) * 100);
  const wk = weekStartISO(todayISO());
  const name = state.profile.name || 'Aadil';

  const blocks = DAILY_BLOCKS.map((b) => {
    const isDone = !!rec.blocks[b.id];
    const trk = b.track === '90' ? 'trk-90' : b.track === 'learn' ? 'trk-learn' : 'trk-both';
    return `
      <div class="blk ${isDone ? 'done' : ''}" data-act="toggle-block" data-id="${b.id}">
        <div class="cb">${icon('check')}</div>
        <div class="blk-main">
          <div class="blk-title"><span class="trk ${trk}"></span>${esc(b.title)}</div>
          <div class="blk-hint">${b.mins} min · ${esc(b.hint)}</div>
        </div>
      </div>`;
  }).join('');

  return `
  ${modeSwitch()}

  <div class="hero ${ui.mode === '90' ? 'm90' : 'mlearn'}">
    <div class="hero-top">
      <div class="eyebrow">${ui.mode === '90' ? '90-din track' : 'Learning track'}</div>
      <div class="hero-pill num">${done}/${DAILY_BLOCKS.length} aaj</div>
    </div>
    <h2>${esc(name)}, aaj ka din</h2>
    <p>${done >= DAILY_BLOCKS.length ? 'Sab ho gaya — streak bach gaya.' : done >= 4 ? 'Bas ek-do block bache hain.' : 'Ek-ek block. Bas shuru karo.'}</p>
    <div class="hero-bar"><i style="width:${pct}%"></i></div>
    <div class="hero-stats">
      <div class="hero-stat"><b>${ui.mode === '90' ? day90() : 'M' + currentMonth().m}</b><span>${ui.mode === '90' ? 'din / 90' : 'mahina'}</span></div>
      <div class="hero-stat"><b>${streak()}</b><span>din streak</span></div>
      <div class="hero-stat"><b>${weekHours(wk)}</b><span>ghante/hafta</span></div>
    </div>
  </div>

  <div class="sec"><h3>Aaj ka plan</h3><span class="tiny muted">${TOTAL_MINS} min</span></div>
  <div class="card tight">${blocks}</div>

  <div class="sec"><h3>${ui.mode === '90' ? 'Agla kaam' : 'Agla step'}</h3></div>
  ${ui.mode === '90' ? next90Card() : nextLearnCard()}

  <div class="sec"><h3>Aaj ka log</h3><span class="tiny muted">kya banaya / kya atka</span></div>
  <div class="card">
    <textarea id="logArea" placeholder="Aaj: ...&#10;Atka: ...&#10;Kal: ...">${esc(rec.log || '')}</textarea>
    <button class="btn soft sm mt10" data-act="save-log">Log save karo</button>
  </div>

  <div class="stat-row">
    <div class="stat" data-act="more" data-sub="money" style="cursor:pointer">
      <b>${inr(monthEarn())}</b><span>is mahine</span>
    </div>
    <div class="stat" data-act="more" data-sub="projects" style="cursor:pointer">
      <b>${shippedCount()}/${state.projects.length}</b><span>project</span>
    </div>
    <div class="stat" data-act="nav" data-nav="practice" style="cursor:pointer">
      <b>${state.evals.length}</b><span>evals</span>
    </div>
  </div>
  `;
}

function next90Card() {
  const n = nextTask90();
  if (!n) {
    return `<div class="card">
      <div class="card-title">Sab kaam ho gaye</div>
      <div class="card-sub">Day 91 pe repeat plan kholo — rate 2x.</div>
    </div>`;
  }
  const ps = phaseStats(n.ph);
  return `
  <div class="card">
    <div class="row between" style="align-items:flex-start">
      <div style="flex:1;min-width:0">
        <span class="tag red">${esc(n.ph.name)}</span>
        <div class="card-title mt6">${esc(n.t.t)}</div>
        <div class="card-sub">${esc(n.ph.range)} · ${ps.done}/${ps.total} ho gaye</div>
      </div>
    </div>
    ${progressBar(Math.round((ps.done / ps.total) * 100))}
    <div class="mt10">
      <div class="hr-label" style="margin-top:0">Kaise karna hai</div>
      <ol style="margin:0;padding-left:18px;font-size:12.5px;color:var(--text-2);line-height:1.6">
        ${n.t.how.slice(0, 3).map((h) => `<li>${esc(h)}</li>`).join('')}
      </ol>
    </div>
    <button class="btn accent block mt14" data-act="nav" data-nav="plan">Poora plan dekho</button>
  </div>`;
}

function nextLearnCard() {
  const n = nextWeekLearn();
  const ms = monthStats(n.mo);
  return `
  <div class="card">
    <div class="row between" style="align-items:flex-start">
      <div style="flex:1;min-width:0">
        <span class="tag indigo">Month ${n.mo.m}</span>
        <div class="card-title mt6">${esc(n.mo.title)}</div>
        <div class="card-sub">${esc(n.mo.focus)}</div>
      </div>
    </div>
    ${progressBar(Math.round((ms.done / ms.total) * 100), 'indigo')}
    <div class="mt10">
      <div class="hr-label" style="margin-top:0">${n.proj ? 'Is month ka project' : 'Is hafte ka topic'}</div>
      <div style="font-size:13px;font-weight:600">${esc(n.proj ? n.mo.project.t : (n.w.w + ' — ' + n.w.d))}</div>
    </div>
    <button class="btn indigo block mt14" data-act="nav" data-nav="plan">Learning plan khole</button>
  </div>`;
}

/* ============================================================
   PLAN — dono roadmap, switch se
   ============================================================ */
function vPlan() {
  return `
  ${modeSwitch()}
  <div class="blk-head">
    <div>
      <div class="blk-head-t">${ui.mode === '90' ? '90-din roadmap' : 'Learning roadmap'}</div>
      <div class="blk-head-s">${ui.mode === '90'
        ? 'Fixed dates · paisa + proof · ' + day90() + '/90 din'
        : 'Flexible · 13 mahine · ' + learnStats().pct + '% ho gaya'}</div>
    </div>
  </div>
  ${ui.mode === '90' ? plan90Body() : learnBody()}
  `;
}

/* ---------------- 90 din ---------------- */
function plan90Body() {
  const st = t90Stats();
  const phases = PLAN_90.map((ph, idx) => {
    const ps = phaseStats(ph);
    const open = ui.openPhase === ph.id;
    const pct = Math.round((ps.done / ps.total) * 100);
    const tasks = ph.tasks.map((t, i) => {
      const key = ph.id + '-' + i;
      const isDone = !!state.t90.done[key];
      return `
        <div class="task ${isDone ? 'done' : ''}">
          <div class="task-top" data-act="toggle-t90" data-key="${key}">
            <div class="cb">${icon('check')}</div>
            <div class="task-txt">${esc(t.t)}</div>
          </div>
          <details class="how">
            <summary>Kaise karna hai</summary>
            <div class="how-body">
              <ol>${t.how.map((h) => `<li>${esc(h)}</li>`).join('')}</ol>
              ${t.why ? `<div class="mt6"><b>Kyun:</b> ${esc(t.why)}</div>` : ''}
            </div>
          </details>
        </div>`;
    }).join('');

    return `
      <div class="card phase is-90">
        <div class="phase-head" data-act="open-phase" data-id="${ph.id}">
          <div class="phase-num">${idx + 1}</div>
          <div class="phase-meta">
            <div class="phase-name">${esc(ph.name)}</div>
            <div class="phase-range">${esc(ph.range)} · ${esc(ph.goal || '')}</div>
          </div>
          <div class="ph-end">
            <span class="cnt num">${ps.done}/${ps.total}</span>
            <div class="chev ${open ? 'open' : ''}">${icon('chev')}</div>
          </div>
        </div>
        <div class="head-bar">${progressBar(pct)}</div>
        ${open ? tasks : ''}
      </div>`;
  }).join('');

  return `
  <div class="card flat">
    <div class="row between">
      <div>
        <div class="card-sub">Progress</div>
        <div style="font-size:20px;font-weight:750" class="num">${st.done} / ${st.total}</div>
      </div>
      <div class="badge red">Day ${day90()}</div>
    </div>
    <div class="mt10">${progressBar(st.pct)}</div>
    <div class="tiny muted mt6">Yeh track date pe chalta hai — learning jahan bhi ho, nahi rukta.</div>
  </div>
  ${phases}`;
}

/* ---------------- learning ---------------- */
function learnBody() {
  const st = learnStats();
  const cm = currentMonth();
  const openMonth = ui.openMonth === null ? cm.m : ui.openMonth;

  const months = LEARN_MONTHS.map((mo) => {
    const ms = monthStats(mo);
    const open = openMonth === mo.m;
    const pct = Math.round((ms.done / ms.total) * 100);
    const weeks = mo.weeks.map((w) => {
      const key = 'm' + mo.m + '-' + w.w;
      const isDone = !!state.learn.done[key];
      return `
        <div class="week ${isDone ? 'done' : ''}" data-act="toggle-learn" data-key="${key}">
          <div class="cb" style="width:18px;height:18px;border-radius:6px;${isDone ? 'background:var(--ok);border-color:var(--ok)' : ''}">${icon('check')}</div>
          <div class="week-n">${w.w}</div>
          <div class="week-txt">${esc(w.d)}</div>
        </div>`;
    }).join('');

    const projKey = 'm' + mo.m + '-proj';
    const projDone = !!state.learn.done[projKey];
    const res = (mo.res || []).map((r) => r.u
      ? `<a class="res-link" href="${esc(r.u)}" target="_blank" rel="noopener">${icon('link')}${esc(r.l)}</a>`
      : `<div class="res-link" style="color:var(--text-2)">${icon('info')}${esc(r.l)}</div>`).join('');

    return `
      <div class="card phase is-learn">
        <div class="mon-head" data-act="open-month" data-m="${mo.m}">
          <div class="mon-badge"><b>${mo.m}</b><i>MON</i></div>
          <div class="phase-meta">
            <div class="phase-name">${esc(mo.title)}</div>
            <div class="phase-range">${esc(mo.focus)}</div>
          </div>
          <div class="ph-end">
            <span class="cnt num">${ms.done}/${ms.total}</span>
            <div class="chev ${open ? 'open' : ''}">${icon('chev')}</div>
          </div>
        </div>
        <div class="head-bar">${progressBar(pct, 'indigo')}</div>
        ${open ? `
          <div class="mon-body">
            ${weeks}
            <div class="proj-box">
              <div class="row between">
                <b>Project: ${esc(mo.project.t)}</b>
                <div class="cb" style="width:18px;height:18px;border-radius:6px;${projDone ? 'background:var(--ok);border-color:var(--ok)' : ''}"
                     data-act="toggle-learn" data-key="${projKey}">${icon('check')}</div>
              </div>
              <ol>${mo.project.steps.map((s) => `<li>${esc(s)}</li>`).join('')}</ol>
            </div>
            ${res ? `<div class="res-links">${res}</div>` : ''}
            ${mo.note ? `<div class="how-body" style="margin-top:12px;font-size:12px;color:var(--text-2)">${esc(mo.note)}</div>` : ''}
          </div>` : ''}
      </div>`;
  }).join('');

  return `
  <div class="card flat">
    <div class="row between">
      <div>
        <div class="card-sub">Abhi</div>
        <div style="font-size:20px;font-weight:750" class="num">Month ${cm.m}</div>
      </div>
      <div class="badge indigo">${st.pct}% total</div>
    </div>
    <div class="mt10">${progressBar(st.pct, 'indigo')}</div>
    <div class="tiny muted mt6">12 month target · 13 lage to koi problem nahi. Deadline nahi, direction hai.</div>
  </div>

  ${adaptedCard()}
  ${months}`;
}

function adaptedCard() {
  const open = ui.more === 'adapted';
  const rows = [
    ['Month 1', 'Excel dashboard hataya', 'Python + scripts pe pura time — AI engineer ko Excel ka basic kaafi'],
    ['Month 3', 'EDA 4 hafte → 3 hafte', 'Chautha hafta SQL ko diya — SQL se freelance kaam milta hai'],
    ['Month 4', 'Power BI / Tableau skip', 'Data analyst ka kaam nahi chahiye. Uski jagah FastAPI early start'],
    ['Month 4', 'FastAPI jaldi shuru', 'API deploy karna aana = paisa kamane layak banna'],
    ['Month 7', 'Deep Learning 4 → 3 hafte', 'CNN project rakha, RNN sirf samajhne ke liye'],
    ['Month 12-13', 'Buffer month add', '13 mahine lage to guilt nahi — tumne khud bola tha'],
    ['Resources', 'Hindi-first', 'CodeWithHarry / CampusX — English weak hai, isliye'],
    ['Resume/LinkedIn', 'Sample copy nahi', 'Woh 10 saal experience wale ke hain. Tumhara resume projects se banega']
  ];
  return `
  <div class="card">
    <div class="row between" data-act="adapted-toggle" style="cursor:pointer">
      <div>
        <div class="card-title">Tumhare hisaab se kya badla</div>
        <div class="card-sub">11th pass, English weak, paisa jaldi chahiye, degree nahi</div>
      </div>
      <div class="chev ${open ? 'open' : ''}">${icon('chev')}</div>
    </div>
    ${open ? `<div class="mt10">
      ${rows.map((r) => `
        <div style="padding:9px 0;border-top:1px solid var(--line)">
          <div class="row between"><b class="small">${esc(r[0])}</b><span class="tiny muted">${esc(r[1])}</span></div>
          <div class="tiny muted mt6">${esc(r[2])}</div>
        </div>`).join('')}
    </div>` : ''}
  </div>`;
}

/* ============================================================
   PRACTICE
   ============================================================ */
function vPractice() {
  const tabs = `
    <div class="seg">
      <button class="${ui.practice === 'prompt' ? 'on' : ''}" data-act="practice-tab" data-t="prompt">Prompt Lab</button>
      <button class="${ui.practice === 'english' ? 'on' : ''}" data-act="practice-tab" data-t="english">English</button>
      <button class="${ui.practice === 'tests' ? 'on' : ''}" data-act="practice-tab" data-t="tests">Tests</button>
    </div>`;

  if (ui.practice === 'prompt') return tabs + practicePrompt();
  if (ui.practice === 'english') return tabs + practiceEnglish();
  return tabs + practiceTests();
}

function practicePrompt() {
  const r = ui.promptRes;
  const resultHTML = r ? `
    <div class="card">
      <div class="score-head">
        <div>
          <div class="score-num ${r.score >= 75 ? 'good' : r.score >= 50 ? 'mid' : 'low'}">${r.score}</div>
          <div class="tiny muted">/ 100</div>
        </div>
        <div class="score-meta">
          ${progressBar(r.score, r.score >= 75 ? 'ok' : '')}
          <div class="tiny muted mt6">${r.score >= 75 ? 'Achha prompt hai.' : r.score >= 50 ? 'Theek hai, sudhaar possible hai.' : 'Yeh galti tumhari hai — prompt adhoora hai. Neeche jo missing hai wo add karo.'}</div>
        </div>
      </div>
      <div class="divider"></div>
      ${r.items.map((it) => `
        <div class="fb">
          <div class="fb-dot ${it.type}"></div>
          <div>${esc(it.text)}</div>
        </div>`).join('')}
      <div class="how-body" style="margin-top:12px"><b>Zara ki salah:</b> ${esc(r.next)}</div>
      <div class="row gap mt10">
        <button class="btn sm soft" data-act="speak" data-text="${esc(r.next)}">${icon('play')} Suno</button>
        <button class="btn sm ghost" data-act="prompt-save">Save karo</button>
      </div>
    </div>` : '';

  return `
  <div class="card">
    <div class="card-title">Prompt likho</div>
    <div class="card-sub">Zara check karegi — role, task, context, format, constraint</div>
    <textarea id="promptArea" class="mt10" placeholder="Tum ek senior Python developer ho. Neeche diye code me bug dhundo. Main beginner hoon. Output table me do: bug, kyun, fix. Sirf 3 bug. Hinglish me.">${esc(draft.prompt)}</textarea>
    <div class="row gap mt10">
      <button class="btn accent" data-act="check-prompt">Check karwao</button>
      <button class="btn ghost" data-act="prompt-example">Example</button>
    </div>
  </div>
  ${resultHTML}
  <div class="sec"><h3>Prompt ke 5 part</h3></div>
  <div class="card">
    ${PROMPT_PARTS.map((p) => `<div class="tpl"><b>${esc(p.name)}</b>"${esc(p.ex)}"</div>`).join('')}
  </div>`;
}

function practiceEnglish() {
  const r = ui.englishRes;
  const words = draft.english.trim() ? draft.english.trim().split(/\s+/).length : 0;
  const tpl = ENGLISH_TEMPLATES.map((g) => `
    <div class="hr-label" style="margin:12px 0 6px">${esc(g.g)}</div>
    ${g.items.map((i) => `<div class="tpl">${esc(i)}</div>`).join('')}`).join('');

  const resultHTML = r ? `
    <div class="card">
      <div class="score-head">
        <div>
          <div class="score-num ${r.score >= 75 ? 'good' : r.score >= 50 ? 'mid' : 'low'}">${r.score}</div>
          <div class="tiny muted">/ 100 · ${r.words} words</div>
        </div>
        <div class="score-meta">${progressBar(r.score, r.score >= 75 ? 'ok' : '')}</div>
      </div>
      <div class="divider"></div>
      ${r.items.map((it) => `<div class="fb"><div class="fb-dot ${it.type}"></div><div>${esc(it.text)}</div></div>`).join('')}
      <div class="how-body" style="margin-top:12px"><b>Zara ki salah:</b> ${esc(r.next)}</div>
      <div class="row gap mt10">
        <button class="btn sm soft" data-act="eval-save">Eval me save karo</button>
        <button class="btn sm ghost" data-act="speak" data-text="${esc(r.next)}">${icon('play')} Suno</button>
      </div>
    </div>` : '';

  return `
  <div class="card">
    <div class="card-title">English eval drill</div>
    <div class="card-sub">Ek bad AI answer lo, 150 words me feedback likho. Hindi me socho, English me likho.</div>
    <textarea id="englishArea" class="mt10" placeholder="This response is correct but incomplete. It says Python is used for data science. It should also mention web development and automation...">${esc(draft.english)}</textarea>
    <div class="row between mt6">
      <span class="tiny muted" id="wordCount">${words} words</span>
      <button class="btn sm ghost" data-act="load-samples">Sample</button>
    </div>
    <button class="btn accent block mt10" data-act="check-english">Check karwao</button>
  </div>
  ${resultHTML}
  <div class="sec"><h3>15 templates</h3><span class="tiny muted">ratna hai</span></div>
  <div class="card">${tpl}</div>`;
}

function practiceTests() {
  const q = ui.quiz;
  if (!q) {
    const last = state.tests.slice().sort((a, b) => (a.at < b.at ? 1 : -1))[0];
    return `
    <div class="card">
      <div class="card-title">Test lo</div>
      <div class="card-sub">5 sawaal · prompt, eval, AI basics, paisa. Har jawab ke baad explanation.</div>
      <button class="btn accent block mt14" data-act="start-test">Test shuru karo</button>
      ${last ? `<div class="tiny muted mt10">Pichla: ${last.score}/5 · ${fmtDate(last.at)}</div>` : ''}
    </div>
    ${state.tests.length ? `<div class="card">
      <div class="card-title">Purane tests</div>
      ${state.tests.slice().reverse().slice(0, 6).map((t) => `
        <div class="kv"><span class="muted">${fmtDate(t.at)}</span><b>${t.score}/5</b></div>`).join('')}
    </div>` : ''}`;
  }

  if (q.idx >= q.list.length) {
    const s = q.score;
    return `
    <div class="card center">
      <div class="score-num ${s >= 4 ? 'good' : s >= 3 ? 'mid' : 'low'}" style="font-size:42px">${s}/5</div>
      <div class="muted small mt6">${s >= 4 ? 'Bahut achha — topic clear hai.' : s >= 3 ? 'Theek hai, thoda revise karo.' : 'Kam hai — templates dobara padho.'}</div>
      <button class="btn accent block mt14" data-act="start-test">Dubara</button>
      <button class="btn ghost block mt10" data-act="end-test">Wapas</button>
    </div>`;
  }

  const item = q.list[q.idx];
  return `
  <div class="card">
    <div class="row between"><span class="tiny muted">Sawaal ${q.idx + 1} / ${q.list.length}</span><span class="tiny muted">Sahi: ${q.score}</span></div>
    <div class="mt6">${progressBar((q.idx / q.list.length) * 100)}</div>
    <div class="qbox mt14">${esc(item.q)}</div>
    ${item.o.map((opt, i) => {
      let cls = '';
      if (q.answered !== null) {
        if (i === item.a) cls = 'right';
        else if (i === q.answered) cls = 'wrong';
      }
      return `<button class="opt ${cls}" data-act="answer" data-i="${i}" ${q.answered !== null ? 'disabled' : ''}>${esc(opt)}</button>`;
    }).join('')}
    ${q.answered !== null ? `
      <div class="how-body mt10"><b>${q.answered === item.a ? 'Sahi!' : 'Galat.'}</b> ${esc(item.e)}</div>
      <button class="btn accent block mt10" data-act="next-q">Agla sawaal</button>` : ''}
  </div>`;
}

/* ============================================================
   MORE
   ============================================================ */
function vMore() {
  if (ui.more === 'projects') return vProjects();
  if (ui.more === 'money') return vMoney();
  if (ui.more === 'platforms') return vPlatforms();
  if (ui.more === 'ideas') return vIdeas();
  if (ui.more === 'weekly') return vWeekly();
  if (ui.more === 'settings') return vSettings();

  const rows = [
    { k: 'projects', i: 'folder', t: 'Projects', s: `${shippedCount()} shipped / ${state.projects.length}` },
    { k: 'money', i: 'wallet', t: 'Paisa', s: `${inr(totalEarn())} ab tak` },
    { k: 'platforms', i: 'list', t: 'Platforms', s: `${state.platforms.filter((p) => p.status === 'tasks' || p.status === 'paid').length} active` },
    { k: 'ideas', i: 'bulb', t: 'Ideas parking', s: `${state.ideas.length} parked · Day 91 pe khulenge` },
    { k: 'weekly', i: 'chart', t: 'Weekly scorecard', s: '6 number, har Sunday' },
    { k: 'settings', i: 'gear', t: 'Settings', s: 'naam, theme, awaaz, cloud, export' }
  ];

  return `
  <div class="blk-head">
    <div class="blk-head-t">Sab kuch</div>
    <div class="blk-head-s">projects · paisa · platforms · settings</div>
  </div>

  <div class="card flat">
    <div class="row between">
      <div style="text-align:center;flex:1"><div style="font-size:17px;font-weight:750" class="num">${inr(totalEarn())}</div><div class="tiny muted">kamai</div></div>
      <div style="width:1px;height:30px;background:var(--line)"></div>
      <div style="text-align:center;flex:1"><div style="font-size:17px;font-weight:750" class="num">${shippedCount()}/${state.projects.length}</div><div class="tiny muted">projects</div></div>
      <div style="width:1px;height:30px;background:var(--line)"></div>
      <div style="text-align:center;flex:1"><div style="font-size:17px;font-weight:750" class="num">${state.evals.length}</div><div class="tiny muted">evals</div></div>
    </div>
  </div>

  <div class="card tight">
    ${rows.map((r) => `
      <div class="item" data-act="more" data-sub="${r.k}">
        <div class="item-ico">${icon(r.i)}</div>
        <div class="item-body"><div class="item-title">${r.t}</div><div class="item-sub">${r.s}</div></div>
        <div class="item-right">${icon('arrow')}</div>
      </div>`).join('')}
  </div>

  <button class="btn block mt14" data-act="open-zara">
    ${icon('zara')} Zara se baat karo
    <span class="tiny muted" style="margin-left:6px">${state.profile.ttsProvider !== 'device' ? 'cloud voice' : 'Hinglish'}</span>
  </button>

  <div class="tiny muted center mt20">
    ekRaasta v3 · Aadil ka app<br>
    Data isi device pe · cloud on hai to dono device pe same
  </div>`;
}

function subHead(title) {
  return `<div class="row gap" style="margin-bottom:14px">
    <button class="icon-btn" data-act="more" data-sub="">${icon('arrow')}</button>
    <div style="font-size:17px;font-weight:750;letter-spacing:-.3px">${esc(title)}</div>
  </div>`;
}

function vProjects() {
  const list = state.projects.map((p) => {
    const cls = p.status === 'done' ? 'ok' : p.status === 'wip' ? 'warn' : '';
    return `
    <div class="card">
      <div class="row between">
        <div class="card-title" style="flex:1">${esc(p.name)}</div>
        <span class="badge ${cls}">${p.status === 'done' ? 'Shipped' : p.status === 'wip' ? 'Chalu' : 'Todo'}</span>
      </div>
      <div class="row wrap gap" style="gap:5px;margin-top:8px">
        ${(p.tags || []).map((t) => `<span class="tag">${esc(t)}</span>`).join('')}
      </div>
      ${p.link ? `<a class="res-link" style="padding-left:0" href="${esc(p.link)}" target="_blank" rel="noopener">${icon('link')}${esc(p.link.replace(/^https?:\/\//, ''))}</a>` : ''}
      <div class="g2 mt10">
        <select data-act="proj-status" data-id="${p.id}">
          <option value="todo" ${p.status === 'todo' ? 'selected' : ''}>Todo</option>
          <option value="wip" ${p.status === 'wip' ? 'selected' : ''}>Chalu</option>
          <option value="done" ${p.status === 'done' ? 'selected' : ''}>Ho gaya</option>
        </select>
        <input type="url" data-act="proj-link" data-id="${p.id}" placeholder="GitHub link" value="${esc(p.link)}" />
      </div>
    </div>`;
  }).join('');

  return subHead('Projects') + `
    <div class="tiny muted" style="margin:-6px 2px 12px">${shippedCount()} shipped out of ${state.projects.length}. Shipped matlab chalta hai.</div>
    ${list}`;
}

function vMoney() {
  const rows = state.earnings.length ? state.earnings.slice().reverse().map((e) => `
    <div class="item" style="cursor:default">
      <div class="item-ico">${icon('wallet')}</div>
      <div class="item-body">
        <div class="item-title num">${inr(toINR(e.amount, e.cur))}</div>
        <div class="item-sub">${fmtDate(e.date)} · ${esc(e.platform)}${e.note ? ' · ' + esc(e.note) : ''}</div>
      </div>
      <button class="icon-btn" data-act="del-earn" data-id="${e.id}">${icon('trash')}</button>
    </div>`).join('') : emptyBox('wallet', 'Abhi ₹0. Yeh normal hai.<br>Pehla paisa Karya se 2-4 hafte me.');

  const platOpts = state.platforms.map((p) => `<option value="${esc(p.name)}">${esc(p.name)}</option>`).join('');

  return subHead('Paisa') + `
    <div class="card flat">
      <div class="row between">
        <div><div class="card-sub">Is mahine</div><div class="money-big">${inr(monthEarn())}</div></div>
        <div style="text-align:right"><div class="card-sub">Ab tak</div><div style="font-size:19px;font-weight:750" class="num">${inr(totalEarn())}</div></div>
      </div>
    </div>

    <div class="card">
      <div class="card-title">Kamai add karo</div>
      <div class="g2 mt10">
        <label class="f"><span>Date</span><input type="date" id="eDate" value="${todayISO()}" /></label>
        <label class="f"><span>Platform</span><select id="ePlat">${platOpts}<option>Other</option></select></label>
        <label class="f"><span>Amount</span><input type="number" id="eAmt" placeholder="0" step="0.01" /></label>
        <label class="f"><span>Currency</span><select id="eCur"><option value="INR">INR ₹</option><option value="USD">USD $</option></select></label>
      </div>
      <label class="f"><span>Note</span><input type="text" id="eNote" placeholder="kaam kya tha" /></label>
      <button class="btn accent block" data-act="add-earn">Add karo</button>
    </div>

    <div class="card tight">${rows}</div>`;
}

function vPlatforms() {
  const t = todayISO();
  const sorted = state.platforms.slice().sort((a, b) => {
    const ad = a.due || '9999'; const bd = b.due || '9999';
    return ad < bd ? -1 : ad > bd ? 1 : 0;
  });

  const cards = sorted.map((p) => {
    const due = p.due && p.due <= t && p.status !== 'paid';
    const live = p.status === 'tasks' || p.status === 'paid';
    const opts = Object.keys(PLATFORM_STATUS).map((k) =>
      `<option value="${k}" ${p.status === k ? 'selected' : ''}>${PLATFORM_STATUS[k]}</option>`).join('');
    return `
      <div class="card" style="${due ? 'border-color:var(--warn)' : ''}">
        <div class="row between">
          <div class="card-title">${esc(p.name)}</div>
          <span class="badge ${live ? 'ok' : due ? 'warn' : ''}">${PLATFORM_STATUS[p.status] || '—'}</span>
        </div>
        <div class="card-sub mt6">${esc(p.rate || '')}</div>
        <div class="item-sub mt6"><b>Next:</b> ${esc(p.next || '—')}${p.due ? ` · ${fmtDate(p.due)}${due ? ' <span style="color:var(--warn);font-weight:700">due</span>' : ''}` : ''}</div>
        <div class="g2 mt10">
          <select data-act="plat-status" data-id="${p.id}">${opts}</select>
          <input type="date" data-act="plat-due" data-id="${p.id}" value="${esc(p.due || '')}" />
        </div>
      </div>`;
  }).join('');

  return subHead('Platforms') + `
    <div class="tiny muted" style="margin:-6px 2px 12px">Order important hai. Karya pehle — English ki zarurat kam.</div>
    ${cards}`;
}

function vIdeas() {
  const unlock = addDays(state.profile.startDate, 90);
  const left = Math.max(0, daysBetween(todayISO(), unlock));
  const list = state.ideas.length ? state.ideas.slice().reverse().map((i) => `
    <div class="card">
      <div class="row between">
        <div style="flex:1;font-size:13px">${esc(i.text)}</div>
        <button class="icon-btn" data-act="del-idea" data-id="${i.id}">${icon('trash')}</button>
      </div>
      <div class="tiny muted mt6">${fmtDate(i.at)} ko park kiya · Day 91 tak band</div>
    </div>`).join('') : emptyBox('bulb', 'Kuch park nahi hai.<br>Naya idea aaye to yahan likho — phir kaam pe wapas.');

  return subHead('Ideas parking') + `
    <div class="card">
      <div class="card-title">Naya idea aaya?</div>
      <div class="card-sub">Yeh idea achha ho sakta hai. Par abhi nahi. Yahi tumhara pattern hai — isliye park ho raha hai.</div>
      <textarea id="ideaArea" class="mt10" placeholder="Naya idea kya hai..."></textarea>
      <button class="btn accent block mt10" data-act="add-idea">Park karo</button>
    </div>
    <div class="stat-row">
      <div class="stat"><b>${state.ideas.length}</b><span>parked</span></div>
      <div class="stat"><b>${left}</b><span>din baaki</span></div>
      <div class="stat"><b>${day90()}</b><span>aaj ka din</span></div>
    </div>
    ${list}`;
}

function vWeekly() {
  const ws = weekStartISO(todayISO());
  const cur = weekRow(ws);
  const prev = weekRow(addDays(ws, -7));
  const rows = [
    ['Ghante (auto)', cur.hours, prev.hours],
    ['Evals (auto)', cur.evals, prev.evals],
    ['Kamai (auto)', inr(cur.rupees), inr(prev.rupees)],
    ['Repos shipped', cur.repos, prev.repos],
    ['Outreach', cur.outreach, prev.outreach],
    ['Replies', cur.replies, prev.replies]
  ];
  return subHead('Weekly scorecard') + `
    <div class="card">
      <div class="card-sub">Har Sunday yeh 6 number bharo.</div>
      <div class="g2 mt10">
        <label class="f"><span>Repos shipped</span><input type="number" id="wRepos" value="${cur.repos}" min="0" /></label>
        <label class="f"><span>Outreach</span><input type="number" id="wOut" value="${cur.outreach}" min="0" /></label>
        <label class="f"><span>Replies</span><input type="number" id="wRep" value="${cur.replies}" min="0" /></label>
        <label class="f"><span>Ghante (auto)</span><input type="text" value="${cur.hours}" disabled /></label>
      </div>
      <button class="btn accent block" data-act="save-week">Save karo</button>
    </div>
    <div class="card">
      <div class="card-title">Is hafte vs pichla</div>
      <div class="mt6">
        ${rows.map((r) => `<div class="kv"><span class="muted">${r[0]}</span><b>${r[1]} <span class="tiny muted">· pichla ${r[2]}</span></b></div>`).join('')}
      </div>
    </div>
    <button class="btn ghost block" data-act="print">Weekly report print / PDF</button>`;
}

function vSettings() {
  const p = state.profile;
  return subHead('Settings') + `
    <div class="card">
      <div class="card-title">Tumhari detail</div>
      <label class="f mt10"><span>Naam</span><input type="text" id="sName" value="${esc(p.name)}" placeholder="Tumhara naam" /></label>
      <div class="g2">
        <label class="f"><span>90-din Day 1</span><input type="date" id="sStart" value="${p.startDate}" /></label>
        <label class="f"><span>Learning start</span><input type="date" id="sLearn" value="${p.learnStart}" /></label>
      </div>
      <div class="g2">
        <label class="f"><span>Roz ka target (ghante)</span><input type="number" id="sHours" value="${p.hoursPerDay}" step="0.5" min="1" max="12" /></label>
        <label class="f"><span>1 USD = ? INR</span><input type="number" id="sRate" value="${p.usdRate}" min="1" /></label>
      </div>
      <button class="btn accent block" data-act="save-settings">Save karo</button>
    </div>

    <div class="card">
      <div class="row between">
        <div><div class="card-title">Theme</div><div class="card-sub">${p.theme === 'dark' ? 'Dark' : 'Light'} chal raha hai</div></div>
        <button class="btn sm soft" data-act="theme">${icon(p.theme === 'dark' ? 'sun' : 'moon')} Badlo</button>
      </div>
      <div class="divider"></div>
      <div class="row between">
        <div><div class="card-title">Zara bole?</div><div class="card-sub">${p.voice ? 'Bol ke sunati hai' : 'Chup rehti hai'}</div></div>
        <button class="btn sm ${p.voice ? 'soft' : 'ghost'}" data-act="toggle-voice">${p.voice ? 'On' : 'Off'}</button>
      </div>
    </div>

    ${voiceCard()}

    <div class="card">
      <div class="card-title">Zara ka dimag (optional)</div>
      <div class="card-sub">Bina key ke rules se chalti hai — offline. Free Groq key daalo to asli AI.</div>
      <label class="f mt10"><span>API key</span><input type="password" id="sKey" value="${esc(p.apiKey)}" placeholder="gsk_... (khaali chhod do to offline)" /></label>
      <label class="f"><span>API base URL</span><input type="text" id="sBase" value="${esc(p.apiBase)}" /></label>
      <label class="f"><span>Model</span><input type="text" id="sModel" value="${esc(p.apiModel)}" /></label>
      <button class="btn accent block" data-act="save-settings">Save karo</button>
    </div>

    <div class="card">
      <div class="card-title">Cloud sync (login)</div>
      <div class="card-sub">Ek account = phone aur PC dono pe same data</div>
      ${cloudCardBody()}
    </div>

    <div class="card">
      <div class="card-title">App install karo</div>
      <div class="card-sub">Phone ya PC pe icon — browser bar ke bina</div>
      <button class="btn soft block mt10" data-act="install">Install / Add to Home Screen</button>
    </div>

    <div class="card">
      <div class="card-title">Data</div>
      <div class="card-sub">Data isi browser me. Export karke rakh lo.</div>
      <div class="row gap wrap mt10">
        <button class="btn sm ghost" data-act="export">Export</button>
        <button class="btn sm ghost" data-act="import">Import</button>
        <button class="btn sm danger" data-act="reset">Reset</button>
      </div>
      <input type="file" id="importFile" accept="application/json" class="hidden" />
    </div>

    <div class="tiny muted center">ekRaasta v3 · Made for Aadil</div>`;
}

/* ---------------- Zara ki awaaz ---------------- */
function voiceCard() {
  const st = Zara.ttsStatus();
  const list = Zara.allVoices();
  const cur = state.profile.voiceName || (Zara.chosenVoice() ? Zara.chosenVoice().name : '');
  const provider = state.profile.ttsProvider || 'device';

  const options = list.length
    ? list.map((v) => `<option value="${esc(v.name)}" ${v.name === cur ? 'selected' : ''}>${esc(v.name)} · ${esc(v.lang)}</option>`).join('')
    : '<option value="">Koi voice nahi mili</option>';

  return `
  <div class="card">
    <div class="card-title">Zara ki awaaz</div>
    <div class="card-sub">Abhi: <b>${esc(st.voice)}</b> · ${esc(st.engine)}</div>

    <div class="hr-label">Device voice (free)</div>
    <label class="f"><span>Voice</span><select id="vName">${options}</select></label>
    <div class="g2">
      <label class="f"><span>Speed ${Number(state.profile.voiceRate).toFixed(2)}</span>
        <input type="range" id="vRate" min="0.7" max="1.3" step="0.02" value="${state.profile.voiceRate}" /></label>
      <label class="f"><span>Pitch ${Number(state.profile.voicePitch).toFixed(2)}</span>
        <input type="range" id="vPitch" min="0.8" max="1.4" step="0.02" value="${state.profile.voicePitch}" /></label>
    </div>
    <div class="row gap wrap">
      <button class="btn sm accent" data-act="voice-test">Sun ke dekho</button>
      <button class="btn sm ghost" data-act="voice-save">Save</button>
      <button class="btn sm ghost" data-act="voice-refresh">Refresh</button>
    </div>
    <div class="how-body mt10">
      <b>Robotic lage to:</b> Android → Settings → Text-to-speech → Google TTS → "Install voice data" → Hindi.
      PC → Edge me kholo (Microsoft Swara/Neera). Phir "Refresh".
    </div>

    <div class="hr-label">Cloud voice — real ladki jaisi</div>
    <label class="f"><span>Provider</span>
      <select id="tProvider">
        <option value="device" ${provider === 'device' ? 'selected' : ''}>Device voice (free)</option>
        <option value="sarvam" ${provider === 'sarvam' ? 'selected' : ''}>Sarvam AI (Hindi best)</option>
        <option value="elevenlabs" ${provider === 'elevenlabs' ? 'selected' : ''}>ElevenLabs (sabse natural)</option>
        <option value="google" ${provider === 'google' ? 'selected' : ''}>Google Cloud TTS</option>
      </select>
    </label>
    <label class="f"><span>API key</span><input type="password" id="tKey" value="${esc(state.profile.ttsKey)}" placeholder="provider ki key" /></label>
    <label class="f"><span>Voice name / id</span>
      <input type="text" id="tVoice" value="${esc(state.profile.ttsVoice)}"
        placeholder="${provider === 'sarvam' ? 'anushka' : provider === 'elevenlabs' ? '21m00Tcm4TlvDq8ikWAM' : 'hi-IN-Neural2-A'}" /></label>
    <div class="row gap wrap">
      <button class="btn sm accent" data-act="cloud-voice-test">Cloud test</button>
      <button class="btn sm ghost" data-act="cloud-voice-save">Save</button>
    </div>
    <div class="tiny muted mt6">Key sirf isi device pe. Fail ho to device voice pe chali jayegi.</div>
  </div>`;
}

/* ---------------- cloud sync ---------------- */
function cloudCardBody() {
  const st = Cloud.status();

  if (!st.ready) {
    const t = ui.cloudTest;
    const testBox = t ? `<div class="test-box ${t.ok ? 'ok' : 'bad'}">${icon(t.ok ? 'check' : 'info')}<span>${esc(t.msg)}</span></div>` : '';
    return `
      <div class="tiny muted mt10" style="line-height:1.6">
        PC aur phone pe <b>ek hi data</b>. Supabase free hai — 3 minute ka kaam.
      </div>

      <details class="how mt10" open>
        <summary>Step 1 · Supabase project banao</summary>
        <div class="how-body">
          1. <b>supabase.com</b> → Start your project (GitHub/Google se login chalega)<br>
          2. <b>New project</b> → naam kuch bhi, region <b>Mumbai / Singapore</b>, password yaad rakho<br>
          3. 2 minute wait — project ban jayega
        </div>
      </details>

      <details class="how">
        <summary>Step 2 · SQL chalao (copy karo)</summary>
        <div class="how-body">
          Supabase me <b>SQL Editor</b> → New query → niche wala poora paste → <b>RUN</b>.
          <textarea id="sqlBox" class="mt10" wrap="off" style="font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:10.5px;line-height:1.6;min-height:170px;white-space:pre;overflow:auto" readonly>${esc(Cloud.SQL)}</textarea>
          <button class="btn sm soft mt10" data-act="cloud-copy-sql">${icon('code')} SQL copy karo</button>
        </div>
      </details>

      <div class="hr-label" style="margin:14px 0 6px">Step 3 · URL aur key paste karo</div>
      <div class="tiny muted" style="line-height:1.6">Supabase → <b>Project Settings → API</b> → <b>Project URL</b> aur <b>anon public</b> key.</div>
      <label class="f mt10"><span>Supabase URL</span><input type="text" id="cUrl" value="${esc(state.profile.supabaseUrl)}" placeholder="https://xxxxx.supabase.co" /></label>
      <label class="f"><span>Supabase anon key</span><input type="password" id="cKey" value="${esc(state.profile.supabaseKey)}" placeholder="eyJhbGciOi..." /></label>
      <div class="tiny muted">Auth → Providers → Email → <b>Confirm email</b> OFF kar dena, warna login nahi hoga.</div>

      <div class="row gap mt10">
        <button class="btn accent" data-act="cloud-config">Save karo</button>
        <button class="btn ghost" data-act="cloud-test">Test karo</button>
      </div>
      ${testBox}`;
  }

  if (!st.signedIn) {
    return `
      <label class="f mt10"><span>Email</span><input type="email" id="cEmail" placeholder="tumhara@email.com" /></label>
      <label class="f"><span>Password</span><input type="password" id="cPass" placeholder="6+ character" /></label>
      <div class="row gap">
        <button class="btn accent" data-act="cloud-login">Login</button>
        <button class="btn ghost" data-act="cloud-signup">Naya account</button>
      </div>
      <div class="row between mt10">
        <span class="tiny muted">${esc(String(state.profile.supabaseUrl).replace(/^https?:\/\//, ''))}</span>
        <button class="btn sm ghost" data-act="cloud-forget">Config badlo</button>
      </div>`;
  }

  const timeTxt = st.at ? new Date(st.at).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '—';
  const stateTxt = st.state === 'syncing' ? 'Sync ho raha hai...'
    : st.state === 'error' ? 'Error: ' + esc(st.err || '')
    : st.state === 'synced' ? 'Synced · ' + timeTxt : 'Login hai';

  return `
    <div class="row between mt10">
      <div style="min-width:0">
        <div class="small" style="font-weight:650">${esc(st.email)}</div>
        <div class="tiny muted">${stateTxt}</div>
      </div>
      <span class="badge ${st.state === 'error' ? 'warn' : 'ok'}">${st.state === 'error' ? 'Error' : 'Cloud'}</span>
    </div>
    <div class="row gap wrap mt10">
      <button class="btn sm soft" data-act="cloud-push">Push</button>
      <button class="btn sm ghost" data-act="cloud-pull">Pull</button>
      <button class="btn sm danger" data-act="cloud-logout">Logout</button>
    </div>
    <div class="tiny muted mt6">Auto-sync on — har change 3 sec baad cloud pe.</div>`;
}

/* ============================================================
   CHAT
   ============================================================ */
function chatHTML() {
  if (!state.chat.length) {
    return `<div class="msg zara">Namaste Aadil! Main Zara hoon.

Poocho: "aaj kya karna hai", "prompt kaise likhu", "paisa kaise kamaun".</div>`;
  }
  return state.chat.slice(-40).map((m) => `<div class="msg ${m.role}">${esc(m.text)}</div>`).join('');
}

const QUICK_Q = ['Aaj kya karna hai?', 'Prompt kaise likhu?', 'Paisa kaise kamaun?', 'English kaise improve karu?', 'Test lo'];
```

#### `js/app.js`

```js
/* ============================================================
   app.js — boot, router, sab events
   ============================================================ */

/* ---------------- render ---------------- */
function flushInputs() {
  const log = document.getElementById('logArea');
  if (log) todayRec().log = log.value;
  const p = document.getElementById('promptArea');
  if (p) draft.prompt = p.value;
  const e = document.getElementById('englishArea');
  if (e) draft.english = e.value;
  save();
}

const SCREENS = {
  home: vHome,
  plan: vPlan,
  practice: vPractice,
  more: vMore
};

function render() {
  flushInputs();
  const html = (SCREENS[ui.nav] || vHome)();
  document.getElementById('screen').innerHTML = html;

  /* tabbar */
  const navKey = ui.nav;
  document.querySelectorAll('.tab').forEach((t) => {
    t.classList.toggle('on', t.dataset.nav === navKey);
  });

  /* header */
  document.getElementById('logoSub').textContent =
    ui.nav === 'plan'
      ? (ui.mode === '90' ? `90 Din · Day ${day90()}` : `Learning · Month ${currentMonth().m}`)
      : `Day ${day90()} / 90 · Model ${currentMonth().m}`;

  /* english word count live */
  const ta = document.getElementById('englishArea');
  if (ta) {
    ta.addEventListener('input', () => {
      const w = ta.value.trim() ? ta.value.trim().split(/\s+/).length : 0;
      const wc = document.getElementById('wordCount');
      if (wc) { wc.textContent = w + ' words'; wc.style.color = w >= 120 ? 'var(--ok)' : 'var(--text-2)'; }
    });
  }
  /* voice sliders ke live labels */
  const bindSlider = (id, label) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener('input', () => {
      const sp = el.closest('label').querySelector('span');
      if (sp) sp.textContent = label + ' ' + Number(el.value).toFixed(2);
    });
  };
  bindSlider('vRate', 'Speed');
  bindSlider('vPitch', 'Pitch');
}

/* ---------------- Zara chat ---------------- */
function renderChat() {
  const body = document.getElementById('chatBody');
  body.innerHTML = chatHTML();
  body.scrollTop = body.scrollHeight;
  const quick = document.getElementById('chatQuick');
  quick.innerHTML = QUICK_Q.map((q) => `<button class="qchip" data-act="quick" data-q="${esc(q)}">${esc(q)}</button>`).join('');
  document.getElementById('zaraStatus').textContent = state.profile.apiKey
    ? 'AI connected · Hinglish'
    : 'Offline rules · API key daalo to asli AI';
}

function openZara() {
  document.getElementById('zaraSheet').classList.remove('hidden');
  renderChat();
  if (!state.chat.length) {
    setTimeout(() => Zara.speak('Namaste! Main Zara hoon. Poocho kuch bhi.'), 250);
  }
}
function closeZara() {
  document.getElementById('zaraSheet').classList.add('hidden');
  Zara.stopSpeak();
}

function pushMsg(role, text) {
  state.chat.push({ role, text, at: new Date().toISOString() });
  if (state.chat.length > 120) state.chat = state.chat.slice(-120);
  save();
}

async function sendChat(text) {
  const t = String(text || '').trim();
  if (!t) return;
  pushMsg('user', t);
  renderChat();

  const body = document.getElementById('chatBody');
  const typing = document.createElement('div');
  typing.className = 'msg zara typing';
  typing.textContent = 'Zara soch rahi hai...';
  body.appendChild(typing);
  body.scrollTop = body.scrollHeight;

  let answer = null;
  if (state.profile.apiKey) {
    answer = await Zara.askLLM(t);
    if (!answer) {
      answer = Zara.reply(t);
      toast('API se jawab nahi aaya — offline jawab de rahi hoon');
    }
  } else {
    await new Promise((r) => setTimeout(r, 350));
    answer = Zara.reply(t);
  }

  pushMsg('zara', answer);
  renderChat();
  Zara.speak(answer);
}

/* ---------------- tests ---------------- */
function startTest() {
  const pool = QUIZ_BANK.slice();
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  ui.quiz = { list: pool.slice(0, 5), idx: 0, score: 0, answered: null };
  render();

  /* login hai to cloud se latest data lao */
  if (Cloud.auto()) {
    Cloud.pull(true).then((r) => { if (r && r.applied) { render(); toast('Cloud se data aaya'); } });
  }
}

/* ---------------- settings ---------------- */
function saveSettings() {
  const g = (id) => { const el = document.getElementById(id); return el ? el.value : null; };
  state.profile.name = (g('sName') || '').trim();
  state.profile.startDate = g('sStart') || state.profile.startDate;
  state.profile.learnStart = g('sLearn') || state.profile.learnStart;
  state.profile.hoursPerDay = Number(g('sHours')) || 3.5;
  state.profile.usdRate = Number(g('sRate')) || 88;
  state.profile.apiKey = (g('sKey') || '').trim();
  state.profile.apiBase = (g('sBase') || '').trim() || 'https://api.groq.com/openai/v1';
  state.profile.apiModel = (g('sModel') || '').trim() || 'llama-3.1-8b-instant';
  saveNow();
  render();
  toast('Settings save ho gayi');
}

function exportJSON() {
  flushInputs();
  try {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ekraasta-backup-${todayISO()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => { try { URL.revokeObjectURL(url); } catch (e) {} }, 400);
    toast('Backup download ho gaya');
  } catch (e) {
    toast('Download block hua — browser permission do');
  }
}

function importJSON(file) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const p = JSON.parse(reader.result);
      if (!p || !p.profile) throw new Error('bad');
      state = Object.assign(seedState(), p);
      state.profile = Object.assign(seedState().profile, p.profile || {});
      saveNow();
      applyTheme();
      render();
      toast('Data import ho gaya');
    } catch (e) {
      toast('File galat hai — import nahi hua');
    }
  };
  reader.readAsText(file);
}

function printReport() {
  flushInputs();
  const ws = weekStartISO(todayISO());
  const rows = [];
  for (let i = 0; i < 7; i++) {
    const d = addDays(ws, i);
    const rec = state.daily[d];
    rows.push(`<tr><td>${fmtDateFull(d)}</td><td>${blocksDone(rec)}/5</td><td>${(minsDone(rec) / 60).toFixed(1)}</td><td>${esc((rec && rec.log) || '')}</td></tr>`);
  }
  const t90 = t90Stats();
  const lr = learnStats();
  const html = `
    <h2 style="margin:0 0 4px">ekRaasta — Weekly Report</h2>
    <p style="margin:0 0 14px;font-size:12px">${fmtDateFull(ws)} se ${fmtDateFull(addDays(ws, 6))} · Day ${day90()}/90 · Learning Month ${currentMonth().m}</p>
    <table border="1" cellpadding="6" cellspacing="0" style="width:100%;border-collapse:collapse;font-size:12px">
      <tr style="background:#eee"><th>Date</th><th>Blocks</th><th>Ghante</th><th>Log</th></tr>
      ${rows.join('')}
    </table>
    <p style="font-size:12px;margin-top:14px">
      <b>Week total:</b> ${weekHours(ws)} ghante<br>
      <b>90-din track:</b> ${t90.done}/${t90.total} (${t90.pct}%)<br>
      <b>Learning:</b> ${lr.done}/${lr.total} (${lr.pct}%)<br>
      <b>Kamai (ab tak):</b> ${inr(totalEarn())} · <b>Evals:</b> ${state.evals.length} · <b>Projects shipped:</b> ${shippedCount()}
    </p>`;
  let box = document.getElementById('printArea');
  if (!box) {
    box = document.createElement('div');
    box.id = 'printArea';
    document.body.appendChild(box);
  }
  box.innerHTML = html;
  window.print();
}

function resetAll() {
  if (!confirm('Sab data delete ho jayega. Pakka?')) return;
  if (!confirm('Aakhri baar: reset kar dun?')) return;
  try { store.removeItem(STORE_KEY); } catch (e) {}
  state = seedState();
  saveNow();
  applyTheme();
  render();
  toast('Sab reset ho gaya');
}

/* ---------------- events ---------------- */
document.addEventListener('click', async (e) => {
  const closer = e.target.closest('[data-close]');
  if (closer) {
    if (closer.dataset.close === 'zara') closeZara();
    if (closer.dataset.close === 'modal') closeModal();
    return;
  }

  const tab = e.target.closest('.tab');
  if (tab) {
    if (ui.nav !== tab.dataset.nav) window.scrollTo(0, 0);
    ui.nav = tab.dataset.nav;
    ui.more = null;
    render();
    return;
  }

  const el = e.target.closest('[data-act]');
  if (!el) return;
  const a = el.dataset.act;

  switch (a) {
    /* ---- navigation ---- */
    case 'nav': {
      const target = el.dataset.nav;
      ui.nav = (target === 't90' || target === 'learn') ? 'plan' : target;
      if (target === 't90') ui.mode = '90';
      if (target === 'learn') ui.mode = 'learn';
      ui.more = null;
      render();
      window.scrollTo({ top: 0, behavior: 'instant' in document.documentElement.style ? 'instant' : 'auto' });
      break;
    }
    case 'mode':
      ui.mode = el.dataset.mode;
      if (ui.nav !== 'plan' && ui.nav !== 'home') ui.nav = 'plan';
      ui.more = null;
      render();
      if (window.scrollY > 40) window.scrollTo(0, 0);
      break;
    case 'adapted-toggle':
      ui.more = ui.more === 'adapted' ? null : 'adapted';
      render();
      break;
    case 'more':
      ui.more = el.dataset.sub || null; ui.nav = 'more'; render(); window.scrollTo(0, 0); break;
    case 'theme': toggleTheme(); render(); break;
    case 'practice-tab':
      ui.practice = el.dataset.t; ui.promptRes = null; ui.englishRes = null; render(); window.scrollTo(0, 0); break;
    case 'ptrack':
      ui.pTrack = el.dataset.t; render(); break;

    /* ---- daily blocks ---- */
    case 'toggle-block': {
      const rec = todayRec();
      rec.blocks[el.dataset.id] = !rec.blocks[el.dataset.id];
      save();
      const done = blocksDone(rec);
      if (done === DAILY_BLOCKS.length) toast('Sab ho gaya — aaj ka din count hua');
      else if (done === 4) toast('4/5 — streak bach gaya');
      render();
      break;
    }
    case 'save-log': flushInputs(); toast('Log save ho gaya'); break;

    /* ---- 90 din ---- */
    case 'open-phase':
      ui.openPhase = ui.openPhase === el.dataset.id ? null : el.dataset.id;
      render();
      break;
    case 'toggle-t90': {
      const k = el.dataset.key;
      if (state.t90.done[k]) delete state.t90.done[k];
      else state.t90.done[k] = todayISO();
      save(); render();
      break;
    }

    /* ---- learning ---- */
    case 'open-month':
      ui.openMonth = ui.openMonth === Number(el.dataset.m) ? null : Number(el.dataset.m);
      render();
      break;
    case 'toggle-learn': {
      const k = el.dataset.key;
      if (state.learn.done[k]) delete state.learn.done[k];
      else state.learn.done[k] = todayISO();
      save(); render();
      break;
    }

    /* ---- practice: prompt ---- */
    case 'check-prompt': {
      flushInputs();
      ui.promptRes = Zara.promptFeedback(draft.prompt);
      render();
      break;
    }
    case 'prompt-example': {
      const ex = PROMPT_EXAMPLES[0];
      draft.prompt = ex.good;
      ui.promptRes = null;
      render();
      toast('Achha example bhar diya — padho aur badlo');
      break;
    }
    case 'prompt-save': {
      if (!ui.promptRes) { toast('Pehle check karwao'); break; }
      state.prompts.push({ id: uid(), at: todayISO(), text: draft.prompt, score: ui.promptRes.score });
      save(); toast('Prompt practice save ho gaya');
      break;
    }
    case 'speak':
      Zara.speak(el.dataset.text || '');
      break;

    /* ---- practice: english ---- */
    case 'check-english': {
      flushInputs();
      ui.englishRes = Zara.englishFeedback(draft.english);
      render();
      break;
    }
    case 'eval-save': {
      if (!ui.englishRes) { toast('Pehle check karwao'); break; }
      state.evals.push({
        id: uid(), date: todayISO(), topic: 'English eval drill',
        text: draft.english, mistakes: '', score: ui.englishRes.score
      });
      save(); toast('Eval save ho gaya · 30 ka target yaad rakhna');
      break;
    }
    case 'load-samples': {
      draft.english = 'This response is correct but incomplete. It says Python is only used for data science. It should also mention web development and automation. The accuracy is good, but completeness is low. Suggested fix: add two more use cases with a short example. Overall score: 3/5 because one important use case is missing.';
      ui.englishRes = null;
      render();
      break;
    }

    /* ---- practice: tests ---- */
    case 'start-test': startTest(); break;
    case 'answer': {
      if (!ui.quiz || ui.quiz.answered !== null) break;
      ui.quiz.answered = Number(el.dataset.i);
      if (ui.quiz.answered === ui.quiz.list[ui.quiz.idx].a) ui.quiz.score++;
      render();
      break;
    }
    case 'next-q': {
      if (!ui.quiz) break;
      ui.quiz.idx++;
      ui.quiz.answered = null;
      if (ui.quiz.idx >= ui.quiz.list.length) {
        state.tests.push({ at: todayISO(), score: ui.quiz.score });
        save();
      }
      render();
      break;
    }
    case 'end-test': ui.quiz = null; ui.practice = 'prompt'; render(); break;

    /* ---- money ---- */
    case 'add-earn': {
      const amt = Number((document.getElementById('eAmt') || {}).value);
      if (!amt || amt <= 0) { toast('Amount daalo'); break; }
      state.earnings.push({
        id: uid(),
        date: (document.getElementById('eDate') || {}).value || todayISO(),
        platform: (document.getElementById('ePlat') || {}).value || 'Other',
        amount: amt,
        cur: (document.getElementById('eCur') || {}).value || 'INR',
        note: ((document.getElementById('eNote') || {}).value || '').trim()
      });
      save(); render(); toast('Kamai add ho gayi');
      break;
    }
    case 'del-earn':
      state.earnings = state.earnings.filter((x) => x.id !== el.dataset.id);
      save(); render();
      break;

    /* ---- ideas ---- */
    case 'add-idea': {
      const t = ((document.getElementById('ideaArea') || {}).value || '').trim();
      if (!t) { toast('Idea likho'); break; }
      state.ideas.push({ id: uid(), text: t, at: todayISO() });
      save(); render(); toast('Park ho gaya · Day 91 pe khulega');
      break;
    }
    case 'del-idea':
      state.ideas = state.ideas.filter((x) => x.id !== el.dataset.id);
      save(); render();
      break;

    /* ---- weekly ---- */
    case 'save-week': {
      const ws = weekStartISO(todayISO());
      const g = (id) => Number(((document.getElementById(id) || {}).value) || 0);
      const row = weekRow(ws);
      const entry = { week: ws, hours: row.hours, evals: row.evals, rupees: row.rupees, repos: g('wRepos'), outreach: g('wOut'), replies: g('wRep') };
      const i = state.weekly.findIndex((w) => w.week === ws);
      if (i >= 0) state.weekly[i] = entry; else state.weekly.push(entry);
      save(); render(); toast('Scorecard save ho gaya');
      break;
    }

    /* ---- settings ---- */
    case 'save-settings': saveSettings(); break;
    case 'toggle-voice':
      state.profile.voice = !state.profile.voice;
      save(); render();
      toast(state.profile.voice ? 'Zara bol degi' : 'Zara chup rahegi');
      break;
    /* ---- Zara voice ---- */
    case 'voice-test':
      saveVoiceFields();
      if (!state.profile.voiceName) {
        const b = Zara.bestVoice();
        if (b) state.profile.voiceName = b.name;
      }
      state.profile.voice = true;
      saveNow();
      Zara.speak('Namaste Aadil! Main Zara hoon. Aaj ka pehla kaam — Python functions practice. Chalo shuru karein.');
      break;
    case 'voice-save':
      saveVoiceFields(); render(); toast('Awaaz save ho gayi');
      break;
    case 'voice-refresh':
      Zara.loadVoices();
      setTimeout(() => { render(); toast('Voice list update ho gayi'); }, 400);
      break;
    case 'cloud-voice-save':
      saveVoiceFields(); render(); toast('Cloud voice save ho gayi');
      break;
    case 'cloud-voice-test':
      saveVoiceFields();
      Zara.speak('Namaste Aadil! Yeh Zara ki cloud awaaz hai. Sun kar batao — theek lagi?');
      break;

    /* ---- cloud sync ---- */
    case 'cloud-config': {
      const u = (document.getElementById('cUrl') || {}).value || '';
      const k = (document.getElementById('cKey') || {}).value || '';
      if (!/^https?:\/\//.test(u.trim())) { toast('URL https:// se shuru hona chahiye'); break; }
      state.profile.supabaseUrl = u.trim();
      state.profile.supabaseKey = k.trim();
      ui.cloudTest = null;
      saveNow(); render();
      toast('Cloud config save ho gayi — ab Test karo');
      break;
    }
    case 'cloud-test': {
      const uEl = document.getElementById('cUrl');
      const kEl = document.getElementById('cKey');
      const u = uEl ? uEl.value.trim() : state.profile.supabaseUrl;
      const k = kEl ? kEl.value.trim() : state.profile.supabaseKey;
      const prevU = state.profile.supabaseUrl;
      const prevK = state.profile.supabaseKey;
      state.profile.supabaseUrl = u;
      state.profile.supabaseKey = k;
      ui.cloudTest = { ok: true, msg: 'Check kar raha hoon...' };
      render();
      Cloud.test().then((r) => {
        if (r.ok) {
          ui.cloudTest = null;
          saveNow();
          render();
          toast('Connected! Ab email se account banao');
        } else {
          state.profile.supabaseUrl = prevU;
          state.profile.supabaseKey = prevK;
          ui.cloudTest = r;
          render();
        }
      });
      break;
    }
    case 'cloud-copy-sql': {
      const txt = Cloud.SQL || '';
      const done = () => toast('SQL copy ho gaya — Supabase SQL Editor me paste karo');
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(txt).then(done).catch(() => fallback());
      } else fallback();
      function fallback() {
        const box = document.getElementById('sqlBox');
        if (box) { box.removeAttribute('readonly'); box.select(); }
        try { document.execCommand('copy'); done(); } catch (e) { toast('Copy nahi hua — text select karke copy karo'); }
        if (box) box.setAttribute('readonly', 'readonly');
      }
      break;
    }
    case 'cloud-forget':
      state.profile.supabaseUrl = '';
      state.profile.supabaseKey = '';
      Cloud.logout();
      saveNow(); render();
      break;
    case 'cloud-signup':
    case 'cloud-login': {
      const email = ((document.getElementById('cEmail') || {}).value || '').trim();
      const pass = (document.getElementById('cPass') || {}).value || '';
      if (!email || pass.length < 6) { toast('Email aur 6+ character ka password daalo'); break; }
      const btn = el; btn.disabled = true; btn.textContent = 'Ruk jao...';
      try {
        if (a === 'cloud-signup') {
          const r = await Cloud.signup(email, pass);
          if (r.needsConfirm) toast('Account bana — email verify karke phir login karo');
          else { toast('Account ban gaya, login ho gaya'); await Cloud.pull(); }
        } else {
          await Cloud.login(email, pass);
          toast('Login ho gaya');
          await Cloud.pull();
        }
      } catch (e) {
        toast('Nahi hua: ' + (e.message || 'error'));
      }
      render();
      break;
    }
    case 'cloud-push': await Cloud.push(false); render(); break;
    case 'cloud-pull': await Cloud.pull(false); render(); break;
    case 'cloud-logout':
      Cloud.logout(); render(); toast('Logout ho gaya — data is device pe safe hai');
      break;

    /* ---- PWA install ---- */
    case 'install': promptInstall(); break;

    case 'export': exportJSON(); break;
    case 'import': {
      const f = document.getElementById('importFile');
      if (f) f.click();
      break;
    }
    case 'reset': resetAll(); break;
    case 'print': printReport(); break;

    /* ---- zara ---- */
    case 'open-zara': openZara(); break;
    case 'quick': sendChat(el.dataset.q); break;

    default: break;
  }
});

/* input/change events */
document.addEventListener('change', (e) => {
  const el = e.target.closest('[data-act]');
  if (!el) return;
  const a = el.dataset.act;

  if (a === 'proj-status') {
    const p = state.projects.find((x) => x.id === el.dataset.id);
    if (p) { p.status = el.value; save(); render(); }
  }
  if (a === 'proj-link') {
    const p = state.projects.find((x) => x.id === el.dataset.id);
    if (p) { p.link = el.value.trim(); save(); toast('Link save ho gaya'); }
  }
  if (a === 'plat-status') {
    const p = state.platforms.find((x) => x.id === el.dataset.id);
    if (p) { p.status = el.value; save(); render(); }
  }
  if (a === 'plat-due') {
    const p = state.platforms.find((x) => x.id === el.dataset.id);
    if (p) { p.due = el.value; save(); render(); }
  }
  if (a === 'import-file') { /* handled below */ }

  if (e.target.id === 'importFile' && e.target.files && e.target.files[0]) {
    importJSON(e.target.files[0]);
  }
});

document.addEventListener('input', (e) => {
  if (e.target.id === 'promptArea') draft.prompt = e.target.value;
  if (e.target.id === 'englishArea') draft.english = e.target.value;
  if (e.target.id === 'logArea') { todayRec().log = e.target.value; save(); }
});

/* chat form */
document.addEventListener('DOMContentLoaded', () => {});
window.addEventListener('DOMContentLoaded', boot);

function saveVoiceFields() {
  const g = (id) => { const el = document.getElementById(id); return el ? el.value : null; };
  if (g('vName') !== null) state.profile.voiceName = g('vName');
  if (g('vRate') !== null) state.profile.voiceRate = Number(g('vRate')) || 0.98;
  if (g('vPitch') !== null) state.profile.voicePitch = Number(g('vPitch')) || 1.08;
  if (g('tProvider') !== null) state.profile.ttsProvider = g('tProvider');
  if (g('tKey') !== null) state.profile.ttsKey = String(g('tKey')).trim();
  if (g('tVoice') !== null) state.profile.ttsVoice = String(g('tVoice')).trim();
  saveNow();
}

function promptInstall() {
  const ev = window.__installPrompt;
  if (ev) {
    ev.prompt();
    ev.userChoice.then(() => { window.__installPrompt = null; });
    return;
  }
  const ua = navigator.userAgent || '';
  if (/Android/i.test(ua)) toast('Chrome menu (⋮) → "Add to Home screen"');
  else if (/iPhone|iPad/i.test(ua)) toast('Safari → Share → "Add to Home Screen"');
  else toast('Chrome/Edge: address bar ka install icon, ya menu → "Install ekRaasta"');
}

function boot() {
  /* inject print styles */
  const st = document.createElement('style');
  st.textContent = `
    #printArea { display: none; }
    @media print {
      body > *:not(#printArea) { display: none !important; }
      #printArea { display: block !important; padding: 16px; color: #000; background: #fff; }
      body { background: #fff; padding: 0; }
    }`;
  document.head.appendChild(st);

  /* PWA install prompt capture */
  window.addEventListener('beforeinstallprompt', (ev) => {
    ev.preventDefault();
    window.__installPrompt = ev;
  });

  /* service worker (sirf http/https pe) */
  if ('serviceWorker' in navigator && location.protocol.indexOf('http') === 0) {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }

  applyTheme();
  document.getElementById('btnTheme').innerHTML = icon(state.profile.theme === 'dark' ? 'sun' : 'moon');
  document.getElementById('btnSettingsTop').innerHTML = icon('gear');
  const fab = document.getElementById('fabZara');
  if (fab) { fab.innerHTML = icon('zara'); fab.addEventListener('click', openZara); }
  document.getElementById('btnZaraVoice').innerHTML = icon('mic');
  document.getElementById('btnMic').innerHTML = icon('mic');
  if (typeof hydrateIcons === 'function') hydrateIcons();
  document.getElementById('chatForm').querySelector('.send-btn').innerHTML = icon('send');

  document.getElementById('btnTheme').addEventListener('click', () => { toggleTheme(); render(); });
  document.getElementById('btnSettingsTop').addEventListener('click', () => {
    ui.nav = 'more'; ui.more = 'settings'; render();
  });
  document.getElementById('btnZaraVoice').addEventListener('click', () => {
    const last = state.chat.filter((m) => m.role === 'zara').slice(-1)[0];
    if (last) Zara.speak(last.text);
    else toast('Pehle kuch poocho');
  });

  document.getElementById('chatForm').addEventListener('submit', (ev) => {
    ev.preventDefault();
    const inp = document.getElementById('chatText');
    const v = inp.value;
    inp.value = '';
    sendChat(v);
  });

  document.getElementById('btnMic').addEventListener('click', () => {
    Zara.listen(
      (txt) => { sendChat(txt); },
      (err) => toast(err)
    );
    toast('Bolna shuru karo...');
  });

  render();
}
```

#### `sw.js`

```js
/* ekRaasta — service worker
   App shell cache karta hai taaki offline bhi chale.
   Cloud sync internet aane pe apne aap ho jata hai. */

const CACHE = 'ekraasta-v6';
const SHELL = [
  './',
  './index.html',
  './css/app.css',
  './js/data.js',
  './js/cloud.js',
  './js/store.js',
  './js/ui.js',
  './js/zara.js',
  './js/views.js',
  './js/app.js',
  './manifest.webmanifest',
  './icons/icon-192.png',
  './icons/icon-512.png'
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()).catch(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;                    // sync POST requests network pe jayein
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;          // Supabase/Groq calls cache nahi

  e.respondWith(
    caches.match(req).then((hit) => {
      if (hit) {
        fetch(req).then((res) => { if (res && res.ok) caches.open(CACHE).then((c) => c.put(req, res)); }).catch(() => {});
        return hit;
      }
      return fetch(req).then((res) => {
        if (res && res.ok) {
          const clone = res.clone();
          caches.open(CACHE).then((c) => c.put(req, clone));
        }
        return res;
      }).catch(() => caches.match('./index.html'));
    })
  );
});
```

#### `manifest.webmanifest`

```json
{
  "name": "ekRaasta \u2014 AI Engineer ka raasta",
  "short_name": "ekRaasta",
  "description": "90-din cash plan + 12-mahine learning roadmap + Zara (padhai partner)",
  "start_url": "./index.html",
  "scope": "./",
  "display": "standalone",
  "orientation": "portrait",
  "background_color": "#08090c",
  "theme_color": "#08090c",
  "lang": "hi",
  "categories": [
    "education",
    "productivity"
  ],
  "icons": [
    {
      "src": "icons/icon-192.png",
      "sizes": "192x192",
      "type": "image/png",
      "purpose": "any"
    },
    {
      "src": "icons/icon-512.png",
      "sizes": "512x512",
      "type": "image/png",
      "purpose": "any"
    },
    {
      "src": "icons/icon-512.png",
      "sizes": "512x512",
      "type": "image/png",
      "purpose": "maskable"
    }
  ]
}
```

#### `build-single.py`

```python
#!/usr/bin/env python3
"""index.html + css + js ko ek file me jod deta hai -> ekraasta-standalone.html
Chalane ke liye: python3 build-single.py
"""
import re, pathlib

root = pathlib.Path(__file__).parent
html = (root / 'index.html').read_text(encoding='utf-8')

# inline CSS
def css_repl(m):
    href = m.group(1)
    return '<style>\n' + (root / href).read_text(encoding='utf-8') + '\n</style>'
html = re.sub(r'<link rel="stylesheet" href="([^"]+)"\s*/?>', css_repl, html)

# inline JS (order maintain)
def js_repl(m):
    src = m.group(1)
    code = (root / src).read_text(encoding='utf-8')
    return '<script>\n' + code + '\n</script>'
html = re.sub(r'<script src="([^"]+)"></script>', js_repl, html)

# standalone me PWA manifest kaam nahi karta (https chahiye) — link hata do
html = re.sub(r'<link rel="manifest"[^>]*>\s*', '', html)
html = re.sub(r'<link rel="apple-touch-icon"[^>]*>\s*', '', html)

out = root / 'ekraasta-standalone.html'
out.write_text(html, encoding='utf-8')
print('written:', out.name, len(html), 'bytes')
```

#### `desktop/main.js`

```js
/* ekRaasta — desktop wrapper (Electron)
   Website jaisa hi app, par apni window aur offline. Same data, same cloud sync. */

const { app, BrowserWindow, shell, Menu } = require('electron');
const path = require('path');

function createWindow() {
  const win = new BrowserWindow({
    width: 460,
    height: 900,
    minWidth: 360,
    minHeight: 600,
    backgroundColor: '#f2f3f5',
    title: 'ekRaasta',
    autoHideMenuBar: true,
    icon: path.join(__dirname, 'app', 'icons', 'icon-512.png'),
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  win.loadFile(path.join(__dirname, 'app', 'index.html'));

  /* bahar ke link default browser me kholo */
  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

Menu.setApplicationMenu(null);

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
```

#### `desktop/package.json`

```json
{
  "name": "ekraasta",
  "productName": "ekRaasta",
  "version": "2.0.0",
  "description": "ekRaasta — AI Engineer ka raasta (90-din cash plan + 12-mahine learning)",
  "main": "main.js",
  "author": "ekRaasta",
  "license": "MIT",
  "scripts": {
    "start": "electron .",
    "build": "electron-builder --win portable --x64"
  },
  "devDependencies": {
    "electron": "^31.0.0",
    "electron-builder": "^24.13.3"
  },
  "build": {
    "appId": "com.ekraasta.app",
    "productName": "ekRaasta",
    "files": ["main.js", "app/**/*"],
    "win": { "target": ["portable", "nsis"] },
    "nsis": { "oneClick": false, "allowToChangeInstallationDirectory": true, "shortcutName": "ekRaasta" }
  }
}
```

---

## 16. Naye AI ke liye rules (inko todna mat)

1. **Hinglish hi** — UI text, feedback, chat, sab. English sirf code identifiers me.
2. **Do track, ek app** — 90 Din aur Learning kabhi merge na karo, aur do alag app/screen bhi na banao.
   Switch ek tap ka hona chahiye (`.modeswitch`).
3. **Dark default**, accent **violet `#7c5cff`** aur **cyan `#38bdf8`**. Laal/Airtel wala look user ne reject kiya hai.
4. **Bias mat badlo** — roadmap jaan-boojh ke is user ke liye kata hua hai (Excel/Power BI hataaye, SQL/FastAPI
   jaldi, M13 buffer). Wapas add karne se pehle user se poocho.
5. **Feedback blunt** — "yeh galti aapki hai" wala tone. Politely vague feedback mat likho.
6. **Zero dependency** — koi npm/CDN/framework nahi. Sab vanilla JS + ek CSS file.
7. **Har badlav ke baad**: `node --check` har JS file pe, phir browser me khol ke test karo, phir
   `python3 build-single.py` + zip dobara banao.

## 17. Kaam karne ka tareeka (dev loop)

```bash
cd ekraasta
python3 -m http.server 8000 --bind 0.0.0.0   # http://localhost:8000
node --check js/app.js                        # har JS file pe
python3 build-single.py                       # standalone banao
cd .. && rm -f ekraasta-site.zip && cd ekraasta
zip -qr ../ekraasta-site.zip index.html manifest.webmanifest sw.js css js icons
```

Test checklist (manual ya Playwright):
- [ ] Home: block tick → hero `x/5` aur bar badle, reload pe bhi rahe
- [ ] `.modeswitch` se mode badle → hero ka rang/eyebrow badle, Plan me body badle
- [ ] Plan: phase/month khule, task tick ho, reload pe rahe
- [ ] Practice: achha prompt = 75+, "code theek karo" = <50 + blunt message
- [ ] Aur: paisa add → Home ke stat me dikhe; platforms 7; export button
- [ ] Zara: FAB → sawaal → jawab; voice test
- [ ] Dark + light dono, 390px aur 1280px

---

*Generated from the live source at `2026-10-30`. Agar code aur yeh doc me farak ho, code sach hai.*
