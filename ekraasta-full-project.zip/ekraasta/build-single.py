#!/usr/bin/env python3
"""index.html + css + js ko ek file me jod deta hai -> ekraasta-standalone.html
Chalane ke liye: python3 build-single.py
"""
import re, pathlib

root = pathlib.Path(__file__).parent
html = (root / 'index.html').read_text(encoding='utf-8')

# inline CSS
def css_repl(m):
    href = m.group(1)
    return '<style>\n' + (root / href).read_text(encoding='utf-8') + '\n</style>'
html = re.sub(r'<link rel="stylesheet" href="([^"]+)"\s*/?>', css_repl, html)

# inline JS (order maintain)
def js_repl(m):
    src = m.group(1)
    code = (root / src).read_text(encoding='utf-8')
    return '<script>\n' + code + '\n</script>'
html = re.sub(r'<script src="([^"]+)"></script>', js_repl, html)

# standalone me PWA manifest kaam nahi karta (https chahiye) — link hata do
html = re.sub(r'<link rel="manifest"[^>]*>\s*', '', html)
html = re.sub(r'<link rel="apple-touch-icon"[^>]*>\s*', '', html)

out = root / 'ekraasta-standalone.html'
out.write_text(html, encoding='utf-8')
print('written:', out.name, len(html), 'bytes')
