#!/usr/bin/env python3
# PROJECT-FULL.md banata hai: explanation + poora source code ek hi file me
import os, io, datetime

ROOT = os.path.dirname(os.path.abspath(__file__))

FILES = [
    ("index.html", "text"),
    ("css/app.css", "css"),
    ("js/data.js", "js"),
    ("js/store.js", "js"),
    ("js/ui.js", "js"),
    ("js/cloud.js", "js"),
    ("js/zara.js", "js"),
    ("js/views.js", "js"),
    ("js/app.js", "js"),
    ("sw.js", "js"),
    ("manifest.webmanifest", "json"),
    ("build-single.py", "python"),
    ("desktop/main.js", "js"),
    ("desktop/package.json", "json"),
]

def read(rel):
    p = os.path.join(ROOT, rel)
    with io.open(p, encoding="utf-8") as f:
        return f.read().rstrip() + "\n"

def code_block(rel, lang):
    code = read(rel)
    return "#### `%s`\n\n```%s\n%s```\n" % (rel, lang, code)

HEADER = open(os.path.join(ROOT, "docs", "handoff-head.md"), encoding="utf-8").read().rstrip() + "\n"

parts = [HEADER]
parts.append("\n---\n\n## 15. POORA SOURCE CODE (copy-paste ready)\n")
parts.append("""
Yeh section hi asli app hai. File ka naam heading me hai — us naam se file banao aur code paste karo.
**Load order** `index.html` me tay hota hai: `data → store → ui → cloud → zara → views → app`.

> Note: `js/cloud.js` ko `index.html` me `store.js` se **pehle** load kiya gaya hai, lekin wo `state` ko
> sirf function ke andar use karta hai, isliye order se farak nahi padta. Agar refactor karo to dhyan rakhna.
""")

for rel, lang in FILES:
    if not os.path.exists(os.path.join(ROOT, rel)):
        continue
    parts.append("\n" + code_block(rel, lang))

FOOTER = """
---

## 16. Naye AI ke liye rules (inko todna mat)

1. **Hinglish hi** — UI text, feedback, chat, sab. English sirf code identifiers me.
2. **Do track, ek app** — 90 Din aur Learning kabhi merge na karo, aur do alag app/screen bhi na banao.
   Switch ek tap ka hona chahiye (`.modeswitch`).
3. **Dark default**, accent **violet `#7c5cff`** aur **cyan `#38bdf8`**. Laal/Airtel wala look user ne reject kiya hai.
4. **Bias mat badlo** — roadmap jaan-boojh ke is user ke liye kata hua hai (Excel/Power BI hataaye, SQL/FastAPI
   jaldi, M13 buffer). Wapas add karne se pehle user se poocho.
5. **Feedback blunt** — "yeh galti aapki hai" wala tone. Politely vague feedback mat likho.
6. **Zero dependency** — koi npm/CDN/framework nahi. Sab vanilla JS + ek CSS file.
7. **Har badlav ke baad**: `node --check` har JS file pe, phir browser me khol ke test karo, phir
   `python3 build-single.py` + zip dobara banao.

## 17. Kaam karne ka tareeka (dev loop)

```bash
cd ekraasta
python3 -m http.server 8000 --bind 0.0.0.0   # http://localhost:8000
node --check js/app.js                        # har JS file pe
python3 build-single.py                       # standalone banao
cd .. && rm -f ekraasta-site.zip && cd ekraasta
zip -qr ../ekraasta-site.zip index.html manifest.webmanifest sw.js css js icons
```

Test checklist (manual ya Playwright):
- [ ] Home: block tick → hero `x/5` aur bar badle, reload pe bhi rahe
- [ ] `.modeswitch` se mode badle → hero ka rang/eyebrow badle, Plan me body badle
- [ ] Plan: phase/month khule, task tick ho, reload pe rahe
- [ ] Practice: achha prompt = 75+, "code theek karo" = <50 + blunt message
- [ ] Aur: paisa add → Home ke stat me dikhe; platforms 7; export button
- [ ] Zara: FAB → sawaal → jawab; voice test
- [ ] Dark + light dono, 390px aur 1280px

---

*Generated from the live source at `%s`. Agar code aur yeh doc me farak ho, code sach hai.*
""" % datetime.date.today().isoformat()

parts.append(FOOTER)

out = os.path.join(ROOT, "PROJECT-FULL.md")
with io.open(out, "w", encoding="utf-8") as f:
    f.write("".join(parts))
print("written:", out, os.path.getsize(out), "bytes")
