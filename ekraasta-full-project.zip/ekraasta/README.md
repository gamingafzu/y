# ekRaasta — AI Engineer ka raasta

Ek app, do track:
- **90 Din (fixed dates)** — paisa, proof, English, platforms
- **Learning (12+ months, flexible)** — tumhara roadmap, tumhare hisaab se badla hua

Plus: **Playground** (prompt lab + English drill + tests), **Zara** (Hinglish voice + chat partner), daily blocks, projects, paisa, ideas parking.

---

## v3 — naya UI (ek app, instant switch)

Purana clutter hata diya. Ab:

- **Upar segmented switch** — `90 Din` ⇄ `Learning`. Ek tap, wahi screen, neeche ka roadmap turant badal jata hai. Navigate nahi karna padta.
- **Home** — hero card (mode ke hisaab se laal ya indigo) + aaj ke 5 block + "agla kaam" + log. Dono track ke block ek saath, tag se pata chalta hai kaunsa kis track ka hai.
- **Plan** — yahi switch, poora roadmap. 90 din = 4 phase, task ke saath "Kaise karna hai". Learning = 13 month, week-wise + project + resources (Hindi-first) + "Tumhare hisaab se kya badla" card.
- **Practice** — Prompt Lab / English / Tests.
- **Aur** — projects, paisa, platforms, ideas, weekly, settings.
- **Tabbar 4 tab** (Ghar / Plan / Practice / Aur) + laal FAB = Zara chat.
- **PC pe** nav floating pill ban jata hai, content 780px column me.
- Dark theme, mobile-first, PWA install, print, offline.

Rebuild: `python3 build-single.py` → `ekraasta-standalone.html`
Deploy zip: `index.html manifest.webmanifest sw.js css/ js/ icons/` → `ekraasta-site.zip`

---

## 1. Kaise chalaun

**Sabse aasan:** `ekraasta-standalone.html` — double click karo, browser me khul jayega. Kuch install nahi, internet ki bhi zarurat nahi (offline chalta hai).

**Developer version (edit karne ke liye):**
```
ekraasta/
  index.html
  css/app.css
  js/data.js     <- saara content (90 din, 12 mahine, quiz)
  js/store.js    <- data layer + localStorage + date helpers
  js/ui.js       <- icons, theme, toast, modal
  js/zara.js     <- Zara ka dimag (prompt checker, english checker, chat, voice)
  js/views.js    <- saare screens ka HTML
  js/app.js      <- router + events
  manifest.webmanifest, sw.js, icons/  <- PWA install + offline
  desktop/       <- Electron (.exe banane ke liye)
  BUILD-EXE-APK.md
  build-single.py
```
Local server se kholna ho:
```
cd ekraasta
python3 -m http.server 8000
# browser: http://localhost:8000
```
CSS/JS badalne ke baad single file dobara banao:
```
python3 build-single.py
```

---

## 2. Free hosting (phone pe bhi khule)

GitHub Pages:
1. Naya repo banao (public), `ekraasta-standalone.html` ko `index.html` naam se upload karo
2. Settings → Pages → Branch: `main`, folder: `/root` → Save
3. 1-2 minute me link mil jayega: `https://<username>.github.io/<repo>/`
4. Wahi link phone me kholo, "Add to Home Screen" karo — app jaisa lag jayega

Data **usi device** me rehta hai (localStorage). Phone aur laptop alag data hain — jo abhi theek hai. Sync chahiye to next version me Supabase.

---

## 3. Zara (voice + chat)

**Bina kuch kiye:** Zara rules se chalti hai — prompt check, English check, plan yaad dilana, test lena. Sab offline.

**Asli AI jawab chahiye (free):**
1. [console.groq.com](https://console.groq.com) pe free account → API key banao
2. App → More → Settings → "Zara ka asli dimag" → key paste karo → Save
3. Base URL: `https://api.groq.com/openai/v1`, Model: `llama-3.1-8b-instant`

OpenRouter bhi chalega (`https://openrouter.ai/api/v1` + model name jaise `meta-llama/llama-3.1-8b-instruct:free`).

**Voice:**
- 🔊 "Suno" button / Zara ke jawab — bol ke sunati hai (browser ka speech)
- 🎤 Mic button — tum bolo, woh samajhti hai
- Hindi voice Chrome me best chalti hai; Safari/iOS me limited. Mic ke liye permission dena padega.
- Voice off karne ke liye Settings → "Zara ki awaaz"

**Privacy:** API key sirf tumhare browser ke localStorage me hai. Kisi ko mat bhejo, screenshot me mat dikhao.

---

## 3. Cloud sync + login (phone aur PC ek data)

**Bina login:** data sirf device pe. **Login ke saath:** ek account = dono device pe same data.

### Setup (ek baar, free, 3 minute)
1. [supabase.com](https://supabase.com) → free account → **New project** (region: Mumbai/Singapore)
2. **Settings → API** → copy karo: **Project URL** aur **anon public** key
3. **SQL Editor** → yeh chalao:

```sql
create table if not exists public.user_state (
  user_id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null,
  updated_at timestamptz not null default now()
);
alter table public.user_state enable row level security;

create policy "own select" on public.user_state for select using (auth.uid() = user_id);
create policy "own insert" on public.user_state for insert with check (auth.uid() = user_id);
create policy "own update" on public.user_state for update using (auth.uid() = user_id);
```

4. **Authentication → Providers → Email** → **"Confirm email" OFF** (warna signup ke baad email verify karna padega)
5. App → **More → Settings → Cloud sync** → URL + anon key paste → Save
6. **Naya account** banao (email + 6+ char password) → login

### Ab kya hota hai
- Har change **3 sec baad** cloud pe chala jata hai (silent)
- App kholte hi cloud se latest data aata hai (agar remote naya ho)
- **Push karo / Pull karo** buttons manual control ke liye
- Ek device pe login, dusre pe bhi same email → **same data**
- **Har user ka data alag** — Row Level Security se dusra user tumhara data nahi padh sakta

### Kya cloud pe NAHI jaata
- **Groq/OpenRouter API key** — sirf device pe rehti hai (security)
- **Supabase key** — device pe hi

### Yaad rakhna
- Password bhool gaye → Supabase dashboard → Authentication → user → reset
- Login ke bina app pura chalta hai (offline). Login optional hai
- Export JSON phir bhi karo — cloud free tier ho ya na ho, local backup sabse safe

---

## 4. Install — phone + PC (ek hi app)

Sandbox se signed `.exe`/`.apk` dena possible nahi, isliye **PWA install** (jo same kaam karta hai) + build scripts diye hain. Poora detail: **`BUILD-EXE-APK.md`**

**Sabse short rasta:**
1. `app.netlify.com/drop` pe poora `ekraasta` folder drag karo (ya GitHub Pages)
2. Live https link mil jaye
3. **Android:** Chrome → ⋮ → "Install app" · **Windows:** Chrome/Edge → address bar install icon · **iPhone:** Share → Add to Home Screen
4. Ab icon se khulega, browser bar nahi, offline chalega, auto-update

**Asli .exe chahiye:** `cd desktop && npm install && npm run build` → `dist/ekRaasta 2.0.0.exe` (portable)
**Asli .apk chahiye:** [pwabuilder.com](https://pwabuilder.com) pe apna hosted URL daalo → Android → APK download

---

## 5. Kya kahan hai

| Tab | Kya |
|---|---|
| **Home** | Day X/90, streak, hafte ke ghante, aaj ke 5 block, learning month, agla 90-din ka kaam, log, paisa |
| **90 Din** | Char phase (Foundation → Pehla Paisa → Coding Track → Repeat), har kaam ke saath "Kaise karna hai" steps |
| **Learning** | 13 months (12 + buffer), har month ke 4 week, project, YouTube resources, aur "roadmap se kya badla" note |
| **Practice** | Prompt Lab (Zara 100 me score + kya add karna hai), English eval drill (grammar + template usage check), Tests (5 sawaal, explanation) |
| **More** | Projects, Paisa, Platforms, Ideas parking, Weekly scorecard, Settings |

---

## 6. Roadmap me kya badla (tumhare 12-month PDF se)

| Original | Ab | Kyun |
|---|---|---|
| Month 1: Python + Excel dashboard | Python full, **Excel skip** | AI engineer ko Excel ka basic kaafi |
| Month 3: EDA 4 hafte | **3 hafte** (chautha hafta SQL) | Data analyst track nahi chahiye |
| Month 4: SQL + Power BI | **SQL + FastAPI (early start)** | Power BI/Tableau skip — deploy aana = paisa |
| Month 7: DL 4 hafte | **3 hafte** (CNN project, RNN halka) | Time bachta hai |
| Month 12 | + **Month 13 buffer** | 13 mahine lage to guilt nahi |
| — | + **90-din cash track** parallel | PDF me paisa nahi tha; woh alag se chalta rahega |
| Civil engineer ka context, resume/LinkedIn samples | **Nahi use kiye** | Woh 10 saal experience wale ke hain; tumhara resume projects se banega |

---

## 7. Roz kitna time

| Block | Time |
|---|---|
| Learning — video + code | 50 min |
| Learning — project | 50 min |
| Paisa — Karya / platform / apply | 40 min |
| English drill | 20 min |
| Log | 5 min |
| **Core total** | **2 h 45 min** |
| + buffer (project/break) | ~45 min |
| **Roz ka target** | **~3.5 ghante** (hafte me ~24) |

90-din akela 3 ghante maangta hai, Learning akela 2 ghante — par overlap ki wajah se **3+2 = 5 nahi, 3.5** banta hai. Learning ka monthly project hi 90-din ka proof banta hai. Ek kaam, do jagah count.

---

## 8. Data backup (zaroori)

- Settings → **Export JSON** — file download hogi
- Browser data clear kiya / naya phone liya → **Import JSON** se sab wapas
- Har hafte Sunday ko export karo. 10 second ka kaam, poora data bach jata hai
- localStorage band ho (private mode) to app memory me chalega — band karne pe data chala jayega. Normal window use karo

---

## 9. Abhi kya nahi hai

- **Login / multi-device sync** — filhaal single device, no auth (jaan-boojh ke, simplicity ke liye)
- Push notifications / reminder
- Streak ko calendar view
- Prompt Lab me "asli LLM se prompt improve karwao" (abhi rule-based check hai)

---

## 10. Test status

Chromium (390×844 mobile + desktop width) pe test kiya:
- ✅ Render, theme toggle (light/dark, reload ke baad bhi yaad), sab tabs
- ✅ 5 daily block, 90-din task toggle, learning week toggle — sab persist
- ✅ Prompt check (score + feedback), English check (grammar + template check), test flow
- ✅ Paisa add/delete (USD→INR), platforms, ideas park + Day 91 lock
- ✅ Weekly scorecard, print/PDF report, export JSON
- ✅ Zara chat (offline replies), sheet open/close, voice hooks
- ✅ Cloud: config → signup → auto push → reload ke baad login bacha → pull → logout (mock Supabase pe test)
- ✅ PWA: manifest 200, service worker registered, offline cache bana
- ✅ Zero console errors, offline (file://) pe bhi chalta hai
