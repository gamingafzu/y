# EXE / APK / Install — kaise karein

Sandbox se **signed .exe ya .apk banake dena possible nahi** (Windows/Android build toolchain yahan nahi hai).
Isliye do raste hain — **dono se same app milta hai, same data, ek hi codebase**:

| Rasta | Kaam me | Result |
|---|---|---|
| **A. PWA install** (recommend) | abhi, 2 minute | Android + Windows dono pe app icon, browser bar nahi, offline chalta hai, **auto-update** |
| **B. Electron .exe** | 15-20 min, apne PC pe | Asli `ekRaasta.exe` (portable) — double click, program ki tarah khulega |

---

## A. PWA install (phone + PC, ek hi app)

**Pehle app ko internet pe daalo** (ek baar, free):

### GitHub Pages se (aasan)
1. GitHub pe naya **public** repo banao, naam jaise `ekraasta`
2. Andar yeh files upload karo (folder structure hoga to aur achha):
   ```
   index.html
   manifest.webmanifest
   sw.js
   css/app.css
   js/data.js, cloud.js, store.js, ui.js, zara.js, views.js, app.js
   icons/icon-192.png, icon-512.png
   ```
3. Repo → **Settings → Pages → Source: Deploy from branch → main → / (root)** → Save
4. 1-2 minute baad link: `https://<username>.github.io/ekraasta/`

### Netlify drag-and-drop se (sabse fast)
1. [app.netlify.com/drop](https://app.netlify.com/drop) kholo
2. poora `ekraasta` folder drag karo
3. turant live URL mil jayega (`https://random-name.netlify.app`) — free, account optional

### Ab install karo
- **Android (Chrome):** link kholo → ⋮ menu → **"Install app" / "Add to Home screen"** → icon ban jayega
- **Windows (Chrome/Edge):** link kholo → address bar ke right me **install icon** dabao, ya menu → **"Install ekRaasta"** → Start menu me aa jayega
- **iPhone (Safari):** Share → **"Add to Home Screen"**

> PWA ke liye **https zaroori** hai — isliye pehle host karna padega. Isi wajah se `ekraasta-standalone.html` (double-click version) me install ka option nahi hai.

---

## B. Asli `.exe` (Electron) — apne PC pe banao

Zarurat: Node.js 18+ ([nodejs.org](https://nodejs.org))

```bash
# 1. ekraasta folder ke andar
cd ekraasta/desktop

# 2. app ki copy banao (desktop/app me web app chahiye)
mkdir -p app
cp -r ../index.html ../manifest.webmanifest ../sw.js ../css ../js ../icons app/

# 3. install + build
npm install
npm run build
```

Ban jayega: `desktop/dist/ekRaasta 2.0.0.exe` (portable) — kisi bhi Windows PC pe copy karo, double-click, chal jayega.
Installer version bhi milega (`ekRaasta Setup 2.0.0.exe`) Start-menu shortcut ke saath.

Test karne ke liye (build ke bina):
```bash
npm start
```

> `.exe` banate waqt Windows SmartScreen warning de sakta hai (unsigned build). "More info → Run anyway" — apne bane app ke liye normal hai.

---

## C. Asli `.apk` (Android) — chahiye to

Sabse aasan rasta **PWABuilder** (free, code nahi likhna):
1. [pwabuilder.com](https://www.pwabuilder.com) kholo
2. apna hosted URL daalo (`https://<username>.github.io/ekraasta/`)
3. **Android → Generate** → `.apk` / `.aab` download
4. APK phone me install karo (Settings → "Install unknown apps" allow karna padega)

Ya Bubblewrap se apne PC pe:
```bash
npm i -g @bubblewrap/cli
bubblewrap init --manifest https://<username>.github.io/ekraasta/manifest.webmanifest
bubblewrap build
```

> Play Store pe daalne ke liye Google ka developer account (one-time $25) + `.aab` chahiye. Personal use ke liye APK kaafi hai.

---

## D. Dono pe ek hi data — kaise

PWA / EXE / APK — sab **same app** hai, par data **device pe** rehta hai (localStorage).
Dono jagah ek data chahiye to **Settings → Cloud sync** me Supabase setup karo (README section 3), phir **same email-password se dono device pe login** karo.

- Ek device pe change → 3 sec baad cloud pe
- Dusre device pe app kholo → cloud se latest khud aa jata hai
- Ek user ka data dusre user ko kabhi nahi dikhega (Row Level Security)

Bina login: dono device independent rahenge. Backup ke liye Settings → **Export JSON** / **Import JSON**.
