/* ekRaasta — service worker
   App shell cache karta hai taaki offline bhi chale.
   Cloud sync internet aane pe apne aap ho jata hai. */

const CACHE = 'ekraasta-v6';
const SHELL = [
  './',
  './index.html',
  './css/app.css',
  './js/data.js',
  './js/cloud.js',
  './js/store.js',
  './js/ui.js',
  './js/zara.js',
  './js/views.js',
  './js/app.js',
  './manifest.webmanifest',
  './icons/icon-192.png',
  './icons/icon-512.png'
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()).catch(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;                    // sync POST requests network pe jayein
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;          // Supabase/Groq calls cache nahi

  e.respondWith(
    caches.match(req).then((hit) => {
      if (hit) {
        fetch(req).then((res) => { if (res && res.ok) caches.open(CACHE).then((c) => c.put(req, res)); }).catch(() => {});
        return hit;
      }
      return fetch(req).then((res) => {
        if (res && res.ok) {
          const clone = res.clone();
          caches.open(CACHE).then((c) => c.put(req, clone));
        }
        return res;
      }).catch(() => caches.match('./index.html'));
    })
  );
});
