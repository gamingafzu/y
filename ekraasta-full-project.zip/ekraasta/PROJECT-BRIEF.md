# ekRaasta — PROJECT FULL (code + poora context)

> **Yeh file kya hai:** ek single-file handoff. Isse kisi bhi AI tool (ChatGPT / Claude / Gemini / Cursor)
> ko de sakte ho — usme app ka poora context, rules, architecture aur **line-by-line source code** hai.
> Neeche section 16 me saara code hai; upar ke sections bataate hain ki cheezein *kyun* aisi hain.
>
> **Version:** v4.1 (dark UI + violet/cyan palette) · **Files:** 9 source + 3 support · **Dependencies:** zero
> **Last updated:** 2026-10-31

---

## 1. Ek line me app

**ekRaasta** = ek personal progress app jisme do roadmap ek saath rehte hain — **90-din ka paisa plan**
(fixed dates) aur **12–13 mahine ka AI-engineer learning track** (flexible) — aur upar ek switch se
turant badal jaate hain. Plus daily blocks, prompt/English practice, Zara (Hinglish voice + chat),
projects, kamai tracker, platforms, cloud sync.

Ye ek **single-user, offline-first PWA** hai. Koi backend nahi (cloud optional hai), koi login zaroori nahi.

---

## 2. User kaun hai (context — isse design decisions samajh aayenge)

- **Aadil**, 19 saal, Godhra (Gujarat). 11th pass, CSE diploma beech me chhoda.
- Python basic (number-guessing game, unit converter), AI tools thode use kiye hain.
- **English likhne me kamzor** — isliye har cheez Hinglish me hai.
- **Paisa jaldi chahiye** — isliye 90-din track pehle aata hai aur Karya (Hindi/Gujarati tasks) sabse pehle.
- Degree nahi hai — isliye roadmap "degree" pe nahi, "proof of work" (GitHub + demos) pe khada hai.
- Track A chuna hai: **AI training / evaluation platforms** (Karya → Outlier → Stellar → Mindrift → Mercor →
  DataAnnotation → Alignerr). Tuition/shop/Fiverr wale tracks **user ne reject kiye** hain.

**Roz ka time:** ~**3.5 ghante** (core 2h45 = 165 min + buffer). Yeh `TOTAL_MINS` aur `DAILY_BLOCKS` me fixed hai.

---

## 3. Non-negotiable product rules

| # | Rule | Kyun |
|---|---|---|
| 1 | Sab kuch **Hinglish (Roman)** | User ki English weak hai |
| 2 | **Ek app, do roadmap, ek-tap switch** | User ne do alag app/screen reject kiye |
| 3 | 90-din track **date-based** (fixed), Learning **flexible** | Paisa deadline pe, seekhna pace pe |
| 4 | **Dark default** — violet `#7c5cff` + cyan `#38bdf8` | User ka final palette (obsidian/crimson try reject hua) |
| 5 | Roadmap ka **personalization** (Excel/Power BI hataya) | 11th pass + paisa jaldi chahiye |
| 6 | Feedback **blunt**, sugar-coated nahi | "Yeh galti aapki hai" tone |
| 7 | **Zero dependency**, vanilla JS + 1 CSS | file:// pe chale, offline, PC+phone dono |
| 8 | Mobile-first, PC pe bhi theek | 390px aur 1280px dono test hote hain |

---

## 4. Tech stack

- **HTML** — ek `index.html`, static shell (appbar, tabbar, FAB, chat sheet, modal, toast).
- **CSS** — ek `css/app.css`, CSS variables se light/dark theme. Koi framework/preprocessor nahi.
- **JS** — 7 plain script files, global scope, koi bundler nahi. Sab `index.html` me `<script>` se load.
- **Storage** — `localStorage` (key `ekraasta_v2`), memory fallback agar storage band ho.
- **Optional cloud** — Supabase REST (fetch), SDK nahi.
- **PWA** — `manifest.webmanifest` + `sw.js` (cache-first, cache name `ekraasta-v4`).
- **Standalone build** — `build-single.py` sab inline karke ek HTML banata hai (offline double-click).

---

## 5. Files aur load order

```
ekraasta/
├── index.html               # shell: appbar, screen, tabbar, FAB, chat sheet, modal, toast
├── css/app.css              # poora design system (tokens + components + print + media queries)
├── js/data.js               # SAARA content: daily blocks, PLAN_90, LEARN_MONTHS, prompt/english/quiz
├── js/store.js              # state, localStorage, date helpers, stats
├── js/ui.js                 # icons, esc, toast, theme, modal, ring/progress, hydrateIcons
├── js/cloud.js              # Supabase auth + push/pull + test + SQL constant
├── js/zara.js               # dimag: prompt scorer, english eval, chat router, LLM, TTS/STT
├── js/views.js              # har screen ka HTML + `ui` (view state) + `draft`
├── js/app.js                # boot, render loop, event delegation (saare `data-act`)
├── sw.js                    # service worker
├── manifest.webmanifest     # PWA metadata (theme #08090c)
├── build-single.py          # inline sab kuch → ekraasta-standalone.html
├── desktop/                 # Electron wrapper (.exe build ke liye, optional)
└── icons/icon-192.png, icon-512.png
```

**Load order `index.html` me:** `data → cloud → store → ui → zara → views → app`

> `cloud.js` `store.js` se pehle load hota hai, par `state` ko sirf functions ke andar chhoota hai
> (call time pe milta hai). Refactor karte waqt dhyan rakhna.

---

## 6. Runtime architecture

### 6.1 Boot

```
DOM ready → boot() (app.js)
  ├─ print styles inject
  ├─ beforeinstallprompt capture (PWA install button)
  ├─ service worker register (sirf http/https pe, file:// pe nahi)
  ├─ applyTheme()  ← state.profile.theme ('dark' default)
  ├─ icons inject (theme, gear, FAB, mic, send) + hydrateIcons()
  ├─ bind: click delegation (document pe ek hi listener), chat form, mic
  └─ render()
```

### 6.2 Render loop (poore app ka dil)

App me koi framework nahi. Pattern hai: **state → HTML string → innerHTML**.

```js
function render() {
  flushInputs();                                   // textarea/input ki value state me le lo
  const html = (SCREENS[ui.nav] || vHome)();       // screen ka HTML string
  document.getElementById('screen').innerHTML = html;
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('on', t.dataset.nav === ui.nav));
  document.getElementById('logoSub').textContent = ...;   // appbar ka subtitle
  // live bindings: english word count, voice sliders
}
```

- `SCREENS = { home: vHome, plan: vPlan, practice: vPractice, more: vMore }`
- `ui` = **view state** (kahan ho, kaunsa mode, kaunsa accordion khula) — localStorage me **nahi** jaata.
- `state` = **data** — localStorage me jaata hai, cloud pe jaata hai.
- Har interaction: state ya `ui` badlo → `render()`.

**Scroll rule:** tab change pe `scrollTo(0,0)`; task tick pe nahi (jhatka na lage).
Chhote actions (checkbox) pe bhi poora screen re-render hota hai — isliye scroll position manually manage hota hai.

### 6.3 Event delegation

Ek hi listener: `document.addEventListener('click', handler)`. Har button pe `data-act="..."` hota hai,
handler `switch` me case chalata hai. Extra data `data-*` me aata hai.

| `data-act` | Kaam |
|---|---|
| `nav` | tab/screen badlo (`data-nav`), `t90`/`learn` → plan + mode |
| `mode` | roadmap switch (`data-mode="90" \| "learn"`) |
| `toggle-block` | aaj ka daily block tick (`data-id`) |
| `save-log` | aaj ka log save |
| `open-phase` / `open-month` | accordion kholo/band |
| `toggle-t90` / `toggle-learn` | task/week/project tick (`data-key`) |
| `practice-tab` | Prompt Lab / English / Tests |
| `check-prompt`, `prompt-example`, `prompt-save` | prompt lab |
| `check-english`, `eval-save`, `load-samples` | english drill |
| `start-test`, `answer`, `next-q`, `end-test` | quiz |
| `add-earn`, `del-earn`, `add-idea`, `del-idea`, `save-week` | money / ideas / weekly |
| `more` | Aur ke sub-screen (`data-sub`) |
| `theme` | dark/light |
| `voice-*`, `cloud-voice-*` | TTS voice settings |
| `cloud-config`, `cloud-test`, `cloud-copy-sql`, `cloud-signup`, `cloud-login`, `cloud-push`, `cloud-pull`, `cloud-logout`, `cloud-forget` | cloud sync |
| `install`, `export`, `import`, `reset`, `print` | PWA + data |
| `open-zara`, `quick`, `speak`, `voice-test` | Zara |

### 6.4 `ui` object (view state)

```js
const ui = {
  nav: 'home',        // home | plan | practice | more
  mode: '90',         // 90 | learn   ← roadmap switch ka dil
  more: null,         // projects | money | platforms | ideas | weekly | settings | adapted
  practice: 'prompt', // prompt | english | tests
  openPhase: 'p1',    // kaunsa 90-din phase khula hai
  openMonth: null,    // kaunsa learning month khula hai (null = current month)
  promptRes: null,    // prompt check ka result
  englishRes: null,
  quiz: null,
  cloudTest: null
};
const draft = { prompt: '', english: '' };   // jo type ho raha hai
```

---

## 7. State schema (`js/store.js`)

`localStorage["ekraasta_v2"]` me poora JSON. Load pe `seedState()` ke saath shallow-merge hota hai,
isliye naye field add karne se purana data nahi tootta.

```js
{
  v: 2,
  profile: {
    name: 'Aadil',
    startDate: '2026-10-31',    // 90-din ka Day 1
    learnStart: '2026-10-31',   // learning track ka start
    theme: 'dark',              // dark | light
    uiV: 4,                     // migration flag (purane user ko ek baar dark pe laata hai)
    hoursPerDay: 3.5,
    usdRate: 88,
    apiKey: '',                 // Groq/OpenAI key — CLOUD PE NAHI JAATI
    apiBase: 'https://api.groq.com/openai/v1',
    apiModel: 'llama-3.1-8b-instant',
    voice: true,                // Zara bole ya chup rahe
    voiceName: '', voiceRate: 0.98, voicePitch: 1.08,
    ttsProvider: 'device',      // device | cloud
    ttsKey: '', ttsVoice: '',
    supabaseUrl: '', supabaseKey: ''   // CLOUD PE NAHI JAATE
  },
  daily: { 'YYYY-MM-DD': { blocks: { learn: true, ... }, log: '...' } },
  t90:   { done: { 'p1-0': 'YYYY-MM-DD', ... } },      // 90-din tasks
  learn: { done: { 'm1-w1': '...', 'm1-proj': '...' }, open: 1 },
  projects: [ { id, name, status: 'done'|'wip'|'todo', tags: [], link } ],  // 9 seeded, 2 done
  evals: [], prompts: [], tests: [],
  earnings: [ { id, date, platform, amount, cur, note } ],
  platforms: [ { id, name, status, rate, next, due, notes } ],              // 7 seeded
  ideas: [], weekly: [ { week, hours, ... } ],
  chat: [ { role: 'user'|'zara', text, at } ],
  updatedAt: 0                // epoch ms — cloud me last-write-wins ke liye
}
```

**Helpers (`store.js`):**

| Function | Return |
|---|---|
| `todayISO()`, `isoOf(d)`, `addDays(iso, n)`, `daysBetween(a,b)`, `weekStartISO(iso)` | date utils |
| `fmtDate`, `fmtDateFull` | Hinglish-friendly display |
| `save()`, `saveNow()` | debounce 60ms / turant; save pe cloud auto-push 3s |
| `day90()` | start date se aaj tak ka din number (1-based) |
| `todayRec()` | aaj ka `{ blocks:{}, log:'' }` record |
| `blocksDone(rec)`, `minsDone(rec)` | aaj ka progress |
| `streak()` | lagataar din jisme ≥4 block done (aaj complete na ho to kal se ginti) |
| `t90Stats()`, `phaseStats(ph)` | `{done,total,pct}` |
| `learnStats()`, `monthStats(mo)` | weeks + project ko count karte hain |
| `inr(n)`, `toINR(amount, cur)`, `monthEarn()`, `totalEarn()` | paisa |
| `shippedCount()`, `weekHours(weekStart)`, `weekRow()` | stats |

---

## 8. Content data model (`js/data.js`)

| Constant | Shape | Kaam |
|---|---|---|
| `DAILY_BLOCKS` | `[{ id, track:'90'\|'learn'\|'both', title, mins, hint }]` | roz ke 5 block (50+50+40+20+5) |
| `TOTAL_MINS` | `165` | din ka target |
| `PLAN_90` | `[{ id:'p1', name, range:'Day 1-30', goal, tasks:[{ t, how:[], why }] }]` | 4 phase × ~5-6 task |
| `LEARN_MONTHS` | `[{ m:1, title, focus, weeks:[{w:1,d:'...'}], project:{t,steps:[]}, res:[{l,u}], note }]` | 13 mahine |
| `PROMPT_PARTS` | `[{ name:'Role', ex:'...' }]` | prompt ke 5 part |
| `PROMPT_EXAMPLES` | `[{ good:'...', bad:'...' }]` | example button |
| `ENGLISH_TEMPLATES` | `[{ g:'Feedback', items:[] }]` | 15+ fixed eval sentences |
| `QUIZ_BANK` | `[{ q, opts:[], a:index, why }]` | 15 sawaal |

**Content likhne ke rules:** sab Hinglish, chhote vaakya, har task me "kaise karna hai" practical (tool ka naam,
kahan click), aur jahan ho sake resource **Hindi-first** (CodeWithHarry, CampusX, Krish Naik).

---

## 9. Zara — dimag aur awaaz (`js/zara.js`)

### 9.1 Prompt scorer (`promptFeedback`)

Base 20, phir 5 part pe +15 each, example +5, minus: vague words −8, 3+ sawaal −8, 120 char se chhota −5.
`< 30` char pe seedha 0.

| Part | Detect (regex, Hinglish+English) |
|---|---|
| Role | `tum ek`, `aap ek`, `senior`, `expert`, `you are`, `act as` |
| Task | `likho`, `banao`, `dhundo`, `samjhao`, `fix`, `summar`, `review`... |
| Context | `main `, `mera`, `beginner`, `11th pass`, `student`... |
| Format | `table`, `json`, `bullet`, `list`, `step by step`, `words`... |
| Constraint | `sirf`, `only`, `max`, `do not`, `exactly`, `nahi chahiye`... |

Output: `{ score, items:[{type:'good'|'meh'|'bad', text}], next }`.
Score < 50 pe UI me **"Yeh galti tumhari hai — prompt adhoora hai"** dikhta hai. Yeh jaan-boojh ke blunt hai.

### 9.2 English eval (`englishFeedback`)

Patterns dhoondhta hai: 120+ words (+25), eval templates (+25), capital start (+15), `I` capital (+10),
a/an sahi (+8), punctuation (+7); minus: Hindi words −10, filler, chhota text.
Yeh **assessment-style feedback** ki practice karata hai (Outlier/DataAnnotation ka core skill).

### 9.3 Chat router (`reply`)

Keyword-based offline brain: `aaj kya karna`, `kitne ghante`, `prompt`, `english`, `eval`, `rag`, `paisa`,
`karya`, `outlier|dataannotation`, `test`, `roadmap`, `atka/lost`, `platform`, `resume`...
Har jawab me Hinglish + next step. Agar `state.profile.apiKey` set hai to `askLLM()` asli AI (Groq/OpenAI
compatible) se jawab leta hai — warna offline rule-based.

### 9.4 Awaaz (TTS) + sunna (STT)

- `loadVoices()` → `allVoices()` → `scoreVoice()` (Hindi `hi-IN` + female names ko priority: Swara, Kalpana,
  Heera, Google हिन्दी...) → `bestVoice()`; user ka chunav `chosenVoice()` me pehle aata hai.
- `deviceSpeak()` — `speechSynthesis`; `u.voice` assignment **try/catch** me (kuch browsers throw karte hain),
  fallback `u.lang='hi-IN'`.
- `cloudSpeak()` — provider `sarvam` / `elevenlabs` / `google` ke liye REST call (key user daalta hai).
- `testVoice()`, `ttsStatus()` — settings UI ko status deta hai.
- `listen()` — `webkitSpeechRecognition`, `hi-IN`.

**User ki requirement:** asli ladki jaisi Hindi/Hinglish awaaz — default robotic browser voice reject ki gayi thi.
Best free option jo test me chala: **Microsoft Swara Online (Natural) - Hindi** (Edge/Chrome Windows).

---

## 10. Cloud sync (`js/cloud.js`)

Supabase REST, **SDK nahi**. Session `localStorage["ekraasta_cloud_session"]` me.

| Function | Kaam |
|---|---|
| `cfg()` / `ready()` | `profile.supabaseUrl + supabaseKey` set hai? |
| `signup(email, pass)` / `login(...)` | `/auth/v1/signup`, `/auth/v1/token?grant_type=password` |
| `refreshSession()` / `ensureToken()` | token expire hone pe refresh |
| `push(silent)` | upsert `/rest/v1/user_state` with `Prefer: resolution=merge-duplicates` |
| `pull(silent)` | `select=data,updated_at`; remote naya ho to `applyRemote()` |
| `pushSoon()` | `save()` se bula ke 3 sec debounce me push |
| `test()` | table/URL/key verify — 404 = "table nahi hai", 401/403 = "key galat" |
| `SQL` | ready SQL string (app me copy button se copy hota hai) |

**Merge rule:** `updated_at` compare (1.5s tolerance). Remote naya → apply. Warna local push.
**Secrets:** `apiKey`, `supabaseUrl`, `supabaseKey`, `theme` **cloud se apply nahi hote** (device ke rehte hain).

**SQL (app ke andar `Cloud.SQL`):** table `public.user_state(user_id uuid pk → auth.users, data jsonb,
updated_at timestamptz)` + RLS on + select/insert/update policies `auth.uid() = user_id`.

---

## 11. PWA, build, deploy

- **PWA:** `manifest.webmanifest` (theme `#08090c`, violet icons), `sw.js` cache-first, cache `ekraasta-v6`.
  Install button Settings me hai (`beforeinstallprompt` capture).
- **Standalone:** `python3 build-single.py` → `ekraasta-standalone.html` (~180 KB) — sab inline, file:// pe chalta hai.
- **Deploy:** `index.html manifest.webmanifest sw.js css/ js/ icons/` ko zip karke Netlify pe drag.
  Live: `https://dynamic-florentine-124b28.netlify.app`
- **Desktop:** `desktop/` me Electron wrapper (signed .exe yahan se nahi ban sakta, `BUILD-EXE-APK.md` dekho).

---

## 12. Design system (`css/app.css`)

### Tokens (dark default)

| Token | Dark | Light |
|---|---|---|
| `--bg` | `#08090c` | `#f5f6fa` |
| `--surface` | `#101216` | `#ffffff` |
| `--surface-2/3` | `#151821` / `#1b1f28` | `#f7f8fb` / `#eef0f5` |
| `--line` | `#232733` | `#e4e7ee` |
| `--text / -2 / -3` | `#edf0f6` / `#98a0b0` / `#68707f` | `#0f1419` / `#596274` / `#8b93a3` |
| `--accent` (90-din) | `#7c5cff` violet | `#6d4aff` |
| `--learn` (learning) | `#38bdf8` cyan | `#0284c7` |
| `--ok` / `--warn` | `#34d399` / `#fbbf24` | `#0e9f6e` / `#b45309` |

### Components

- `.appbar` — sticky, blur, logo + `#logoSub` + theme/gear buttons
- `.modeswitch` — 2-part segmented control; active side apne track ka halka tint
  (violet = 90 Din, cyan = Learning) — pehle kaali dikh rahi thi, wo fix kiya gaya
- `.hero` — gradient card (`m90` violet / `mlearn` cyan), `.hero-pill` + `.hero-bar` + 3 stats
- `.blk` — daily block row; title ke aage chhota **track dot** (`.trk-90/.trk-learn/.trk-both`);
  right side pe kuch nahi (pehle tag box title ko tod raha tha)
- `.card / .card.tight / .card.flat`, `.btn` (`accent`, `indigo`, `soft`, `ghost`, `danger`, `sm`, `block`)
- `.phase / .mon-head / .head-bar / .cnt / .chev` — accordions, progress bar head ke neeche full width
- `.sheet` (Zara chat: `.chat-body`, `.msg`, `.chat-quick`, `.chat-input`), `.modal`, `.toast`
- `.tabbar` + `.fab` (48px, content ko dhakta nahi), `.test-box.ok/.bad`
- Print rules (`#printArea`), desktop `@media (min-width: 900px)` — nav bottom-docked, content 780px

### UX rules jo pehle tod diye gaye the (dobara mat todna)

1. Ek hi baat 3 jagah na dikhe (ring + hint + right column %).
2. Title ki width kam na karo right-side badge se.
3. Same kaam ke 2 button na ho (switch + "track kholo").
4. Tab switch pe page top pe jaye; chhote tick pe scroll jump na ho.
5. PC pe nav content ke upar na tayre.

---

## 13. Roadmap personalization (jo user ne manga)

`adaptedCard()` me UI me dikhta hai, aur `LEARN_MONTHS` me actually lagu hai:

| Kahan | Kya badla | Kyun |
|---|---|---|
| Month 1 | Excel dashboard hataya → Python + scripts | AI engineer ko Excel ka basic kaafi |
| Month 3 | EDA 4 → 3 hafte | 4th hafta SQL ko |
| Month 4 | Power BI/Tableau **skip** → FastAPI early | Data-analyst track nahi chahiye |
| Month 7 | DL 4 → 3 hafte | CNN rakha, RNN sirf concept |
| Month 12–13 | buffer month | 13 mahine lage to guilt nahi |
| Resources | Hindi-first | English weak hai |
| Resume | sample copy nahi, projects se | Sample 10 saal experience wale ka tha |

**Isse undo mat karo bina user se poochhe.**

---

## 14. Abhi kya baaki hai (open items)

1. **Real Supabase pe verify** — flow mock pe test hua hai; user ke apne project pe ek baar chalana hai.
2. **`your-github-username`** — `store.js` ke 2 seeded project links me placeholder hai; user ke username se replace karna.
3. **TTS provider keys** — Sarvam/ElevenLabs/Google key user daalega; free device voice default hai.
4. **Icons** — naye violet icon ban gaye hain; phone pe purana install delete karke dobara add karna padega.
5. **Netlify deploy** — zip banaya hua hai, user ko drag karna hai (credentials mere paas nahi).
6. **Notifications/reminders** — socha hua hai, banaya nahi.

---

## Code kahan hai?

Is brief me code nahi hai (chhota rakhne ke liye). Poora source `PROJECT-FULL.md` me hai.
Agar AI ko code change karwana hai to `PROJECT-FULL.md` do.
